package com.geko.garageauction.command;

import com.geko.garageauction.structure.MarketplaceBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class GarageCommands {
    private GarageCommands() {}

    public static void register(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("squarespawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generatePark(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Площадь создана: 24 гаража, дорожки, цветники и центральный монумент."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("scrapyardspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateScrapyard(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Свалка создана: кучи мусора и заполненные контейнеры."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("garagesspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateGarages(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Гаражный район создан: 12 мастерских в сине-серой гамме."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("luxuryspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateLuxuryDistrict(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Элитный район создан: огромный круглый район с мраморной стеной, плотной застройкой и 7–10 контейнерами в каждом доме."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("apartmentsspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateApartments(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Богатый многоэтажный район создан: пятиэтажные бело-зелёные дома, интерьеры и 15–30 контейнеров в каждом."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("cityspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateCity(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Индустриальный город создан: жилые кварталы, химические предприятия и четыре корпоративные башни."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("citylift").requires(s -> s.hasPermission(2))
            .then(Commands.argument("floor",IntegerArgumentType.integer(1,58)).executes(ctx -> {
                if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
                int floor=IntegerArgumentType.getInteger(ctx,"floor");
                if (!MarketplaceBuilder.useCityLift(p.serverLevel(),p,floor)) {
                    ctx.getSource().sendFailure(Component.literal("Лифт работает только внутри главной 58-этажной башни индустриального города. Используй /citylift <этаж> от 1 до 58."));
                    return 0;
                }
                ctx.getSource().sendSuccess(() -> Component.literal("Лифт доставил тебя на этаж: "+floor),false);
                return 1;
            })));
        dispatcher.register(Commands.literal("arenaspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateArena(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Круглая арена создана. Лута нет."),true); return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("matrixspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateMatrix(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Сбой в матрице создан: огромная заражённая зона, смешанные гаражи и усиленный лут."),true); return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("castlesspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateCastles(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Средневековый район замков создан. Внутри только бочки с оружием и бронёй."),true); return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("restorestructures").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            int restored=MarketplaceBuilder.restoreStructures(p.serverLevel());
            ctx.getSource().sendSuccess(() -> Component.literal("Восстановлено зарегистрированных локаций и групп построек: "+restored),true);
            return 1;
        }));
        dispatcher.register(Commands.literal("garagebatch").requires(s -> s.hasPermission(2))
            .then(Commands.argument("type",StringArgumentType.word())
            .then(Commands.argument("count",IntegerArgumentType.integer(1,50)).executes(ctx -> {
                if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
                String type=StringArgumentType.getString(ctx,"type");
                int count=IntegerArgumentType.getInteger(ctx,"count");
                try {
                    int made=MarketplaceBuilder.spawnBatch(p.serverLevel(),p.blockPosition(),p.getYRot(),type,count);
                    ctx.getSource().sendSuccess(() -> Component.literal("Создано объектов в ряд: "+made+". Тип: "+type),true); return 1;
                } catch (IllegalArgumentException ex) {
                    ctx.getSource().sendFailure(Component.literal(ex.getMessage()+". Пример: /garagebatch luxury 4")); return 0;
                }
            }))));
        registerRefresh(dispatcher,"reverselootsquare",102,"park","Лут площади обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootgarages",56,"vehicle","Лут гаражного района обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootscrapyard",52,"scrapyard","Лут свалки обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootluxury",290,"luxury","Лут элитного района обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootmatrix",315,"matrix","Лут сбоя в матрице обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootcastles",132,"castles","Лут замков обновлён в бочках: ");
        registerRefresh(dispatcher,"reverselootapartments",290,"apartments","Лут многоэтажного района обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootcity",435,"city","Лут индустриального города обновлён в контейнерах: ");
    }

    private static void registerRefresh(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> dispatcher,String name,int radius,String lootMode,String message) {
        dispatcher.register(Commands.literal(name).requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            int count=MarketplaceBuilder.refreshLoot(p.serverLevel(),p.blockPosition(),radius,lootMode);
            final int result=count;
            ctx.getSource().sendSuccess(() -> Component.literal(message+result),true); return 1;
        }));
    }
}
