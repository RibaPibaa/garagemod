# 0.6.0 mod integration notes

- Item discovery is dynamic: Garage Auction scans the live Forge item registry, so installed mods do not need to be hard dependencies.
- Original registered `Item` instances are used when making stacks. Their registered item attributes are therefore retained.
- The scanner recognizes serums, syringes, Compound V, symbiotes, rings, artifacts, potions, vehicle components, technology, firearms, melee weapons, clothing and armor by registry path and known mod namespaces.
- `arrzenhanced` was inspected from the available JAR. Flash suit pieces can be paired with the matching Flash ring; Reverse Flash pieces can be paired with the Reverse Flash ring/shield; colour Lantern pieces search for their colour-matched ring, Lantern item and power battery. Compound V and the serum families enter the serum/special pools.
- The available mod list identifies `marbledsmelees` and `delta_wt` as dedicated melee packs; those namespaces are routed to the melee category. MedievalCraft weapons are classified by item name so bows/crossbows are not forced into the melee-only garage pool.
- The exact FSang18's Heropack JAR was not available in the current file set. The Iron Man/reactor and Invincible/Viltrumite-serum rules are therefore generic name-based heuristics, not a verified mapping against that exact JAR. Upload that JAR to finalize its item IDs and determine whether any costume variants require custom NBT.
- The Matrix profile retains its previous strong weighted distribution. A low-probability shared special-item roll is added, as requested. The arena remains empty.
