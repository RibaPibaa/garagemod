# Garage Auction 0.6.0 — Forge 1.20.1

**Target:** Minecraft 1.20.1, Forge 47.4.28, Java 17. Build with Gradle 8.8.

## Spawn commands (operator permission level 2)

- `/squarespawn` — круглая площадь с дорожками, цветниками, монументом и небольшими домиками. Лут: еда, оружие, обычные предметы; броня выпадает редко.
- `/scrapyardspawn` — свалка с кучами мусора. Контейнеров немного, внутри мало и преимущественно низкокачественный лут.
- `/garagesspawn` — сине-серый район мастерских. Лут ограничен техникой/запчастями, холодным оружием и едой; без обычного огнестрела и брони.
- `/luxuryspawn` — большой богатый район с виллами, мраморной стеной, проспектами и 7–10 контейнерами в доме. Сбалансированный ценный лут.
- `/apartmentsspawn` — новый бело-зелёный район пятиэтажных жилых домов (около 48 зданий), с комнатами, кроватями, лестницами, зелёным остеклением, памятником воину и 15–30 контейнерами в каждом здании. Лут близок к богатому району, с повышенным шансом еды и одежды.
- `/cityspawn` — новый индустриальный город примерно в 1,5 раза крупнее богатого района: жилые кварталы, богатые дома, жилые высотки, две химические площадки, жители и четыре корпоративные башни. Главная башня — 58 этажей; три другие — 23, 28 и 34 этажа.
- `/citylift <этаж>` — телепорт лифта на этаж 1–58 главной башни. Команду нужно использовать внутри главной башни.
- `/arenaspawn` — круглая арена с трибунами и освещением. Лута нет.
- `/matrixspawn` — прежняя круглая зона «Сбой в матрице»: прежняя геометрия и основной сильный лут. Добавлен только общий редкий шанс особого предмета.
- `/castlesspawn` — средневековый район замков. Броня (включая супергеройскую), одежда, оружие и зелья; почти нет еды, техника исключена из обычного пула.

## Лут в индустриальном городе

- Химические предприятия: сыворотки, зелья, химические и особые компоненты.
- Маленькие жилые дома: много еды и одежды, немного техники (одна техническая вещь гарантирована в одном из контейнеров дома), редкая броня, преимущественно огнестрельное оружие.
- Богатые дома: профиль богатого района.
- Жилые высотки: больше брони, оружия, еды и техники.
- Корпоративные башни: наиболее ценные технологии, броня и оружие. В главной башне контейнеры распределены по этажам.

## Loot profiles

Loot is classified from the live Forge item registry into food, clothing, armor, melee weapons, firearms, technology/vehicle parts, potions, serums, special items and miscellaneous items. Profiles apply different category weights for each district. Each chest/barrel has an independent low-probability special-item roll in every loot-bearing location; the arena remains intentionally empty. The roll is profile-filtered so castle armories do not receive ordinary technology and chemical plants stay focused on serums/potions. Matrix keeps its established high-value profile.

Armor set detection now requires all four normal armor slots (head, chest, legs, feet); partial armor sets are not treated as complete sets. Matching clothing outfits can still be generated as coherent outfits. Original registry items are used so their registered attributes remain intact. Known Iron Man, Green Lantern, Invincible and Flash item-name patterns can pull related components from the same mod namespace when those components are discoverable. Mod-specific variants stored only in custom NBT may need a dedicated adapter after inspecting that mod's JAR.

TaCZ integration remains optional and uses reflection to create a gun/ammunition bundle from the loaded gun-pack registry.

## Container placement and regeneration

- A barrel is never placed above a chest by the generator. If a container is stacked above a chest, the upper container is forced to be another chest.
- Each generated container stores its loot profile, so refresh commands keep the right district-specific distribution.
- `/restorestructures` removes generated blocks and their inventories, item entities dropped inside the registered footprint, generated armor stands and Garage Auction-spawned villagers, then rebuilds the location from its saved seed. Player-built blocks inside a registered footprint are also cleared.
- New locations are registered for restoration. Old structures created before registry tracking was introduced cannot be automatically reconstructed.

## Loot refresh commands

- `/reverselootsquare` — park/square.
- `/reverselootgarages` — workshops.
- `/reverselootscrapyard` — scrapyard.
- `/reverselootluxury` — luxury villas.
- `/reverselootapartments` — five-storey apartment district.
- `/reverselootcity` — all container profiles across the industrial city.
- `/reverselootmatrix` — Matrix glitch area.
- `/reverselootcastles` — castle barrels.

Stand near the centre of the relevant location before using its refresh command. City and apartment refreshes scan the full vertical build range.

## Build

```bash
gradle build --no-daemon
```

The compiled mod is written to `build/libs/garageauction-0.6.0.jar`.

## Mod-specific bundle verification

The generic registry scanner already recognizes the visible `arrzenhanced` item families (including Flash rings, colour Lantern items, serums and Compound V) and the known melee-pack namespaces (`marbledsmelees` and `delta_wt`). The exact FSang18's Heropack JAR is not present among the files currently available for inspection. Its exact item IDs and any custom item NBT variants therefore still need a final adapter pass; the current Iron Man / Invincible bundle matching is name-based and same-namespace only. The source archive is usable as a first 0.6.0 integration build, but this mod-specific verification should be completed before treating every superhero bundle as final.
