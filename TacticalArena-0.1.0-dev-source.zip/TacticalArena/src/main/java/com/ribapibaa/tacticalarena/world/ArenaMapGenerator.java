package com.ribapibaa.tacticalarena.world;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.game.ArenaMatchManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/** Procedural arena regions. The first player login creates them automatically. */
public final class ArenaMapGenerator {
    public static final BlockPos ASSAULT = new BlockPos(-520, 80, -300);
    public static final BlockPos HITMANIA = new BlockPos(520, 80, -300);
    public static final BlockPos DOCKYARD = new BlockPos(0, 80, 620);
    public static final BlockPos BUNKER = new BlockPos(0, 35, 0);
    public static final BlockPos LOBBY = new BlockPos(0, 80, 1900);
    private static final int RADIUS = 105;
    private static final Set<BlockPos> CHESTS = new HashSet<>();
    private static final List<BlockPos> GATE_BLOCKS = new ArrayList<>();
    private static final Random RANDOM = new Random(20261113L);
    private static boolean generated;
    private static BlockPos hitmaniaSelected = HITMANIA;
    private static final List<Vec3> USED_BR_SPAWNS = new ArrayList<>();

    private ArenaMapGenerator() {}

    public static boolean isGenerated() { return generated; }

    public static void generateAll(ServerLevel level) {
        RANDOM.setSeed(20261113L);
        CHESTS.clear();
        GATE_BLOCKS.clear();
        ArenaNpcSpawner.resetSpawnPoints();
        generateVillage(level, ASSAULT);
        generateCity(level, HITMANIA);
        generateDockyard(level, DOCKYARD);
        generateBunker(level, BUNKER);
        generateLobby(level, LOBBY);
        generatePassages(level);
        ArenaLoot.populateAll(level, CHESTS);
        ArenaNpcSpawner.populate(level, false);
        ArenaWorldManager.captureSnapshot(level, CHESTS);
        generated = true;
    }

    public static void prepareMatch(ArenaMatchManager.Mode mode) {
        hitmaniaSelected = RANDOM.nextBoolean() ? ASSAULT : HITMANIA;
        USED_BR_SPAWNS.clear();
    }

    public static void setBattleRoyaleAccess(ServerLevel level, boolean open) {
        for (BlockPos pos : GATE_BLOCKS) level.setBlock(pos, open ? Blocks.AIR.defaultBlockState() : Blocks.IRON_BARS.defaultBlockState(), 3);
    }

    public static Vec3 randomBattleRoyaleSpawn(ServerLevel level, int playerIndex) {
        BlockPos[] centers = {ASSAULT, HITMANIA, DOCKYARD};
        for (int attempt = 0; attempt < 150; attempt++) {
            BlockPos center = centers[RANDOM.nextInt(centers.length)];
            double angle = RANDOM.nextDouble() * Math.PI * 2.0;
            double radius = 18 + RANDOM.nextDouble() * 70;
            int x = center.getX() + (int) Math.round(Math.cos(angle) * radius);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * radius);
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos feet = new BlockPos(x, y, z);
            if (!isCombatArenaPosition(feet)) continue;
            if (!level.getBlockState(feet.below()).isSolidRender(level, feet.below())) continue;
            if (level.getBlockState(feet).is(Blocks.FIRE) || level.getBlockState(feet).is(Blocks.SOUL_FIRE)) continue;
            if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(feet.above()).isEmpty()) continue;
            if (!level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()) continue;
            if (!level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()) continue;
            Vec3 candidate = new Vec3(x + 0.5, y, z + 0.5);
            boolean tooClose = USED_BR_SPAWNS.stream().anyMatch(existing -> existing.distanceTo(candidate) < 120.0D);
            if (tooClose) continue;
            USED_BR_SPAWNS.add(candidate);
            return candidate;
        }
        BlockPos fallback = centers[playerIndex % centers.length];
        return new Vec3(fallback.getX() + 0.5, fallback.getY() + 1, fallback.getZ() + 0.5);
    }

    public static Vec3 lobbySpawn() { return new Vec3(LOBBY.getX() + 0.5, LOBBY.getY() + 1, LOBBY.getZ() + 15.5); }

    public static Vec3 spawnFor(ArenaMatchManager.Mode mode, int playerIndex, int playerCount) {
        BlockPos center;
        if (mode == ArenaMatchManager.Mode.ASSAULT) center = ASSAULT;
        else if (mode == ArenaMatchManager.Mode.HITMANIA) center = hitmaniaSelected;
        else {
            BlockPos[] choices = {ASSAULT, HITMANIA, DOCKYARD};
            center = choices[RANDOM.nextInt(choices.length)];
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double distance = 22 + RANDOM.nextDouble() * 55;
            return new Vec3(center.getX() + Math.cos(angle) * distance, center.getY() + 2, center.getZ() + Math.sin(angle) * distance);
        }
        double offset = playerIndex == 0 ? -3.0 : 3.0;
        double spawnY = (mode == ArenaMatchManager.Mode.HITMANIA && center.equals(HITMANIA)) ? center.getY() + 2 : center.getY() + 1;
        return new Vec3(center.getX() + offset, spawnY, center.getZ() + 5);
    }

    public static boolean isArenaPosition(BlockPos pos) {
        return inside(pos, ASSAULT, RADIUS) || inside(pos, HITMANIA, RADIUS) || inside(pos, DOCKYARD, RADIUS)
                || inside(pos, BUNKER, 45) || inside(pos, LOBBY, 48) || nearPassage(pos);
    }

    public static boolean isCombatArenaPosition(BlockPos pos) {
        return inside(pos, ASSAULT, RADIUS) || inside(pos, HITMANIA, RADIUS) || inside(pos, DOCKYARD, RADIUS) || inside(pos, BUNKER, 45) || nearPassage(pos);
    }

    public static boolean isLobbyPosition(BlockPos pos) {
        return inside(pos, LOBBY, 48);
    }

    private static boolean nearPassage(BlockPos pos) {
        if (pos.getY() < 65 || pos.getY() > 82) return false;
        int ax = ASSAULT.getX() + 100, az = ASSAULT.getZ();
        int hx = HITMANIA.getX() - 100, hz = HITMANIA.getZ();
        int dx = DOCKYARD.getX(), dz = DOCKYARD.getZ() - 100;
        return distanceToSegment(pos.getX(), pos.getZ(), ax, az, hx, hz) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), HITMANIA.getX(), HITMANIA.getZ() + 100, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, ASSAULT.getX(), ASSAULT.getZ() + 100) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), ax, az) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), hx, hz) < 7
                || distanceToSegment(pos.getX(), pos.getZ(), BUNKER.getX(), BUNKER.getZ(), dx, dz) < 7;
    }

    private static double distanceToSegment(double px, double pz, double ax, double az, double bx, double bz) {
        double dx = bx - ax, dz = bz - az;
        double length = dx * dx + dz * dz;
        if (length == 0) return Math.hypot(px - ax, pz - az);
        double t = Math.max(0, Math.min(1, ((px - ax) * dx + (pz - az) * dz) / length));
        return Math.hypot(px - (ax + t * dx), pz - (az + t * dz));
    }

    public static List<net.minecraft.world.phys.AABB> allBounds() {
        return List.of(bounds(ASSAULT, RADIUS, 80), bounds(HITMANIA, RADIUS, 80), bounds(DOCKYARD, RADIUS, 80),
                bounds(BUNKER, 45, 45), bounds(LOBBY, 48, 48), new net.minecraft.world.phys.AABB(-430, 65, -310, 430, 82, -290),
                new net.minecraft.world.phys.AABB(-10, 65, -410, 530, 82, 550), new net.minecraft.world.phys.AABB(-530, 65, -410, 10, 82, 550),
                new net.minecraft.world.phys.AABB(-430, 65, -310, 10, 82, 10), new net.minecraft.world.phys.AABB(-10, 65, -310, 430, 82, 10),
                new net.minecraft.world.phys.AABB(-10, 65, -10, 10, 82, 550));
    }

    private static boolean inside(BlockPos pos, BlockPos center, int radius) {
        long dx = pos.getX() - center.getX(); long dz = pos.getZ() - center.getZ();
        return dx * dx + dz * dz <= (long) radius * radius && Math.abs(pos.getY() - center.getY()) <= 90;
    }

    private static net.minecraft.world.phys.AABB bounds(BlockPos center, int radius, int yRadius) {
        return new net.minecraft.world.phys.AABB(center.getX() - radius, center.getY() - yRadius, center.getZ() - radius,
                center.getX() + radius, center.getY() + yRadius, center.getZ() + radius);
    }

    private static void generateVillage(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS, Blocks.COARSE_DIRT.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.MOSSY_STONE_BRICKS.defaultBlockState());
        // Three loose districts, with small yards and varied houses.
        for (int dz = -52; dz <= 52; dz += 26) {
            for (int dx = -52; dx <= 52; dx += 26) {
                if (Math.abs(dx) < 15 && Math.abs(dz) < 15) continue;
                int x = c.getX() + dx, z = c.getZ() + dz;
                buildHouse(level, x, c.getY(), z, 9 + RANDOM.nextInt(5), 7 + RANDOM.nextInt(4), 5 + RANDOM.nextInt(3), RANDOM.nextBoolean());
                if (RANDOM.nextBoolean()) box(level, x - 4, c.getY(), z + 10, x + 4, c.getY() + 1, z + 12, Blocks.HAY_BLOCK.defaultBlockState());
            }
        }
        // Streets and ruined cover.
        box(level, c.getX() - 4, c.getY(), c.getZ() - 95, c.getX() + 4, c.getY(), c.getZ() + 95, Blocks.GRAVEL.defaultBlockState());
        box(level, c.getX() - 95, c.getY(), c.getZ() - 4, c.getX() + 95, c.getY(), c.getZ() + 4, Blocks.GRAVEL.defaultBlockState());
        for (int i = 0; i < 18; i++) {
            int x = c.getX() + RANDOM.nextInt(150) - 75, z = c.getZ() + RANDOM.nextInt(150) - 75;
            if (Math.abs(x - c.getX()) < 12 && Math.abs(z - c.getZ()) < 12) continue;
            box(level, x, c.getY(), z, x + 2, c.getY() + 1, z + 2, Blocks.COBBLESTONE.defaultBlockState());
            if (RANDOM.nextBoolean()) set(level, x + 1, c.getY() + 2, z + 1, Blocks.DEAD_BUSH.defaultBlockState());
        }
        placeChest(level, c.getX() - 35, c.getY() + 1, c.getZ() + 35, ArenaLoot.Table.ASSAULT);
        placeChest(level, c.getX() + 42, c.getY() + 1, c.getZ() - 40, ArenaLoot.Table.ASSAULT);
    }

    private static void buildHouse(ServerLevel level, int x, int y, int z, int w, int d, int h, boolean brick) {
        BlockState wall = (brick ? Blocks.BRICKS : Blocks.COBBLESTONE).defaultBlockState();
        BlockState roof = (brick ? Blocks.DARK_OAK_PLANKS : Blocks.SPRUCE_PLANKS).defaultBlockState();
        box(level, x, y, z, x + w, y + h, z + d, wall);
        box(level, x + 1, y + 1, z + 1, x + w - 1, y + h - 1, z + d - 1, Blocks.AIR.defaultBlockState());
        box(level, x - 1, y + h + 1, z - 1, x + w + 1, y + h + 1, z + d + 1, roof);
        set(level, x + w / 2, y + 1, z, Blocks.AIR.defaultBlockState());
        set(level, x + w / 2, y + 2, z, Blocks.AIR.defaultBlockState());
        set(level, x + 2, y + 2, z, Blocks.GLASS_PANE.defaultBlockState());
        set(level, x + w - 2, y + 2, z, Blocks.GLASS_PANE.defaultBlockState());
        set(level, x + 2, y + 2, z + d, Blocks.GLASS_PANE.defaultBlockState());
        set(level, x + w - 2, y + 2, z + d, Blocks.GLASS_PANE.defaultBlockState());
        box(level, x + 2, y + 1, z + 2, x + w - 2, y + 1, z + d - 2, Blocks.OAK_PLANKS.defaultBlockState());
        ArenaNpcSpawner.registerSpawn(x + w / 2, y + 2, z + d / 2);
        placeChest(level, x + 1, y + 1, z + 1, ArenaLoot.Table.ASSAULT);
        set(level, x + 2, y + 1, z + d - 2, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(level, x + w - 2, y + 1, z + 2, Blocks.BARREL.defaultBlockState());
        set(level, x + w - 2, y + 1, z + d - 2, Blocks.FURNACE.defaultBlockState());
        if (RANDOM.nextBoolean()) set(level, x + 2, y + h + 2, z + 2, Blocks.CAMPFIRE.defaultBlockState());
    }

    private static void generateCity(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS, Blocks.GRAY_CONCRETE.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        box(level, c.getX() - 5, c.getY(), c.getZ() - 95, c.getX() + 5, c.getY(), c.getZ() + 95, Blocks.BLACK_CONCRETE.defaultBlockState());
        box(level, c.getX() - 95, c.getY(), c.getZ() - 5, c.getX() + 95, c.getY(), c.getZ() + 5, Blocks.BLACK_CONCRETE.defaultBlockState());
        int[][] plots = {{-55,-55},{-20,-55},{20,-55},{55,-20},{55,25},{20,55},{-20,55},{-55,20},{0,0}};
        for (int i = 0; i < plots.length; i++) {
            int x = c.getX() + plots[i][0], z = c.getZ() + plots[i][1];
            buildTower(level, x - 9, c.getY(), z - 9, 18, 18, 3 + RANDOM.nextInt(5), i % 3);
        }
        placeChest(level, c.getX() - 60, c.getY() + 1, c.getZ() + 60, ArenaLoot.Table.HITMANIA);
        placeChest(level, c.getX() + 62, c.getY() + 1, c.getZ() - 60, ArenaLoot.Table.HITMANIA);
    }

    private static void buildTower(ServerLevel level, int x, int y, int z, int w, int d, int floors, int style) {
        BlockState wall = (style == 0 ? Blocks.LIGHT_GRAY_CONCRETE : style == 1 ? Blocks.GRAY_CONCRETE : Blocks.BRICKS).defaultBlockState();
        for (int floor = 0; floor < floors; floor++) {
            int fy = y + floor * 5;
            box(level, x, fy, z, x + w, fy + 4, z + d, wall);
            box(level, x + 1, fy + 1, z + 1, x + w - 1, fy + 3, z + d - 1, Blocks.AIR.defaultBlockState());
            box(level, x + 1, fy + 1, z + 1, x + w - 1, fy + 1, z + d - 1, Blocks.POLISHED_ANDESITE.defaultBlockState());
            for (int wx = x + 3; wx < x + w - 2; wx += 4) {
                set(level, wx, fy + 2, z, Blocks.GLASS_PANE.defaultBlockState());
                set(level, wx, fy + 2, z + d, Blocks.GLASS_PANE.defaultBlockState());
            }
            set(level, x + w / 2, fy + 1, z + d / 2, Blocks.SEA_LANTERN.defaultBlockState());
            ArenaNpcSpawner.registerSpawn(x + 4, fy + 2, z + 4);
            for (int stairY = fy + 1; stairY < fy + 5; stairY++) set(level, x + w - 3, stairY, z + 3, Blocks.SCAFFOLDING.defaultBlockState());
            // Small exterior balcony on the street-facing wall.
            box(level, x + 5, fy + 1, z - 3, x + w - 5, fy + 1, z - 1, Blocks.SPRUCE_PLANKS.defaultBlockState());
            box(level, x + 5, fy + 2, z - 3, x + w - 5, fy + 3, z - 3, Blocks.IRON_BARS.defaultBlockState());
        }
        box(level, x, y + floors * 5, z, x + w, y + floors * 5, z + d, Blocks.BLACK_CONCRETE.defaultBlockState());
        placeChest(level, x + 2, y + 2, z + 2, ArenaLoot.Table.HITMANIA);
    }

    private static void generateDockyard(ServerLevel level, BlockPos c) {
        circularGround(level, c, RADIUS, Blocks.COARSE_DIRT.defaultBlockState());
        circularWall(level, c, RADIUS, Blocks.IRON_BARS.defaultBlockState());
        // Rail spurs and a large warehouse.
        box(level, c.getX() - 90, c.getY(), c.getZ() - 8, c.getX() + 90, c.getY(), c.getZ() - 6, Blocks.RAIL.defaultBlockState());
        box(level, c.getX() - 90, c.getY(), c.getZ() + 8, c.getX() + 90, c.getY(), c.getZ() + 10, Blocks.RAIL.defaultBlockState());
        box(level, c.getX() - 35, c.getY(), c.getZ() - 25, c.getX() + 35, c.getY() + 12, c.getZ() + 25, Blocks.IRON_BLOCK.defaultBlockState());
        box(level, c.getX() - 33, c.getY() + 1, c.getZ() - 23, c.getX() + 33, c.getY() + 11, c.getZ() + 23, Blocks.AIR.defaultBlockState());
        for (int i = 0; i < 28; i++) {
            int x = c.getX() + RANDOM.nextInt(150) - 75;
            int z = c.getZ() + RANDOM.nextInt(150) - 75;
            int y = c.getY();
            BlockState color = switch (RANDOM.nextInt(5)) {
                case 0 -> Blocks.RED_CONCRETE.defaultBlockState(); case 1 -> Blocks.BLUE_CONCRETE.defaultBlockState();
                case 2 -> Blocks.GREEN_CONCRETE.defaultBlockState(); case 3 -> Blocks.YELLOW_CONCRETE.defaultBlockState();
                default -> Blocks.ORANGE_CONCRETE.defaultBlockState();
            };
            box(level, x, y + 1, z, x + 11, y + 3, z + 4, color);
            box(level, x + 1, y + 2, z + 1, x + 10, y + 2, z + 3, Blocks.AIR.defaultBlockState());
            if (RANDOM.nextBoolean()) box(level, x, y + 4, z, x + 11, y + 6, z + 4, color);
        }
        // Crane-like gantries.
        for (int x : new int[]{c.getX() - 65, c.getX() + 65}) {
            box(level, x, c.getY(), c.getZ() - 35, x + 3, c.getY() + 32, c.getZ() - 32, Blocks.IRON_BLOCK.defaultBlockState());
            box(level, x + 24, c.getY(), c.getZ() - 35, x + 27, c.getY() + 32, c.getZ() - 32, Blocks.IRON_BLOCK.defaultBlockState());
            box(level, x, c.getY() + 32, c.getZ() - 35, x + 27, c.getY() + 34, c.getZ() - 32, Blocks.IRON_BLOCK.defaultBlockState());
        }
        placeChest(level, c.getX() - 72, c.getY() + 1, c.getZ() + 48, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() + 70, c.getY() + 1, c.getZ() + 45, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() - 55, c.getY() + 1, c.getZ() - 55, ArenaLoot.Table.DOCKYARD);
        placeChest(level, c.getX() + 52, c.getY() + 1, c.getZ() - 52, ArenaLoot.Table.DOCKYARD);
        ArenaNpcSpawner.registerSpawn(c.getX() - 28, c.getY() + 1, c.getZ() + 8);
        ArenaNpcSpawner.registerSpawn(c.getX() + 30, c.getY() + 1, c.getZ() - 12);
        ArenaNpcSpawner.registerSpawn(c.getX() + 10, c.getY() + 1, c.getZ() + 40);
    }

    private static void generateBunker(ServerLevel level, BlockPos c) {
        int y = 22;
        box(level, c.getX() - 42, y, c.getZ() - 42, c.getX() + 42, y + 15, c.getZ() + 42, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        box(level, c.getX() - 40, y + 1, c.getZ() - 40, c.getX() + 40, y + 14, c.getZ() + 40, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 5, y + 1, c.getZ() - 40, c.getX() + 5, y + 13, c.getZ() + 40, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 38, y + 1, c.getZ() - 5, c.getX() + 38, y + 13, c.getZ() + 5, Blocks.AIR.defaultBlockState());
        for (int i = -30; i <= 30; i += 10) {
            box(level, c.getX() + i - 4, y + 1, c.getZ() - 35, c.getX() + i + 4, y + 11, c.getZ() - 20, Blocks.AIR.defaultBlockState());
            box(level, c.getX() + i - 4, y + 1, c.getZ() + 20, c.getX() + i + 4, y + 11, c.getZ() + 35, Blocks.AIR.defaultBlockState());
        }
        for (int x = c.getX() - 35; x <= c.getX() + 35; x += 10) set(level, x, y + 12, c.getZ(), Blocks.SEA_LANTERN.defaultBlockState());
        placeChest(level, c.getX() - 30, y + 1, c.getZ() - 28, ArenaLoot.Table.BUNKER);
        placeChest(level, c.getX() + 30, y + 1, c.getZ() + 28, ArenaLoot.Table.BUNKER);
    }

    private static void generateLobby(ServerLevel level, BlockPos c) {
        box(level, c.getX() - 48, c.getY(), c.getZ() - 48, c.getX() + 48, c.getY(), c.getZ() + 48, Blocks.GRASS_BLOCK.defaultBlockState());
        // Old manor footprint, three floors, furnished-looking interior and warm lights.
        box(level, c.getX() - 18, c.getY(), c.getZ() - 12, c.getX() + 18, c.getY() + 13, c.getZ() + 12, Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        box(level, c.getX() - 16, c.getY() + 1, c.getZ() - 10, c.getX() + 16, c.getY() + 12, c.getZ() + 10, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 1, c.getY() + 1, c.getZ() + 12, c.getX() + 1, c.getY() + 2, c.getZ() + 12, Blocks.AIR.defaultBlockState());
        box(level, c.getX() - 17, c.getY() + 1, c.getZ() - 11, c.getX() + 17, c.getY() + 1, c.getZ() + 11, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        box(level, c.getX() - 20, c.getY() + 14, c.getZ() - 14, c.getX() + 20, c.getY() + 14, c.getZ() + 14, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        for (int floor = 0; floor < 2; floor++) {
            int y = c.getY() + 4 + floor * 4;
            box(level, c.getX() - 16, y, c.getZ() - 10, c.getX() + 16, y, c.getZ() + 10, Blocks.SPRUCE_PLANKS.defaultBlockState());
        }
        for (int y = c.getY() + 1; y <= c.getY() + 11; y++) set(level, c.getX() - 14, y, c.getZ() - 8, Blocks.SCAFFOLDING.defaultBlockState());
        box(level, c.getX() - 13, c.getY() + 1, c.getZ() - 7, c.getX() - 10, c.getY() + 3, c.getZ() - 5, Blocks.BOOKSHELF.defaultBlockState());
        set(level, c.getX() + 12, c.getY() + 1, c.getZ() - 7, Blocks.LECTERN.defaultBlockState());
        box(level, c.getX() - 6, c.getY() + 1, c.getZ() + 4, c.getX() + 6, c.getY() + 1, c.getZ() + 5, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        for (int x : new int[]{c.getX() - 12, c.getX(), c.getX() + 12}) {
            set(level, x, c.getY() + 3, c.getZ() - 12, Blocks.LANTERN.defaultBlockState());
            set(level, x, c.getY() + 3, c.getZ() + 12, Blocks.LANTERN.defaultBlockState());
        }
        box(level, c.getX() - 3, c.getY() + 15, c.getZ() - 2, c.getX() + 3, c.getY() + 20, c.getZ() + 2, Blocks.BRICKS.defaultBlockState());
        set(level, c.getX(), c.getY() + 20, c.getZ(), Blocks.CAMPFIRE.defaultBlockState());
        // Tall grass and lantern paths.
        for (int i = 0; i < 180; i++) {
            int x = c.getX() + RANDOM.nextInt(90) - 45, z = c.getZ() + RANDOM.nextInt(90) - 45;
            if (Math.abs(x - c.getX()) < 22 && Math.abs(z - c.getZ()) < 18) continue;
            set(level, x, c.getY() + 1, z, Blocks.TALL_GRASS.defaultBlockState());
        }
        for (int z = c.getZ() + 14; z <= c.getZ() + 35; z += 7) set(level, c.getX(), c.getY() + 1, z, Blocks.LANTERN.defaultBlockState());
        // Manor perimeter fence keeps the lobby visually separate from the arenas.
        for (int angle = 0; angle < 360; angle++) {
            double a = Math.toRadians(angle);
            int x = c.getX() + (int) Math.round(Math.cos(a) * 47);
            int z = c.getZ() + (int) Math.round(Math.sin(a) * 47);
            set(level, x, c.getY() + 1, z, Blocks.DARK_OAK_FENCE.defaultBlockState());
        }
        set(level, c.getX(), c.getY() + 1, c.getZ() + 47, Blocks.AIR.defaultBlockState());
    }

    private static void generatePassages(ServerLevel level) {
        int aX = ASSAULT.getX() + 100, aZ = ASSAULT.getZ();
        int hX = HITMANIA.getX() - 100, hZ = HITMANIA.getZ();
        int dX = DOCKYARD.getX(), dZ = DOCKYARD.getZ() - 100;
        // Outer triangular passages connect every pair of arenas.
        buildPassage(level, aX, aZ, hX, hZ);
        buildPassage(level, HITMANIA.getX(), HITMANIA.getZ() + 100, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70);
        buildPassage(level, DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, ASSAULT.getX(), ASSAULT.getZ() + 100);
        // Three additional gated branches lead from the central bunker to each arena.
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), aX, aZ);
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), hX, hZ);
        buildPassage(level, BUNKER.getX(), BUNKER.getZ(), dX, dZ);
        createShaft(level, aX, aZ, 71, 80);
        createShaft(level, hX, hZ, 71, 80);
        createShaft(level, dX, dZ, 71, 80);
        createShaft(level, HITMANIA.getX(), HITMANIA.getZ() + 100, 71, 80);
        createShaft(level, DOCKYARD.getX() + 70, DOCKYARD.getZ() - 70, 71, 80);
        createShaft(level, DOCKYARD.getX() - 70, DOCKYARD.getZ() - 70, 71, 80);
        createShaft(level, ASSAULT.getX(), ASSAULT.getZ() + 100, 71, 80);
        createShaft(level, BUNKER.getX(), BUNKER.getZ(), 38, 80);
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            BlockPos gate = new BlockPos(BUNKER.getX() + dx, 37, BUNKER.getZ() + dz);
            GATE_BLOCKS.add(gate);
            level.setBlock(gate, Blocks.IRON_BARS.defaultBlockState(), 3);
        }
    }

    private static void createShaft(ServerLevel level, int x, int z, int minY, int maxY) {
        for (int y = minY; y <= maxY; y++) {
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                BlockPos pos = new BlockPos(x + dx, y, z + dz);
                if (y == maxY || y == minY) level.setBlock(pos, (dx == 0 && dz == 0) ? Blocks.AIR.defaultBlockState() : (edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState()), 3);
                else level.setBlock(pos, edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState(), 3);
            }
            if (y > minY && y < maxY) set(level, x, y, z, Blocks.SCAFFOLDING.defaultBlockState());
        }
    }

    private static void buildPassage(ServerLevel level, int ax, int az, int bx, int bz) {
        int steps = Math.max(Math.abs(bx - ax), Math.abs(bz - az));
        int gateStep = steps / 2;
        for (int i = 0; i <= steps; i++) {
            double t = steps == 0 ? 0 : (double) i / steps;
            int x = (int) Math.round(ax + (bx - ax) * t);
            int z = (int) Math.round(az + (bz - az) * t);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                boolean edge = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                for (int y = 71; y <= 75; y++) {
                    BlockPos p = new BlockPos(x + dx, y, z + dz);
                    if (i == gateStep) {
                        GATE_BLOCKS.add(p);
                        level.setBlock(p, Blocks.IRON_BARS.defaultBlockState(), 3);
                    } else {
                        level.setBlock(p, edge ? Blocks.STONE_BRICKS.defaultBlockState() : Blocks.AIR.defaultBlockState(), 3);
                    }
                }
                level.setBlock(new BlockPos(x + dx, 70, z + dz), Blocks.STONE_BRICKS.defaultBlockState(), 3);
                level.setBlock(new BlockPos(x + dx, 76, z + dz), Blocks.STONE_BRICKS.defaultBlockState(), 3);
            }
        }
    }

    private static void circularGround(ServerLevel level, BlockPos c, int radius, BlockState state) {
        int y = ArenaConfig.ARENA_Y.get();
        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            if (x * x + z * z <= radius * radius) box(level, c.getX() + x, y - 2, c.getZ() + z, c.getX() + x, y, c.getZ() + z, state);
        }
    }

    private static void circularWall(ServerLevel level, BlockPos c, int radius, BlockState state) {
        int y = ArenaConfig.ARENA_Y.get();
        for (int angle = 0; angle < 360; angle++) {
            double a = Math.toRadians(angle);
            int x = c.getX() + (int) Math.round(Math.cos(a) * radius);
            int z = c.getZ() + (int) Math.round(Math.sin(a) * radius);
            box(level, x, y + 1, z, x, y + 7, z, state);
        }
    }

    private static void placeChest(ServerLevel level, int x, int y, int z, ArenaLoot.Table table) {
        BlockPos pos = new BlockPos(x, y, z);
        level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        CHESTS.add(pos);
        ArenaLoot.setTable(pos, table);
    }

    private static void box(ServerLevel level, int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
        int minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
        for (int x = minX; x <= maxX; x++) for (int y = minY; y <= maxY; y++) for (int z = minZ; z <= maxZ; z++) {
            level.setBlock(new BlockPos(x, y, z), state, 3);
        }
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, 3);
    }
}
