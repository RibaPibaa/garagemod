package com.ribapibaa.tacticalarena.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

public final class ArenaConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue MATCH_MINUTES;
    public static final ForgeConfigSpec.IntValue BR_ZONE_SHRINK_MINUTES;
    public static final ForgeConfigSpec.IntValue READY_COUNTDOWN_SECONDS;
    public static final ForgeConfigSpec.IntValue WARMUP_SECONDS;
    public static final ForgeConfigSpec.IntValue DEATHCAM_SECONDS;
    public static final ForgeConfigSpec.IntValue RESPAWN_PROTECTION_SECONDS;
    public static final ForgeConfigSpec.IntValue RESPAWN_MIN_DISTANCE;
    public static final ForgeConfigSpec.IntValue RESPAWN_MAX_DISTANCE;
    public static final ForgeConfigSpec.IntValue KILL_REGEN_SECONDS;
    public static final ForgeConfigSpec.IntValue KILL_REGEN_AMPLIFIER;
    public static final ForgeConfigSpec.BooleanValue LOCK_WORLD_TIME;
    public static final ForgeConfigSpec.BooleanValue ALLOW_DESTRUCTIBLE_BLOCKS;
    public static final ForgeConfigSpec.IntValue ARENA_Y;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> ASSAULT_KIT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> HITMANIA_KIT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> BR_STARTER_KIT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> HITMANIA_CLOTHING;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> ASSAULT_MEDICAL;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> HITMANIA_MEDICAL;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> ASSAULT_LOOT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> HITMANIA_LOOT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> DOCKYARD_LOOT;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> BUNKER_LOOT;

    static {
        BUILDER.push("match");
        MATCH_MINUTES = BUILDER.defineInRange("durationMinutes", 10, 1, 120);
        BR_ZONE_SHRINK_MINUTES = BUILDER.defineInRange("battleRoyaleZoneShrinkMinutes", 10, 1, 120);
        READY_COUNTDOWN_SECONDS = BUILDER.defineInRange("readyCountdownSeconds", 4, 1, 30);
        WARMUP_SECONDS = BUILDER.defineInRange("warmupSeconds", 10, 0, 120);
        DEATHCAM_SECONDS = BUILDER.defineInRange("deathcamSeconds", 3, 0, 30);
        RESPAWN_PROTECTION_SECONDS = BUILDER.defineInRange("respawnProtectionSeconds", 3, 0, 30);
        RESPAWN_MIN_DISTANCE = BUILDER.defineInRange("respawnMinDistance", 20, 1, 128);
        RESPAWN_MAX_DISTANCE = BUILDER.defineInRange("respawnMaxDistance", 23, 1, 128);
        KILL_REGEN_SECONDS = BUILDER.defineInRange("killRegenerationSeconds", 5, 0, 30);
        KILL_REGEN_AMPLIFIER = BUILDER.defineInRange("killRegenerationAmplifier", 4, 0, 10);
        LOCK_WORLD_TIME = BUILDER.define("lockWorldTimeDuringMatch", true);
        ALLOW_DESTRUCTIBLE_BLOCKS = BUILDER.define("allowGlassDoorsAndPropsToBreak", true);
        ARENA_Y = BUILDER.defineInRange("arenaSurfaceY", 80, 50, 200);
        BUILDER.pop();

        BUILDER.push("kits");
        ASSAULT_KIT = BUILDER.defineList("assault", java.util.List.of(
                "minecraft:iron_sword", "minecraft:crossbow", "minecraft:shield",
                "minecraft:iron_chestplate", "minecraft:iron_helmet", "minecraft:cooked_beef"
        ), o -> o instanceof String);
        HITMANIA_KIT = BUILDER.defineList("hitmania", java.util.List.of(
                "minecraft:crossbow", "minecraft:iron_sword", "minecraft:leather_chestplate",
                "minecraft:leather_leggings", "minecraft:cooked_beef", "minecraft:golden_apple"
        ), o -> o instanceof String);
        BR_STARTER_KIT = BUILDER.defineList("battleRoyaleStarter", java.util.List.of("minecraft:bread"), o -> o instanceof String);
        HITMANIA_CLOTHING = BUILDER.defineList("hitmaniaBusinessSuitItems", java.util.List.<String>of(), o -> o instanceof String);
        ASSAULT_MEDICAL = BUILDER.defineList("assaultMedicalItems", java.util.List.<String>of(), o -> o instanceof String);
        HITMANIA_MEDICAL = BUILDER.defineList("hitmaniaMedicalItems", java.util.List.<String>of(), o -> o instanceof String);
        ASSAULT_LOOT = BUILDER.defineList("assaultLootItems", java.util.List.of("minecraft:crossbow", "minecraft:iron_sword", "minecraft:shield", "minecraft:chainmail_chestplate", "minecraft:arrow", "minecraft:cooked_beef", "minecraft:golden_apple"), o -> o instanceof String);
        HITMANIA_LOOT = BUILDER.defineList("hitmaniaLootItems", java.util.List.of("minecraft:crossbow", "minecraft:spyglass", "minecraft:iron_sword", "minecraft:leather_chestplate", "minecraft:arrow", "minecraft:golden_apple", "minecraft:bread"), o -> o instanceof String);
        DOCKYARD_LOOT = BUILDER.defineList("dockyardLootItems", java.util.List.of("minecraft:crossbow", "minecraft:iron_axe", "minecraft:shield", "minecraft:iron_helmet", "minecraft:arrow", "minecraft:cooked_beef", "minecraft:iron_ingot"), o -> o instanceof String);
        BUNKER_LOOT = BUILDER.defineList("bunkerLootItems", java.util.List.of("minecraft:crossbow", "minecraft:diamond_sword", "minecraft:diamond_chestplate", "minecraft:golden_apple", "minecraft:arrow", "minecraft:totem_of_undying"), o -> o instanceof String);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private ArenaConfig() {}

    public static void register() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, SPEC, "tacticalarena-server.toml");
    }
}
