package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MatchFadeScreen extends Screen {
    private final String mode;
    private int age;

    public MatchFadeScreen(String mode) {
        super(Component.literal("Operation briefing"));
        this.mode = mode;
    }

    @Override
    public void tick() {
        age++;
        if (age >= 20 && minecraft != null && minecraft.screen == this) minecraft.setScreen(null);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float alpha = Math.max(0.0F, 1.0F - (age + partialTick) / 20.0F);
        int a = Math.min(255, Math.max(0, (int) (alpha * 255.0F)));
        graphics.fill(0, 0, width, height, (a << 24));
        String title = switch (mode) {
            case "ASSAULT" -> "ASSAULT — RURAL DISTRICT";
            case "HITMANIA" -> "HITMANIA — NIGHT OPERATION";
            case "BATTLE_ROYALE" -> "BATTLE ROYALE — LAST SURVIVOR";
            default -> mode;
        };
        String subtitle = switch (mode) {
            case "ASSAULT" -> "Eliminate the opponent. Every kill adds one point.";
            case "HITMANIA" -> "A city operation. Every kill adds one point.";
            case "BATTLE_ROYALE" -> "Search, survive and reach the central bunker.";
            default -> "Prepare for deployment.";
        };
        graphics.drawCenteredString(font, title, width / 2, height / 2 - 18, 0xFFFFFFFF);
        graphics.drawCenteredString(font, subtitle, width / 2, height / 2 + 2, 0xFFD5DDE5);
        graphics.drawCenteredString(font, "TAKE YOUR POSITION", width / 2, height / 2 + 22, 0xFFB5C1CC);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
}
