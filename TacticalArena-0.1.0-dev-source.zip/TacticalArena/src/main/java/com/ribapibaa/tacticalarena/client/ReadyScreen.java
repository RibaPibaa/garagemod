package com.ribapibaa.tacticalarena.client;

import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ReadyScreen extends Screen {
    public ReadyScreen() { super(Component.literal("MATCH LOBBY")); }

    @Override
    protected void init() {
        int x = width / 2 - 110;
        int y = height / 2 + 26;
        addRenderableWidget(Button.builder(Component.literal("READY"), b -> ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.ReadyC2S())).bounds(x, y, 220, 26).build());
        addRenderableWidget(Button.builder(Component.literal("STOP MATCH"), b -> ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.StopMatchC2S())).bounds(x, y + 34, 220, 22).build());
        addRenderableWidget(Button.builder(Component.literal("BACK"), b -> minecraft.setScreen(new ModeSelectScreen())).bounds(x, y + 64, 220, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(0, 0, width, height, 0xB010141B);
        graphics.drawCenteredString(font, "MATCH READY ROOM", width / 2, height / 2 - 100, 0xFFE4E8EC);
        graphics.drawCenteredString(font, "MODE: " + ArenaClientState.mode, width / 2, height / 2 - 78, 0xFFCFD8E3);
        String description = switch (ArenaClientState.mode) {
            case "ASSAULT" -> "10-minute village firefight. Infinite respawns; each kill scores one point.";
            case "HITMANIA" -> "10-minute rainy-city operation. Infinite respawns; each kill scores one point.";
            case "BATTLE_ROYALE" -> "Three arenas, one bunker, shrinking zone. Three lives; last survivor wins.";
            default -> "Prepare for deployment.";
        };
        graphics.drawCenteredString(font, description, width / 2, height / 2 - 60, 0xFF9DAAB7);
        graphics.drawCenteredString(font, "STATUS: " + ArenaClientState.phase, width / 2, height / 2 - 38, 0xFF9DAAB7);
        graphics.drawCenteredString(font, "READY (" + ArenaClientState.ready + "/2)", width / 2, height / 2 - 22, 0xFF8FE0B0);
        graphics.drawCenteredString(font, ArenaClientState.playerOne + "  " + ArenaClientState.scoreOne, width / 2, height / 2 - 6, 0xFFE4E8EC);
        graphics.drawCenteredString(font, ArenaClientState.playerTwo + "  " + ArenaClientState.scoreTwo, width / 2, height / 2 + 8, 0xFFE4E8EC);
        if (!ArenaClientState.phase.equals("LOBBY") && !ArenaClientState.phase.equals("FINISHED")) {
            graphics.drawCenteredString(font, "STARTS IN / TIME: " + ArenaClientState.seconds + "s", width / 2, height / 2 + 116, 0xFFFFD27A);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
