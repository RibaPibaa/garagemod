package com.ribapibaa.tacticalarena.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class DeathCamScreen extends Screen {
    public DeathCamScreen() { super(Component.literal("ELIMINATED")); }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, 0x66585858);
        graphics.fill(width / 2 - 145, height - 92, width / 2 + 145, height - 16, 0xB010141B);
        graphics.drawCenteredString(font, "YOU ARE DOWN", width / 2, height - 82, 0xFFFFFFFF);
        graphics.drawCenteredString(font, "ELIMINATED BY: " + ArenaClientState.killer, width / 2, height - 65, 0xFFE5B7B7);
        graphics.drawCenteredString(font, "DAMAGE DEALT: " + String.format("%.1f", ArenaClientState.damageDealt), width / 2, height - 48, 0xFFE4E8EC);
        graphics.drawCenteredString(font, "DAMAGE RECEIVED: " + String.format("%.1f", ArenaClientState.damageTaken), width / 2, height - 33, 0xFFE4E8EC);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) { return true; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
