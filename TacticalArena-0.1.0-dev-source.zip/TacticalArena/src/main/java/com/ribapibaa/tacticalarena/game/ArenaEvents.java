package com.ribapibaa.tacticalarena.game;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.world.ArenaMapGenerator;
import com.ribapibaa.tacticalarena.world.ArenaWorldManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ArenaEvents {
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) ArenaMatchManager.tick(event.getServer());
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ArenaMatchManager.onPlayerJoin(player);
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ArenaMatchManager.onLogout(player);
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ArenaMatchManager.onPlayerRespawn(player);
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        ArenaMatchManager.onPlayerDeath(event);
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        ArenaMatchManager.onPlayerHurt(event);
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer attacker)) return;
        if (!ArenaMatchManager.isPvPEnabled() || !ArenaMatchManager.isParticipant(attacker)) { event.setCanceled(true); return; }
        if (ArenaMatchManager.consumeProtectionOnAttack(attacker)) { event.setCanceled(true); return; }
        if (event.getTarget() instanceof ServerPlayer victim
                && (!ArenaMatchManager.isParticipant(victim) || ArenaMatchManager.isProtected(victim))) event.setCanceled(true);
    }

    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) return;
        if (ArenaMapGenerator.isLobbyPosition(event.getPos())) { event.setCanceled(true); return; }
        if (!ArenaMapGenerator.isArenaPosition(event.getPos())) return;
        if (!ArenaMatchManager.isPvPEnabled()) { event.setCanceled(true); return; }
        BlockState state = event.getState();
        boolean destructible = isDestructible(state);
        if (!ArenaConfig.ALLOW_DESTRUCTIBLE_BLOCKS.get() || !destructible) {
            event.setCanceled(true);
            return;
        }
        ArenaWorldManager.captureBreak(event.getPos(), state);
    }

    @SubscribeEvent
    public void onExplosion(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof net.minecraft.server.level.ServerLevel level)) return;
        java.util.Iterator<net.minecraft.core.BlockPos> iterator = event.getAffectedBlocks().iterator();
        while (iterator.hasNext()) {
            net.minecraft.core.BlockPos pos = iterator.next();
            if (!ArenaMapGenerator.isArenaPosition(pos)) continue;
            if (ArenaMapGenerator.isLobbyPosition(pos) || !ArenaMatchManager.isPvPEnabled()) { iterator.remove(); continue; }
            BlockState state = level.getBlockState(pos);
            if (!ArenaConfig.ALLOW_DESTRUCTIBLE_BLOCKS.get() || !isDestructible(state)) {
                iterator.remove();
            } else {
                ArenaWorldManager.captureBreak(pos, state);
            }
        }
    }

    private static boolean isDestructible(BlockState state) {
        return state.getBlock() instanceof GlassBlock || state.getBlock() instanceof DoorBlock
                || state.getBlock() instanceof TrapDoorBlock || state.getBlock() instanceof FenceGateBlock
                || state.getBlock() instanceof IronBarsBlock;
    }

    @SubscribeEvent
    public void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getLevel() instanceof net.minecraft.server.level.ServerLevel && ArenaMapGenerator.isArenaPosition(event.getPos())) {
            event.setCanceled(true);
        }
    }
}
