package com.ribapibaa.tacticalarena.item;

import com.ribapibaa.tacticalarena.TacticalArenaMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TacticalArenaMod.MODID);
    public static final RegistryObject<Item> ARENA_SELECTOR = ITEMS.register("arena_selector",
            () -> new ArenaSelectorItem(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
