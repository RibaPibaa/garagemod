package com.ribapibaa.tacticalarena.network;

import com.ribapibaa.tacticalarena.TacticalArenaMod;
import com.ribapibaa.tacticalarena.game.ArenaMatchManager;
import com.ribapibaa.tacticalarena.game.ArenaMatchManager.Mode;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class ArenaNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TacticalArenaMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int id = 0;

    private ArenaNetwork() {}

    public static void register() {
        CHANNEL.registerMessage(id++, SelectModeC2S.class, SelectModeC2S::encode, SelectModeC2S::decode, SelectModeC2S::handle);
        CHANNEL.registerMessage(id++, ReadyC2S.class, ReadyC2S::encode, ReadyC2S::decode, ReadyC2S::handle);
        CHANNEL.registerMessage(id++, StopMatchC2S.class, StopMatchC2S::encode, StopMatchC2S::decode, StopMatchC2S::handle);
        CHANNEL.registerMessage(id++, StateS2C.class, StateS2C::encode, StateS2C::decode, StateS2C::handle);
        CHANNEL.registerMessage(id++, DeathCamS2C.class, DeathCamS2C::encode, DeathCamS2C::decode, DeathCamS2C::handle);
    }

    public static void sendState(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), ArenaMatchManager.makeStatePacket());
    }

    public static void broadcastState(net.minecraft.server.MinecraftServer server) {
        StateS2C packet = ArenaMatchManager.makeStatePacket();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
        }
    }

    public static void sendDeathCam(ServerPlayer player, int targetId, boolean active, float dealt, float taken, String killer) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new DeathCamS2C(targetId, active, dealt, taken, killer));
    }

    public static class SelectModeC2S {
        private final String mode;
        public SelectModeC2S(String mode) { this.mode = mode; }
        public static void encode(SelectModeC2S msg, FriendlyByteBuf buf) { buf.writeUtf(msg.mode, 32); }
        public static SelectModeC2S decode(FriendlyByteBuf buf) { return new SelectModeC2S(buf.readUtf(32)); }
        public static void handle(SelectModeC2S msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                try { ArenaMatchManager.selectMode(player, Mode.valueOf(msg.mode)); }
                catch (IllegalArgumentException ignored) { }
            });
            ctx.get().setPacketHandled(true);
        }
    }

    public static class ReadyC2S {
        public static void encode(ReadyC2S msg, FriendlyByteBuf buf) { }
        public static ReadyC2S decode(FriendlyByteBuf buf) { return new ReadyC2S(); }
        public static void handle(ReadyC2S msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player != null) ArenaMatchManager.toggleReady(player);
            });
            ctx.get().setPacketHandled(true);
        }
    }

    public static class StopMatchC2S {
        public static void encode(StopMatchC2S msg, FriendlyByteBuf buf) { }
        public static StopMatchC2S decode(FriendlyByteBuf buf) { return new StopMatchC2S(); }
        public static void handle(StopMatchC2S msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player != null) ArenaMatchManager.stopMatch(player.serverLevel().getServer());
            });
            ctx.get().setPacketHandled(true);
        }
    }

    public static class StateS2C {
        public final String mode, phase, playerOne, playerTwo;
        public final int seconds, ready, scoreOne, scoreTwo;
        public StateS2C(String mode, String phase, int seconds, int ready, String playerOne, String playerTwo, int scoreOne, int scoreTwo) {
            this.mode = mode; this.phase = phase; this.seconds = seconds; this.ready = ready;
            this.playerOne = playerOne; this.playerTwo = playerTwo; this.scoreOne = scoreOne; this.scoreTwo = scoreTwo;
        }
        public static void encode(StateS2C msg, FriendlyByteBuf buf) {
            buf.writeUtf(msg.mode, 32); buf.writeUtf(msg.phase, 32); buf.writeVarInt(msg.seconds); buf.writeVarInt(msg.ready);
            buf.writeUtf(msg.playerOne, 64); buf.writeUtf(msg.playerTwo, 64); buf.writeVarInt(msg.scoreOne); buf.writeVarInt(msg.scoreTwo);
        }
        public static StateS2C decode(FriendlyByteBuf buf) {
            return new StateS2C(buf.readUtf(32), buf.readUtf(32), buf.readVarInt(), buf.readVarInt(), buf.readUtf(64), buf.readUtf(64), buf.readVarInt(), buf.readVarInt());
        }
        public static void handle(StateS2C msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.ribapibaa.tacticalarena.client.ArenaClientState.apply(msg)));
            ctx.get().setPacketHandled(true);
        }
    }

    public static class DeathCamS2C {
        public final int targetId;
        public final boolean active;
        public final float dealt, taken;
        public final String killer;
        public DeathCamS2C(int targetId, boolean active, float dealt, float taken, String killer) {
            this.targetId = targetId; this.active = active; this.dealt = dealt; this.taken = taken; this.killer = killer;
        }
        public static void encode(DeathCamS2C msg, FriendlyByteBuf buf) {
            buf.writeVarInt(msg.targetId); buf.writeBoolean(msg.active); buf.writeFloat(msg.dealt); buf.writeFloat(msg.taken); buf.writeUtf(msg.killer, 64);
        }
        public static DeathCamS2C decode(FriendlyByteBuf buf) {
            return new DeathCamS2C(buf.readVarInt(), buf.readBoolean(), buf.readFloat(), buf.readFloat(), buf.readUtf(64));
        }
        public static void handle(DeathCamS2C msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.ribapibaa.tacticalarena.client.ArenaClientState.setDeathCam(msg)));
            ctx.get().setPacketHandled(true);
        }
    }
}
