package com.ribapibaa.tacticalarena;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.game.ArenaCommands;
import com.ribapibaa.tacticalarena.game.ArenaEvents;
import com.ribapibaa.tacticalarena.item.ModItems;
import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TacticalArenaMod.MODID)
public class TacticalArenaMod {
    public static final String MODID = "tacticalarena";

    public TacticalArenaMod() {
        ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        ArenaConfig.register();
        ArenaNetwork.register();
        MinecraftForge.EVENT_BUS.register(new ArenaEvents());
        MinecraftForge.EVENT_BUS.register(new ArenaCommands());
    }
}
