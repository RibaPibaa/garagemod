package com.ribapibaa.tacticalarena.client;

import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ModeSelectScreen extends Screen {
    public ModeSelectScreen() { super(Component.literal("TACTICAL ARENA")); }

    @Override
    protected void init() {
        int x = width / 2 - 110;
        int y = height / 2 - 45;
        addRenderableWidget(Button.builder(Component.literal("ASSAULT"), b -> select("ASSAULT")).bounds(x, y, 220, 24).build());
        addRenderableWidget(Button.builder(Component.literal("HITMANIA"), b -> select("HITMANIA")).bounds(x, y + 32, 220, 24).build());
        addRenderableWidget(Button.builder(Component.literal("BATTLE ROYALE"), b -> select("BATTLE_ROYALE")).bounds(x, y + 64, 220, 24).build());
        addRenderableWidget(Button.builder(Component.literal("CLOSE"), b -> onClose()).bounds(x, y + 100, 220, 20).build());
    }

    private void select(String mode) {
        ArenaNetwork.CHANNEL.sendToServer(new ArenaNetwork.SelectModeC2S(mode));
        minecraft.setScreen(new ReadyScreen());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(0, 0, width, height, 0xB010141B);
        graphics.drawCenteredString(font, "TACTICAL ARENA", width / 2, height / 2 - 92, 0xFFE4E8EC);
        graphics.drawCenteredString(font, "SELECT OPERATION", width / 2, height / 2 - 76, 0xFF9DAAB7);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
