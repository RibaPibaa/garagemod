package com.ribapibaa.tacticalarena.game;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import com.ribapibaa.tacticalarena.item.ModItems;
import com.ribapibaa.tacticalarena.network.ArenaNetwork;
import com.ribapibaa.tacticalarena.network.ArenaNetwork.StateS2C;
import com.ribapibaa.tacticalarena.world.ArenaMapGenerator;
import com.ribapibaa.tacticalarena.world.ArenaNpcSpawner;
import com.ribapibaa.tacticalarena.world.ArenaWorldManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import java.util.*;

public final class ArenaMatchManager {
    public enum Mode { ASSAULT, HITMANIA, BATTLE_ROYALE }
    public enum Phase { LOBBY, COUNTDOWN, WARMUP, ACTIVE, FINISHED }

    private static Mode mode = Mode.ASSAULT;
    private static Phase phase = Phase.LOBBY;
    private static final Set<UUID> READY = new HashSet<>();
    private static final Map<UUID, Integer> SCORES = new HashMap<>();
    private static final Map<UUID, Integer> BR_DEATHS = new HashMap<>();
    private static final Map<UUID, CombatStats> COMBAT = new HashMap<>();
    private static final Map<UUID, DeathRecord> PENDING_RESPAWNS = new HashMap<>();
    private static final Map<UUID, Long> PROTECTED_UNTIL = new HashMap<>();
    private static long phaseEndTick;
    private static long matchEndTick;
    private static int lastSyncedSecond = -1;
    private static MinecraftServer currentServer;
    private static final Set<UUID> PARTICIPANTS = new HashSet<>();
    private static final Random RANDOM = new Random();

    private ArenaMatchManager() {}

    public static Mode getMode() { return mode; }
    public static Phase getPhase() { return phase; }
    public static boolean isActive() { return phase == Phase.ACTIVE || phase == Phase.WARMUP; }
    public static boolean isPvPEnabled() { return phase == Phase.ACTIVE; }
    public static boolean isWarmup() { return phase == Phase.WARMUP; }

    public static void selectMode(ServerPlayer player, Mode selected) {
        if (phase != Phase.LOBBY && phase != Phase.FINISHED) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("A match is already running."));
            return;
        }
        mode = selected;
        READY.clear();
        phase = Phase.LOBBY;
        sync(player.serverLevel().getServer());
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Selected mode: " + selected.name()));
    }

    public static void toggleReady(ServerPlayer player) {
        if (phase != Phase.LOBBY && phase != Phase.FINISHED && phase != Phase.COUNTDOWN) return;
        if (!READY.add(player.getUUID())) READY.remove(player.getUUID());
        MinecraftServer server = player.serverLevel().getServer();
        sync(server);
        if (READY.size() >= 2 && server.getPlayerList().getPlayers().size() >= 2) {
            if (phase != Phase.COUNTDOWN) {
                phase = Phase.COUNTDOWN;
                phaseEndTick = server.overworld().getGameTime() + ArenaConfig.READY_COUNTDOWN_SECONDS.get() * 20L;
            }
            sync(server);
        } else if (phase == Phase.COUNTDOWN) {
            phase = Phase.LOBBY;
            sync(server);
        }
    }

    public static void stopMatch(MinecraftServer server) {
        if (server == null) return;
        finishMatch(server, "Match stopped by administrator.");
    }

    public static void tick(MinecraftServer server) {
        if (server == null) return;
        currentServer = server;
        long now = server.overworld().getGameTime();
        processRespawns(server, now);

        if (phase == Phase.ACTIVE && mode == Mode.BATTLE_ROYALE) checkBattleRoyaleWinner(server);

        if (phase == Phase.COUNTDOWN && now >= phaseEndTick) {
            startWarmup(server);
        } else if (phase == Phase.WARMUP && now >= phaseEndTick) {
            beginLiveMatch(server);
        } else if (phase == Phase.ACTIVE && now >= matchEndTick) {
            finishTimedMatch(server);
        }

        if (phase == Phase.ACTIVE || phase == Phase.WARMUP || phase == Phase.COUNTDOWN) {
            int seconds = secondsRemaining(server);
            if (seconds != lastSyncedSecond) {
                lastSyncedSecond = seconds;
                sync(server);
            }
        }
    }

    private static void startWarmup(MinecraftServer server) {
        phase = Phase.WARMUP;
        currentServer = server;
        if (!ArenaMapGenerator.isGenerated()) ArenaMapGenerator.generateAll(server.overworld());
        ArenaWorldController.prepare(server, mode);
        ServerLevel level = server.overworld();
        ArenaMapGenerator.prepareMatch(mode);
        ArenaMapGenerator.setBattleRoyaleAccess(level, mode == Mode.BATTLE_ROYALE);
        ArenaNpcSpawner.populate(level, mode == Mode.BATTLE_ROYALE);
        List<ServerPlayer> players = matchPlayers(server);
        PARTICIPANTS.clear();
        for (int i = 0; i < players.size(); i++) {
            ServerPlayer player = players.get(i);
            PARTICIPANTS.add(player.getUUID());
            player.setGameMode(GameType.ADVENTURE);
            Vec3 spawn = mode == Mode.BATTLE_ROYALE ? ArenaMapGenerator.randomBattleRoyaleSpawn(level, i) : ArenaMapGenerator.spawnFor(mode, i, players.size());
            player.teleportTo(level, spawn.x, spawn.y, spawn.z, player.getYRot(), player.getXRot());
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
            player.getPersistentData().putBoolean("tacticalarena_in_match", true);
        }
        phaseEndTick = level.getGameTime() + ArenaConfig.WARMUP_SECONDS.get() * 20L;
        sync(server);
    }

    private static void beginLiveMatch(MinecraftServer server) {
        phase = Phase.ACTIVE;
        for (ServerPlayer player : matchPlayers(server)) {
            player.setGameMode(GameType.SURVIVAL);
            ArenaKitManager.giveKit(player, mode);
            player.setHealth(player.getMaxHealth());
            if (mode == Mode.BATTLE_ROYALE) {
                setMaxHealth(player, 20.0D);
                BR_DEATHS.put(player.getUUID(), 0);
            }
            COMBAT.put(player.getUUID(), new CombatStats());
        }
        matchEndTick = mode == Mode.BATTLE_ROYALE ? Long.MAX_VALUE
                : server.overworld().getGameTime() + ArenaConfig.MATCH_MINUTES.get() * 60L * 20L;
        lastSyncedSecond = -1;
        sync(server);
    }

    private static void finishTimedMatch(MinecraftServer server) {
        if (mode == Mode.BATTLE_ROYALE) {
            finishMatch(server, "Battle Royale time limit reached.");
            return;
        }
        List<ServerPlayer> players = PARTICIPANTS.stream().map(server.getPlayerList()::getPlayer).filter(Objects::nonNull).toList();
        if (players.size() < 2) {
            finishMatch(server, "Time is up.");
            return;
        }
        int first = SCORES.getOrDefault(players.get(0).getUUID(), 0);
        int second = SCORES.getOrDefault(players.get(1).getUUID(), 0);
        String result = first == second ? "Draw — " + first + ":" + second
                : "Winner: " + (first > second ? players.get(0).getGameProfile().getName() : players.get(1).getGameProfile().getName())
                + " (" + Math.max(first, second) + ":" + Math.min(first, second) + ")";
        finishMatch(server, "Time is up. " + result + ".");
    }

    private static void finishMatch(MinecraftServer server, String reason) {
        if (phase == Phase.LOBBY) return;
        phase = Phase.FINISHED;
        // If the match is stopped during a death camera, bring pending players back before lobby cleanup.
        for (UUID id : new ArrayList<>(PENDING_RESPAWNS.keySet())) {
            ServerPlayer dead = server.getPlayerList().getPlayer(id);
            if (dead != null && !dead.isAlive()) {
                ServerPlayer restored = server.getPlayerList().respawn(dead, false);
                if (restored != null) ArenaNetwork.sendDeathCam(restored, -1, false, 0, 0, "");
            }
        }
        ServerLevel level = server.overworld();
        ArenaWorldManager.restore(level);
        ArenaMapGenerator.setBattleRoyaleAccess(level, false);
        ArenaNpcSpawner.populate(level, false);
        ArenaWorldController.restore(server);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.getPersistentData().getBoolean("tacticalarena_in_match") || PARTICIPANTS.contains(player.getUUID())) {
                player.getPersistentData().putBoolean("tacticalarena_in_match", false);
                player.setGameMode(GameType.ADVENTURE);
                player.getInventory().clearContent();
                player.getInventory().add(new net.minecraft.world.item.ItemStack(ModItems.ARENA_SELECTOR.get()));
                Vec3 lobby = ArenaMapGenerator.lobbySpawn();
                player.teleportTo(level, lobby.x, lobby.y, lobby.z, player.getYRot(), player.getXRot());
                setMaxHealth(player, 20.0D);
                player.setHealth(20.0F);
                player.removeAllEffects();
                player.sendSystemMessage(net.minecraft.network.chat.Component.literal(reason + " Your score: " + SCORES.getOrDefault(player.getUUID(), 0) + "."));
            }
        }
        READY.clear(); SCORES.clear(); BR_DEATHS.clear(); COMBAT.clear(); PENDING_RESPAWNS.clear(); PROTECTED_UNTIL.clear(); PARTICIPANTS.clear();
        sync(server);
        phase = Phase.LOBBY;
        sync(server);
    }

    public static void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim) || phase != Phase.ACTIVE) return;
        UUID id = victim.getUUID();
        EntityKiller killerInfo = resolveKiller(event);
        CombatStats stats = COMBAT.getOrDefault(id, new CombatStats());
        int targetId = killerInfo.player == null ? -1 : killerInfo.player.getId();
        String killerName = killerInfo.player == null ? "Environment" : killerInfo.player.getGameProfile().getName();

        if (killerInfo.player != null && !killerInfo.player.getUUID().equals(id)) {
            SCORES.merge(killerInfo.player.getUUID(), 1, Integer::sum);
            if (mode != Mode.BATTLE_ROYALE) {
                int seconds = ArenaConfig.KILL_REGEN_SECONDS.get();
                if (seconds > 0) killerInfo.player.addEffect(new MobEffectInstance(MobEffects.REGENERATION,
                        seconds * 20, ArenaConfig.KILL_REGEN_AMPLIFIER.get(), false, true, true));
            }
            CombatStats killerStats = COMBAT.computeIfAbsent(killerInfo.player.getUUID(), k -> new CombatStats());
            killerStats.kills++;
        }

        boolean eliminated = false;
        if (mode == Mode.BATTLE_ROYALE) {
            int deaths = BR_DEATHS.merge(id, 1, Integer::sum);
            eliminated = deaths >= 3;
        }
        PENDING_RESPAWNS.put(id, new DeathRecord(victim.serverLevel(), victim.position(), killerInfo.player == null ? null : killerInfo.player.getUUID(),
                victim.serverLevel().getGameTime() + ArenaConfig.DEATHCAM_SECONDS.get() * 20L, eliminated,
                stats.damageDealt, stats.damageTaken, killerName));
        ArenaNetwork.sendDeathCam(victim, targetId, true, stats.damageDealt, stats.damageTaken, killerName);
        if (killerInfo.player != null) ArenaNetwork.sendState(killerInfo.player);
    }

    public static void onPlayerHurt(LivingHurtEvent event) {
        ServerPlayer attacker = resolveAttacker(event.getSource().getEntity());
        if (attacker != null && isProtected(attacker)) {
            removeProtection(attacker);
            event.setCanceled(true);
            return;
        }
        if (attacker != null && (!isPvPEnabled() || !isParticipant(attacker.getUUID()))) {
            event.setCanceled(true);
            return;
        }
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        if (ArenaMapGenerator.isLobbyPosition(victim.blockPosition())) {
            event.setCanceled(true);
            return;
        }
        if (phase == Phase.WARMUP) {
            event.setCanceled(true);
            return;
        }
        if (!isParticipant(victim.getUUID()) || isProtected(victim)) {
            event.setCanceled(true);
            return;
        }
        if (phase != Phase.ACTIVE) return;
        if (attacker != null && !attacker.getUUID().equals(victim.getUUID())) {
            float amount = event.getAmount();
            COMBAT.computeIfAbsent(attacker.getUUID(), k -> new CombatStats()).damageDealt += amount;
            COMBAT.computeIfAbsent(victim.getUUID(), k -> new CombatStats()).damageTaken += amount;
        }
    }

    public static boolean isProtected(ServerPlayer player) {
        Long until = PROTECTED_UNTIL.get(player.getUUID());
        if (until == null) return false;
        if (player.serverLevel().getGameTime() >= until) { PROTECTED_UNTIL.remove(player.getUUID()); return false; }
        return true;
    }

    public static void removeProtection(ServerPlayer player) { PROTECTED_UNTIL.remove(player.getUUID()); }

    private static void checkBattleRoyaleWinner(MinecraftServer server) {
        if (PARTICIPANTS.size() < 2) return;
        List<UUID> alive = PARTICIPANTS.stream().filter(id -> BR_DEATHS.getOrDefault(id, 0) < 3
                && server.getPlayerList().getPlayer(id) != null
                && !server.getPlayerList().getPlayer(id).isSpectator()).toList();
        if (alive.size() <= 1) {
            String winner = alive.isEmpty() ? "No winner" : Optional.ofNullable(server.getPlayerList().getPlayer(alive.get(0))).map(p -> p.getGameProfile().getName()).orElse("Unknown");
            finishMatch(server, "BATTLE ROYALE winner: " + winner + ".");
        }
    }

    private static void processRespawns(MinecraftServer server, long now) {
        if (PENDING_RESPAWNS.isEmpty()) return;
        Iterator<Map.Entry<UUID, DeathRecord>> iterator = PENDING_RESPAWNS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, DeathRecord> entry = iterator.next();
            DeathRecord record = entry.getValue();
            if (now < record.respawnAt) continue;
            ServerPlayer dead = server.getPlayerList().getPlayer(entry.getKey());
            iterator.remove();
            if (dead == null) continue;
            ServerPlayer respawned = server.getPlayerList().respawn(dead, false);
            if (respawned == null) continue;
            ArenaNetwork.sendDeathCam(respawned, -1, false, record.damageDealt, record.damageTaken, record.killerName);
            if (record.eliminated) {
                respawned.setGameMode(GameType.SPECTATOR);
                respawned.sendSystemMessage(net.minecraft.network.chat.Component.literal("ELIMINATED — you are out of the Battle Royale."));
                continue;
            }
            ServerLevel level = record.level;
            BlockPos safe = findSafeRespawn(level, record.deathPosition);
            respawned.teleportTo(level, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, respawned.getYRot(), respawned.getXRot());
            respawned.setGameMode(GameType.SURVIVAL);
            respawned.getAbilities().flying = false;
            respawned.onUpdateAbilities();
            if (mode == Mode.BATTLE_ROYALE) {
                int deaths = BR_DEATHS.getOrDefault(respawned.getUUID(), 0);
                double hp = deaths == 1 ? 14.0D : 8.0D;
                setMaxHealth(respawned, hp);
                respawned.setHealth((float) hp);
            } else {
                setMaxHealth(respawned, 20.0D);
                respawned.setHealth(20.0F);
            }
            int protectTicks = ArenaConfig.RESPAWN_PROTECTION_SECONDS.get() * 20;
            if (protectTicks > 0) PROTECTED_UNTIL.put(respawned.getUUID(), level.getGameTime() + protectTicks);
            COMBAT.put(respawned.getUUID(), new CombatStats());
            respawned.sendSystemMessage(net.minecraft.network.chat.Component.literal("Respawned. Protection lasts " + ArenaConfig.RESPAWN_PROTECTION_SECONDS.get() + " seconds; attacking removes it."));
        }
    }

    private static BlockPos findSafeRespawn(ServerLevel level, Vec3 death) {
        int min = ArenaConfig.RESPAWN_MIN_DISTANCE.get();
        int max = Math.max(min, ArenaConfig.RESPAWN_MAX_DISTANCE.get());
        for (int attempt = 0; attempt < 120; attempt++) {
            double angle = RANDOM.nextDouble() * Math.PI * 2.0;
            double distance = min + RANDOM.nextDouble() * (max - min);
            int x = (int) Math.floor(death.x + Math.cos(angle) * distance);
            int z = (int) Math.floor(death.z + Math.sin(angle) * distance);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos feet = new BlockPos(x, y, z);
            if (!ArenaMapGenerator.isCombatArenaPosition(feet)) continue;
            if (y <= level.getMinBuildHeight() + 1 || y >= level.getMaxBuildHeight() - 2) continue;
            if (!level.getBlockState(feet.below()).isSolidRender(level, feet.below())) continue;
            if (level.getBlockState(feet).is(net.minecraft.world.level.block.Blocks.FIRE)
                    || level.getBlockState(feet).is(net.minecraft.world.level.block.Blocks.SOUL_FIRE)) continue;
            if (!level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()) continue;
            if (!level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()) continue;
            if (!level.getFluidState(feet).isEmpty() || !level.getFluidState(feet.above()).isEmpty()) continue;
            return feet;
        }
        BlockPos[] centers = {ArenaMapGenerator.ASSAULT, ArenaMapGenerator.HITMANIA, ArenaMapGenerator.DOCKYARD, ArenaMapGenerator.BUNKER};
        BlockPos nearest = centers[0];
        double nearestDistance = Double.MAX_VALUE;
        for (BlockPos center : centers) {
            double dx = center.getX() + 0.5 - death.x;
            double dy = center.getY() - death.y;
            double dz = center.getZ() + 0.5 - death.z;
            double distance = dx * dx + dy * dy + dz * dz;
            if (distance < nearestDistance) { nearestDistance = distance; nearest = center; }
        }
        int fx = nearest.getX() + min;
        int fz = nearest.getZ();
        int fy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, fx, fz);
        return new BlockPos(fx, fy, fz);
    }

    private static EntityKiller resolveKiller(LivingDeathEvent event) {
        return new EntityKiller(resolveAttacker(event.getSource().getEntity()));
    }

    private static ServerPlayer resolveAttacker(Entity source) {
        if (source instanceof ServerPlayer player) return player;
        if (source instanceof Projectile projectile && projectile.getOwner() instanceof ServerPlayer player) return player;
        return null;
    }

    private static void setMaxHealth(ServerPlayer player, double value) {
        AttributeInstance attribute = player.getAttribute(Attributes.MAX_HEALTH);
        if (attribute != null) attribute.setBaseValue(value);
    }

    private static List<ServerPlayer> matchPlayers(MinecraftServer server) {
        return server.getPlayerList().getPlayers().stream().filter(p -> READY.contains(p.getUUID()) || p.getPersistentData().getBoolean("tacticalarena_in_match")).limit(2).toList();
    }

    private static int secondsRemaining(MinecraftServer server) {
        if (phase == Phase.ACTIVE && mode == Mode.BATTLE_ROYALE) return 0;
        long now = server.overworld().getGameTime();
        long end = phase == Phase.ACTIVE ? matchEndTick : phaseEndTick;
        return (int) Math.max(0, (end - now + 19) / 20);
    }

    private static void sync(MinecraftServer server) {
        if (server != null) {
            currentServer = server;
            ArenaNetwork.broadcastState(server);
        }
    }

    public static StateS2C makeStatePacket() {
        String one = "Player 1", two = "Player 2";
        int scoreOne = 0, scoreTwo = 0;
        int seconds = 0;
        if (currentServer != null) {
            List<ServerPlayer> players = currentServer.getPlayerList().getPlayers().stream().limit(2).toList();
            if (!players.isEmpty()) {
                one = players.get(0).getGameProfile().getName();
                scoreOne = SCORES.getOrDefault(players.get(0).getUUID(), 0);
            }
            if (players.size() > 1) {
                two = players.get(1).getGameProfile().getName();
                scoreTwo = SCORES.getOrDefault(players.get(1).getUUID(), 0);
            }
            seconds = secondsRemaining(currentServer);
        }
        return new StateS2C(mode.name(), phase.name(), seconds, READY.size(), one, two, scoreOne, scoreTwo);
    }

    public static void onPlayerJoin(ServerPlayer player) {
        if (!ArenaMapGenerator.isGenerated()) ArenaMapGenerator.generateAll(player.serverLevel().getServer().overworld());
        ensureSelector(player);
        if (phase == Phase.LOBBY || phase == Phase.FINISHED || !isParticipant(player.getUUID())) {
            player.setGameMode(GameType.ADVENTURE);
            Vec3 lobby = ArenaMapGenerator.lobbySpawn();
            player.teleportTo(player.serverLevel().getServer().overworld(), lobby.x, lobby.y, lobby.z, player.getYRot(), player.getXRot());
        }
        sync(player.serverLevel().getServer());
    }

    public static boolean consumeProtectionOnAttack(ServerPlayer player) {
        if (!isProtected(player)) return false;
        removeProtection(player);
        return true;
    }

    public static void onPlayerRespawn(ServerPlayer player) {
        if (isParticipant(player.getUUID())) return;
        ensureSelector(player);
        player.setGameMode(GameType.ADVENTURE);
        Vec3 lobby = ArenaMapGenerator.lobbySpawn();
        player.teleportTo(player.serverLevel().getServer().overworld(), lobby.x, lobby.y, lobby.z, player.getYRot(), player.getXRot());
    }

    public static boolean isParticipant(UUID id) {
        return PARTICIPANTS.contains(id);
    }

    public static boolean isParticipant(ServerPlayer player) {
        return isParticipant(player.getUUID());
    }

    private static void ensureSelector(ServerPlayer player) {
        boolean hasSelector = false;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (player.getInventory().getItem(i).is(ModItems.ARENA_SELECTOR.get())) { hasSelector = true; break; }
        }
        if (!hasSelector) player.getInventory().add(new net.minecraft.world.item.ItemStack(ModItems.ARENA_SELECTOR.get()));
    }

    public static void onLogout(ServerPlayer player) {
        READY.remove(player.getUUID());
        if (phase == Phase.COUNTDOWN && READY.size() < 2) phase = Phase.LOBBY;
        PENDING_RESPAWNS.remove(player.getUUID());
        PROTECTED_UNTIL.remove(player.getUUID());
        if (player.serverLevel() != null && player.serverLevel().getServer() != null) {
            if ((phase == Phase.ACTIVE || phase == Phase.WARMUP) && PARTICIPANTS.contains(player.getUUID())) {
                finishMatch(player.serverLevel().getServer(), player.getGameProfile().getName() + " disconnected. Match ended.");
            } else {
                sync(player.serverLevel().getServer());
            }
        }
    }

    private record DeathRecord(ServerLevel level, Vec3 deathPosition, UUID killer, long respawnAt,
                               boolean eliminated, float damageDealt, float damageTaken, String killerName) {}
    private record EntityKiller(ServerPlayer player) {}
    private static class CombatStats { float damageDealt; float damageTaken; int kills; }
}
