package com.ribapibaa.tacticalarena.game;

import com.ribapibaa.tacticalarena.config.ArenaConfig;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.List;
import java.util.Random;

public final class ArenaKitManager {
    private static final Random RANDOM = new Random();
    private ArenaKitManager() {}

    public static void giveKit(ServerPlayer player, ArenaMatchManager.Mode mode) {
        player.getInventory().clearContent();
        if (mode == ArenaMatchManager.Mode.BATTLE_ROYALE) {
            Item[] clothing = {Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS};
            int pieces = 2 + RANDOM.nextInt(3);
            for (int i = 0; i < pieces; i++) player.getInventory().add(new ItemStack(clothing[RANDOM.nextInt(clothing.length)]));
            Item[] melee = {Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD, Items.IRON_AXE};
            player.getInventory().add(new ItemStack(melee[RANDOM.nextInt(melee.length)]));
        }
        List<? extends String> ids = switch (mode) {
            case ASSAULT -> ArenaConfig.ASSAULT_KIT.get();
            case HITMANIA -> ArenaConfig.HITMANIA_KIT.get();
            case BATTLE_ROYALE -> ArenaConfig.BR_STARTER_KIT.get();
        };
        for (String id : ids) addById(player, id, mode);
        if (mode == ArenaMatchManager.Mode.HITMANIA) {
            for (String id : ArenaConfig.HITMANIA_CLOTHING.get()) addById(player, id, mode);
            for (String id : ArenaConfig.HITMANIA_MEDICAL.get()) addById(player, id, mode);
        } else if (mode == ArenaMatchManager.Mode.ASSAULT) {
            for (String id : ArenaConfig.ASSAULT_MEDICAL.get()) addById(player, id, mode);
        }
        player.getInventory().setChanged();
    }

    private static void addById(ServerPlayer player, String id, ArenaMatchManager.Mode mode) {
        ResourceLocation key = ResourceLocation.tryParse(id);
        if (key == null) return;
        Item item = BuiltInRegistries.ITEM.getOptional(key).orElse(Items.AIR);
        if (item == Items.AIR) return;
        ItemStack stack = new ItemStack(item);
        if (item == Items.COOKED_BEEF) stack.setCount(mode == ArenaMatchManager.Mode.ASSAULT ? 20 : 4);
        if (item == Items.BREAD) stack.setCount(mode == ArenaMatchManager.Mode.BATTLE_ROYALE ? 6 : 4);
        if (item == Items.GOLDEN_APPLE && mode == ArenaMatchManager.Mode.HITMANIA) stack.setCount(2);
        player.getInventory().add(stack);
    }
}
