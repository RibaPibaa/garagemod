package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.lang.reflect.Method;
import java.util.*;

/** Runtime registry scanner for themed loot, complete wearable sets and optional TaCZ integration. */
public final class LootScanner {
    private LootScanner() {}

    public record ScanSummary(int total, Map<String, Integer> byMod) {}
    public record LootResult(List<ItemStack> items, boolean includesWearableSet) {}

    public enum LootProfile {
        GENERAL, GARAGE, LUXURY, PARK, SCRAPYARD, MATRIX, CASTLE,
        APARTMENTS, CITY_SMALL_HOUSE, CITY_LUXURY, CITY_CHEMICAL,
        CITY_HIGHRISE, CITY_CORPORATE
    }

    private enum ClothingSlot { HEAD, CHEST, LEGS, FEET, HANDS }
    private enum Category { FOOD, CLOTHING, ARMOR, MELEE, FIREARMS, TECH, POTIONS, SERUMS, SPECIAL, MISC, VEHICLE }
    private record TaczGun(ResourceLocation gunId, ResourceLocation ammoId) {}
    private record BundleRule(String primaryPattern, List<String> componentPatterns) {}

    private static final List<Item> COMMON = new ArrayList<>();
    private static final List<Item> CLOTHING = new ArrayList<>();
    private static final List<Item> VEHICLE = new ArrayList<>();
    private static final List<Item> VALUABLE = new ArrayList<>();
    private static final List<Item> WEAPONS = new ArrayList<>();
    private static final List<Item> FOOD = new ArrayList<>();
    private static final List<Item> ARMOR = new ArrayList<>();
    private static final List<Item> MELEE = new ArrayList<>();
    private static final List<Item> FIREARMS = new ArrayList<>();
    private static final List<Item> TECH = new ArrayList<>();
    private static final List<Item> POTIONS = new ArrayList<>();
    private static final List<Item> SERUMS = new ArrayList<>();
    private static final List<Item> SPECIAL = new ArrayList<>();
    private static final List<Item> LOW_QUALITY = new ArrayList<>();
    private static final List<Item> MISC = new ArrayList<>();
    private static final List<List<Item>> CLOTHING_SETS = new ArrayList<>();
    private static final List<List<Item>> HERO_ARMOR_SETS = new ArrayList<>();
    private static final Set<Item> HERO_ARMOR_ITEMS = Collections.newSetFromMap(new IdentityHashMap<>());
    private static final Map<Item, List<List<Item>>> RELATED_COMPONENTS = new IdentityHashMap<>();
    private static final Map<Item, List<ItemStack>> EXACT_RELATED_COMPONENTS = new IdentityHashMap<>();
    private static final List<TaczGun> TACZ_GUNS = new ArrayList<>();

    private static final float DEFAULT_SPECIAL_CHANCE = 0.055f;
    private static final float SCRAP_SPECIAL_CHANCE = 0.025f;
    private static boolean scanned;

    // Potato v2 registers most heroes as one-piece Palladium chest/head armor items.
    // These are complete hero suits, not ordinary clothing.
    private static final Set<String> POTATO_HERO_ARMOR_PATHS = Set.of(
            "aquaman", "atom", "b_nova", "batman_bale", "batman_beyond", "batman_comics",
            "black_flash", "blackadam_comics", "blackadam_dceu", "cyborgsuperman_comics",
            "flash_black_chestplate", "flash_chestplate", "flash_comics", "hawkgirl", "ikaris",
            "invincible_chestplate", "martian_chestplate", "martian_com", "omniman", "rf",
            "sb_solar", "shazam_comics", "shazam_dceu", "sup_com", "superboy", "superman_beyond",
            "superman_chestplate", "superman_cw", "superman_cw_black", "superman_dceu_chestplate",
            "superman_kingdomcom", "superman_redson", "superman_snyder_chestplate", "thragg",
            "vision_comics", "wonder_women", "y_nova", "zoom"
    );

    // FSang18 includes authored chest-only suits (including Hulkbusters); these are complete one-piece suit drops.
    private static final Set<String> FSANG_SINGLE_PIECE_HERO_ARMOR = Set.of(
            "deadpool_welsh_chestplate",
            "fantastic_four_ff_chestplate2", "fantastic_four_ff_chestplate3", "fantastic_four_ff_chestplate4",
            "fantastic_four_mcu_ben_chestplate", "fantastic_four_mcu_johnny_chestplate",
            "fantastic_four_mcu_reed_chestplate", "fantastic_four_mcu_sue_chestplate",
            "picotech_chestplate", "picotech_chestplate2",
            "superboy_yj_chestplate", "superboy_yj2_chestplate", "wolverine2_chestplate",
            "iron_man_model_13_hb_chestplate", "iron_man_model_44_hb_chestplate",
            "iron_man_model_71_chestplate"
    );
    public static synchronized ScanSummary scan() {
        for (List<Item> pool : allPools()) pool.clear();
        CLOTHING_SETS.clear();
        HERO_ARMOR_SETS.clear();
        HERO_ARMOR_ITEMS.clear();
        RELATED_COMPONENTS.clear();
        EXACT_RELATED_COMPONENTS.clear();
        TACZ_GUNS.clear();

        Map<String, Integer> counts = new TreeMap<>();
        Map<String, EnumMap<EquipmentSlot, Item>> heroArmorSets = new HashMap<>();
        Map<String, List<Item>> onePieceHeroSetPieces = new HashMap<>();
        Map<String, EnumMap<ClothingSlot, Item>> clothingSets = new HashMap<>();
        List<Item> onePieceOutfits = new ArrayList<>();
        List<Item> allItems = new ArrayList<>();

        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id == null || item == Items.AIR || excluded(id)) continue;
            counts.merge(id.getNamespace(), 1, Integer::sum);
            allItems.add(item);
            String path = id.getPath().toLowerCase(Locale.ROOT);

            // Hero suits from Palladium addons are classified before generic clothing/armor.
            // This prevents their individual pieces from entering the random item pool.
            if (isHeroArmorItem(id, item, path)) {
                HERO_ARMOR_ITEMS.add(item);
                String setKey = id.getNamespace() + ":" + armorSetName(path);

                if ("potato".equals(id.getNamespace()) && POTATO_HERO_ARMOR_PATHS.contains(path)) {
                    HERO_ARMOR_SETS.add(List.of(item));
                    onePieceHeroSetPieces.put(setKey, List.of(item));
                    continue;
                }
                if ("fsang".equals(id.getNamespace()) && FSANG_SINGLE_PIECE_HERO_ARMOR.contains(path)) {
                    HERO_ARMOR_SETS.add(List.of(item));
                    onePieceHeroSetPieces.put(setKey, List.of(item));
                    continue;
                }

                EquipmentSlot slot = armorEquipmentSlot(item, path);
                if (slot != null) {
                    heroArmorSets.computeIfAbsent(setKey, k -> new EnumMap<>(EquipmentSlot.class)).put(slot, item);
                }
                continue;
            }

            if (item.isEdible()) FOOD.add(item);
            if (item instanceof PotionItem || isPotionItem(path)) POTIONS.add(item);
            if (isSerumItem(path) && !isUnusableSerumIngredient(path)) SERUMS.add(item);
            if (isSpecialItem(path)) SPECIAL.add(item);
            if (isVehicleItem(path)) VEHICLE.add(item);
            if (isTechItem(path)) TECH.add(item);
            if (isFirearmItem(path, id.getNamespace())) { FIREARMS.add(item); WEAPONS.add(item); }
            if (isMeleeItem(path, id.getNamespace())) { MELEE.add(item); WEAPONS.add(item); }
            if (isValuableItem(path)) VALUABLE.add(item);

            if (item instanceof ArmorItem) {
                ARMOR.add(item);
                continue;
            }

            COMMON.add(item);
            if (isWearableClothing(path)) {
                CLOTHING.add(item);
                ClothingSlot slot = clothingSlot(path);
                if (slot != null) {
                    String setName = clothingSetName(path, slot);
                    String key = id.getNamespace() + ":" + (setName.isBlank() ? path : setName);
                    clothingSets.computeIfAbsent(key, k -> new EnumMap<>(ClothingSlot.class)).put(slot, item);
                } else if (isOnePieceOutfit(path)) {
                    onePieceOutfits.add(item);
                }
            }
            if (isLowQualityItem(path)) LOW_QUALITY.add(item);
            if (!item.isEdible() && !(item instanceof PotionItem) && !isPotionItem(path) && !isSerumItem(path)
                    && !isSpecialItem(path) && !isVehicleItem(path) && !isTechItem(path)
                    && !isFirearmItem(path, id.getNamespace()) && !isMeleeItem(path, id.getNamespace())
                    && !isWearableClothing(path)) MISC.add(item);
        }

        // Ensure the scrapyard always has a dependable pool of genuinely low-value vanilla clutter.
        for (Item junk : List.of(Items.ROTTEN_FLESH, Items.LEATHER, Items.STRING, Items.BONE, Items.FLINT,
                Items.COPPER_INGOT, Items.IRON_NUGGET, Items.PAPER, Items.STICK, Items.GUNPOWDER))
            if (!LOW_QUALITY.contains(junk)) LOW_QUALITY.add(junk);

        // Respect suit-set sizes authored by FSang18/Throg (2–4 pieces), plus explicit one-piece suits.
        // Other hero armor groups need at least three distinct equipment slots to avoid partial drops.
        Map<String, List<Item>> heroSetPieces = new HashMap<>(onePieceHeroSetPieces);
        for (Map.Entry<String, EnumMap<EquipmentSlot, Item>> entry : heroArmorSets.entrySet()) {
            EnumMap<EquipmentSlot, Item> set = entry.getValue();
            boolean authoredShortSet = entry.getKey().startsWith("fsang:") || entry.getKey().startsWith("throgaddon:");
            if (set.size() >= 3 || (authoredShortSet && set.size() == 2)) {
                List<Item> pieces = new ArrayList<>();
                for (EquipmentSlot slot : List.of(EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                        EquipmentSlot.LEGS, EquipmentSlot.FEET)) {
                    Item piece = set.get(slot);
                    if (piece != null) pieces.add(piece);
                }
                if (pieces.size() >= 2) {
                    HERO_ARMOR_SETS.add(pieces);
                    heroSetPieces.put(entry.getKey(), pieces);
                }
            } else if (set.size() == 1 && isOnePieceHeroArmorSet(entry.getKey(), set.values().iterator().next())) {
                List<Item> pieces = new ArrayList<>(set.values());
                HERO_ARMOR_SETS.add(pieces);
                heroSetPieces.put(entry.getKey(), pieces);
            }
        }

        // Clothing outfits remain their own category and can never be mistaken for hero armor.
        for (EnumMap<ClothingSlot, Item> set : clothingSets.values()) {
            if (set.size() >= 2) CLOTHING_SETS.add(new ArrayList<>(set.values()));
        }
        for (Item outfit : onePieceOutfits) CLOTHING_SETS.add(List.of(outfit));

        buildRelatedItemBundles(allItems, heroSetPieces);
        scanTaczGuns();
        scanned = true;

        int setPieceCount = HERO_ARMOR_SETS.stream().mapToInt(List::size).sum()
                + CLOTHING_SETS.stream().mapToInt(List::size).sum();
        return new ScanSummary(COMMON.size() + ARMOR.size() + setPieceCount,
                Collections.unmodifiableMap(counts));
    }

    private static List<List<Item>> allPools() {
        return List.of(COMMON, CLOTHING, VEHICLE, VALUABLE, WEAPONS, FOOD, ARMOR, MELEE,
                FIREARMS, TECH, POTIONS, SERUMS, SPECIAL, LOW_QUALITY, MISC);
    }

    private static void buildRelatedItemBundles(List<Item> allItems, Map<String, List<Item>> heroSetPieces) {
        Map<String, List<Item>> byNamespace = new HashMap<>();
        for (Item item : allItems) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id != null) byNamespace.computeIfAbsent(id.getNamespace(), k -> new ArrayList<>()).add(item);
        }

        // Exact bundles are built from the real item IDs in the uploaded addon JARs.
        for (Map.Entry<String, List<Item>> entry : heroSetPieces.entrySet()) {
            List<ItemStack> components = componentsForHeroSet(entry.getKey());
            if (components.isEmpty()) continue;
            for (Item piece : entry.getValue()) addExactRelatedComponents(piece, components);
        }

        // Keep the previous same-mod matching for other installed addons (not the three
        // explicitly mapped superhero addons, whose bundles must not be guessed).
        for (Item primary : allItems) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(primary);
            if (id == null || Set.of("fsang", "throgaddon", "potato").contains(id.getNamespace())) continue;
            List<List<String>> patterns = relatedComponentPatterns(id.getPath().toLowerCase(Locale.ROOT));
            if (patterns.isEmpty()) continue;
            List<List<Item>> matchedGroups = new ArrayList<>();
            List<Item> sameModItems = byNamespace.getOrDefault(id.getNamespace(), List.of());
            for (List<String> groupPatterns : patterns) {
                List<Item> candidates = new ArrayList<>();
                for (Item candidate : sameModItems) {
                    if (candidate == primary || HERO_ARMOR_ITEMS.contains(candidate)) continue;
                    ResourceLocation componentId = BuiltInRegistries.ITEM.getKey(candidate);
                    if (componentId == null) continue;
                    String componentPath = componentId.getPath().toLowerCase(Locale.ROOT);
                    if (groupPatterns.stream().anyMatch(pattern -> pattern.startsWith("=")
                            ? componentPath.equals(pattern.substring(1)) : componentPath.contains(pattern))) {
                        candidates.add(candidate);
                    }
                }
                if (!candidates.isEmpty()) matchedGroups.add(candidates);
            }
            if (!matchedGroups.isEmpty()) RELATED_COMPONENTS.put(primary, matchedGroups);
        }
    }

    private static void addExactRelatedComponents(Item primary, List<ItemStack> components) {
        List<ItemStack> stored = EXACT_RELATED_COMPONENTS.computeIfAbsent(primary, k -> new ArrayList<>());
        for (ItemStack component : components) {
            if (component == null || component.isEmpty()) continue;
            boolean duplicate = stored.stream().anyMatch(existing ->
                    existing.getItem() == component.getItem() && ItemStack.isSameItemSameTags(existing, component));
            if (!duplicate) stored.add(component.copy());
        }
    }

    private static List<ItemStack> componentsForHeroSet(String setKey) {
        int split = setKey.indexOf(':');
        if (split < 0) return List.of();
        String namespace = setKey.substring(0, split);
        String setName = setKey.substring(split + 1).toLowerCase(Locale.ROOT);
        List<ItemStack> out = new ArrayList<>();

        if ("fsang".equals(namespace)) {
            return fsangComponentsForSet(setName);
        }

        if ("throgaddon".equals(namespace)) {
            if (setName.contains("miles")) {
                addIfPresent(out, "throgaddon:spidermanmiles_dna_syringe");
            } else if (setName.contains("spider")) {
                addIfPresent(out, "throgaddon:spiderman_dna_syringe");
            }
            if (setName.contains("insomniac")) addIfPresent(out, "throgaddon:iron_spider_backpack");
            if (setName.startsWith("wolverine")) {
                addIfPresent(out, "throgaddon:bone_claws_dna_syringe");
                addIfPresent(out, "throgaddon:regenaration_dna_syringe");
                addIfPresent(out, "throgaddon:adamantium_syringe");
            } else if ("cyclops".equals(setName)) {
                addIfPresent(out, "throgaddon:cyclops_dna_syringe");
            } else if ("magneto".equals(setName)) {
                addIfPresent(out, "throgaddon:magnetism_dna_syringe");
            } else if (setName.startsWith("deadpool")) {
                addIfPresent(out, "throgaddon:regenaration_dna_syringe");
            }
            return out;
        }

        // Potato suits are self-contained Palladium armor items. Their abilities are supplied
        // by the suit item itself; the addon does not define a required serum for those suits.
        return out;
    }

    private static int ironManReactorTier(String setName) {
        if (setName.contains("model_63")) return 4;
        if (setName.contains("model_70") || setName.contains("dragon_slayer") || setName.contains("model_thdr")) return 3;
        if (setName.equals("iron_man_model_1") || setName.equals("iron_man_model_1_mk_3")
                || setName.equals("iron_man_mk1") || setName.matches("iron_man_model_(2|3|4|6|7|8|9)")
                || setName.startsWith("iron_man_base_")) return 1;
        return 2;
    }

    private static List<ItemStack> fsangComponentsForSet(String setName) {
        List<ItemStack> out = new ArrayList<>();

        if ("iron_man_mark_50".equals(setName)) {
            addIfPresent(out, "fsang:iron_man_core_mark_50");
        } else if ("iron_man_model_50".equals(setName)) {
            addIfPresent(out, "fsang:iron_man_nano_50");
        } else if ("iron_man_model_37".equals(setName)) {
            addIfPresent(out, "fsang:iron_man_nano_37");
        } else if (setName.startsWith("iron_man_model_") || setName.startsWith("iron_man_base_")
                || setName.equals("iron_man_mk1") || setName.startsWith("iron_heart_model_")
                || setName.startsWith("iron_patriot_model_") || setName.startsWith("war_machine_model_")
                || setName.startsWith("rescue_model_")) {
            addIfPresent(out, "fsang:iron_man_arc_reactor_" + ironManReactorTier(setName));
        }

        ItemStack serum = fsangSerumForSet(setName);
        if (!serum.isEmpty()) out.add(serum);

        if (setName.startsWith("spiderman") || setName.startsWith("spiderwoman")
                || setName.startsWith("iron_spider")) {
            addFirstPresent(out, "fsang:web_shooters", "fsang:web_shooters2", "fsang:web_shooters3");
        }
        if (setName.startsWith("batman") || setName.startsWith("batgirl") || setName.startsWith("robin")) {
            String belt = null;
            if (setName.contains("batman_beyond")) belt = "fsang:batman_beyond_belt";
            else if (setName.contains("batman_kryptonite")) belt = "fsang:batman_kryptonite_belt";
            else if (setName.contains("batman_absolute")) belt = "fsang:batman_absolute_belt";
            else if (setName.contains("batman_dk")) belt = "fsang:batman_dk_belt";
            else if (setName.contains("batgirl_cain")) belt = "fsang:batgirl_cain_belt";
            else if (setName.contains("batgirl_sb")) belt = "fsang:batgirl_sb_belt";
            else if (setName.contains("robin_damian")) belt = "fsang:robin_damian_belt";
            else if (setName.contains("robin_tim")) belt = "fsang:robin_tim_belt";
            else if (setName.contains("robin_young_justice")) belt = "fsang:robin_young_justice_belt";
            if (belt != null) addIfPresent(out, belt);
            addIfPresent(out, "fsang:batarang");
            addIfPresent(out, "fsang:bat_gun");
        }
        if (setName.startsWith("captain_america") || setName.startsWith("usagent"))
            addIfPresent(out, "fsang:captain_america_shield");
        if (setName.startsWith("falcon")) {
            if (setName.contains("vibranium")) addFirstPresent(out, "fsang:falcon_wings_vibranium", "fsang:falcon_wings");
            else addIfPresent(out, "fsang:falcon_wings");
        }
        if (setName.contains("blue_beetle"))
            addFirstPresent(out, "fsang:scarab_blue", "fsang:scarab_green", "fsang:scarab_red");
        if (setName.contains("beta_ray_bill"))
            addIfPresent(out, "fsang:stormbreaker");
        else if (setName.startsWith("mighty_thor"))
            addIfPresent(out, "fsang:mjolnir_mcu");
        else if (setName.startsWith("thor"))
            addIfPresent(out, "fsang:mjolnir");
        if (setName.startsWith("aquaman") || setName.startsWith("atlantean") || setName.startsWith("aqualad")
                || setName.startsWith("mera") || setName.startsWith("namor"))
            addIfPresent(out, "fsang:neptune_trident");
        if (setName.startsWith("shazam") || setName.startsWith("blackadam") || setName.startsWith("black_adam"))
            addIfPresent(out, "fsang:shazam_staff");
        if (setName.startsWith("ghost") || setName.contains("ghost_rider"))
            addIfPresent(out, "fsang:spirit_of_vengence_contract");
        if (setName.startsWith("winter_soldier")) {
            if (setName.contains("vibranium")) addFirstPresent(out, "fsang:winter_soldier_arm_vibranium", "fsang:winter_soldier_arm");
            else addIfPresent(out, "fsang:winter_soldier_arm");
        }
        if (setName.startsWith("green_goblin")) addIfPresent(out, "fsang:pumpkin_bomb");

        return out;
    }

    private static void addFirstPresent(List<ItemStack> out, String... ids) {
        for (String id : ids) {
            ItemStack stack = stackForId(id);
            if (!stack.isEmpty()) {
                out.add(stack);
                return;
            }
        }
    }

    private static ItemStack fsangSerumForSet(String setName) {
        String power = null;
        int model = 0;
        String variant = null;

        if (setName.startsWith("invincible")) {
            power = "fsang:viltrumite_human"; model = 11;
        } else if (setName.startsWith("viltrumite_brute")) {
            power = "fsang:viltrumite_brute"; model = 11;
        } else if (setName.startsWith("viltrumite_scout")) {
            power = "fsang:viltrumite_scout"; model = 11;
        } else if (setName.startsWith("viltrumite_thraxan")) {
            power = "fsang:viltrumite_thraxan"; model = 11;
        } else if (setName.contains("omniman") || setName.startsWith("viltrumite")) {
            power = "fsang:viltrumite"; model = 11;
        } else if (setName.startsWith("iron_spider")) {
            power = setName.contains("miles") ? "fsang:spiderman_miles" : "fsang:spiderman"; model = 3;
        } else if (setName.startsWith("spiderman_miles")) {
            power = "fsang:spiderman_miles"; model = 3;
        } else if (setName.contains("spiderman_2099")) {
            power = "fsang:spiderman_miguel"; model = 3;
        } else if (setName.contains("spiderman_jessica")) {
            power = "fsang:spiderman_jessica"; model = 3;
        } else if (setName.contains("spiderman_kaine")) {
            power = "fsang:spiderman_kaine"; model = 3;
        } else if (setName.contains("spiderman_miguel")) {
            power = "fsang:spiderman_miguel"; model = 3;
        } else if (setName.contains("spiderman_silk")) {
            power = "fsang:spiderman_silk"; model = 3;
        } else if (setName.contains("spiderwoman_gwen")) {
            power = "fsang:spiderman"; model = 3;
        } else if (setName.startsWith("spiderman")) {
            power = "fsang:spiderman"; model = 3;
        } else if (setName.startsWith("black_flash")) {
            power = "fsang:speedforce_leech"; model = 9;
        } else if (setName.startsWith("reverse_flash") || setName.startsWith("red_death")
                || setName.startsWith("zoom")) {
            power = "fsang:speedforce_negative"; model = 9;
        } else if (setName.contains("flash_tachyon") || setName.startsWith("godspeed")) {
            power = "fsang:speedforce_tachyon"; model = 8;
        } else if (setName.contains("flash_god")) {
            power = "fsang:speedforce_god"; model = 8;
        } else if (setName.contains("flash_strength")) {
            power = "fsang:speedforce_strength"; model = 8;
        } else if (setName.contains("flash_speed")) {
            power = "fsang:speedforce_speed"; model = 8;
        } else if (setName.startsWith("flash") || setName.startsWith("impulse")
                || setName.startsWith("kid_flash") || setName.startsWith("red_rush")
                || setName.startsWith("tornado_twins")) {
            power = "fsang:speedforce"; model = 8;
        } else if (setName.startsWith("a_train")) {
            power = "fsang:speed_mutation"; model = 2;
        } else if (setName.startsWith("superboy_yj")) {
            power = "fsang:kryptonian_half_yj"; model = 7;
        } else if (setName.startsWith("superboy")) {
            power = "fsang:kryptonian_half"; model = 7;
        } else if (setName.startsWith("superman_cw")) {
            power = "fsang:kryptonian_cw"; model = 6;
        } else if (setName.startsWith("superman_dceu") || setName.startsWith("supergirl_dceu")) {
            power = "fsang:kryptonian_dceu"; model = 6;
        } else if (setName.startsWith("superman_black") || setName.startsWith("superman_absolute")) {
            return ItemStack.EMPTY; // These variants receive their ability directly from their suit item.
        } else if (setName.startsWith("superman") || setName.startsWith("supergirl")) {
            power = "fsang:kryptonian"; model = 6;
        } else if (setName.startsWith("wolverine3")) {
            power = "fsang:wolverine3"; model = 2;
        } else if (setName.startsWith("wolverine2")) {
            power = "fsang:wolverine2"; model = 2;
        } else if (setName.startsWith("wolverine")) {
            power = "fsang:wolverine"; model = 2;
        } else if (setName.startsWith("cyclops")) {
            power = "fsang:cyclops"; model = 2;
        } else if (setName.startsWith("magneto")) {
            power = "fsang:magnetism"; model = 2;
        } else if (setName.startsWith("mighty_thor") || setName.startsWith("thor")) {
            power = "fsang:asgardian"; model = 4;
        } else if (setName.startsWith("beta_ray_bill")) {
            power = "fsang:asgardian3"; model = 4;
        } else if (setName.startsWith("aquaman") || setName.startsWith("aqualad")
                || setName.startsWith("atlantean") || setName.startsWith("mera") || setName.startsWith("namor")) {
            power = "fsang:atlantean"; model = 5;
        } else if (setName.startsWith("homelander")) {
            power = "fsang:homelander"; model = 13;
        } else if (setName.startsWith("soldier_boy")) {
            power = "fsang:soldier_boy"; model = 13;
        } else if (setName.startsWith("translucent")) {
            power = "fsang:translucent"; model = 13;
        } else if (setName.startsWith("hulk_red")) {
            power = "fsang:hulk_red"; model = 14;
        } else if (setName.startsWith("hulk_controlled")) {
            power = "fsang:hulk_controlled"; model = 14;
        } else if (setName.startsWith("hulk") || setName.startsWith("she_hulk")) {
            power = "fsang:hulk"; model = 14;
        } else if (setName.startsWith("wonder_woman")) {
            power = "fsang:amazon"; model = 12;
        } else if (setName.startsWith("shazam") || setName.startsWith("blackadam") || setName.startsWith("black_adam")) {
            power = "fsang:shazam"; model = 0;
        } else if (setName.startsWith("sentry")) {
            power = "fsang:sentry"; model = 0;
        } else if (setName.startsWith("storm")) {
            power = "fsang:storm"; model = 2;
        } else if (setName.startsWith("winter_soldier")) {
            power = "fsang:super_soldier_winter_soldier"; model = 10;
        } else if (setName.startsWith("apocalypse")) {
            power = "fsang:apocalypse"; model = 2;
        } else if (setName.startsWith("blue_marvel")) {
            power = "fsang:anti_matter"; model = 0;
        } else if (setName.startsWith("booster_gold") || setName.startsWith("loki") || setName.startsWith("sylvie")) {
            power = "fsang:time"; model = 2;
        } else if (setName.startsWith("captain_america") || setName.startsWith("usagent")) {
            power = "fsang:super_soldier"; model = 10;
        } else if (setName.startsWith("captain_marvel")) {
            power = "fsang:kree_hybrid"; model = 0;
        } else if (setName.startsWith("colossus") || setName.startsWith("fantastic_four_mcu_ben")) {
            power = "fsang:colossus"; model = 2;
        } else if (setName.startsWith("daredevil")) {
            power = "fsang:daredevil"; model = 0;
        } else if (setName.startsWith("deadpool")) {
            power = "fsang:regenerative_healing"; model = 2;
        } else if (setName.startsWith("gambit")) {
            power = "fsang:gambit"; model = 2;
        } else if (setName.startsWith("iceman") || setName.startsWith("killer_frost")) {
            power = "fsang:cryokinesis"; model = 2;
        } else if (setName.startsWith("jean_grey")) {
            power = setName.contains("dark_phoenix") || setName.contains("phoenix")
                    ? "fsang:reality_warping" : "fsang:telep_telek";
            model = 2;
        } else if (setName.startsWith("magik") || setName.startsWith("nightcrawler")) {
            power = "fsang:teleportation"; model = 2; variant = setName.startsWith("magik") ? "red" : "blue";
        } else if (setName.startsWith("martian_manhunter") || setName.startsWith("miss_martian")) {
            power = "fsang:martian_green"; model = 0;
        } else if (setName.startsWith("mimic")) {
            power = "fsang:mimicry"; model = 2;
        } else if (setName.startsWith("mr_fantastic") || setName.startsWith("ms_marvel")
                || setName.startsWith("fantastic_four_mcu_reed")) {
            power = "fsang:size_change"; model = 2;
        } else if (setName.startsWith("fantastic_four_mcu_johnny")) {
            power = "fsang:human_torch"; model = 15;
        } else if (setName.startsWith("fantastic_four_mcu_sue") || setName.startsWith("sue_storm")) {
            power = "fsang:invisible_woman"; model = 15;
        } else if (setName.startsWith("professor_x")) {
            power = "fsang:telepathy"; model = 2;
        } else if (setName.startsWith("raven") || setName.startsWith("scarlet_witch")
                || setName.startsWith("zatana")) {
            power = "fsang:reality_warping"; model = 2;
        } else if (setName.startsWith("red_rush")) {
            power = "fsang:speedforce"; model = 8;
        } else if (setName.startsWith("sabretooth")) {
            power = "fsang:sabretooth"; model = 2;
        } else if (setName.startsWith("static_shock")) {
            power = "fsang:electrokinesis"; model = 2;
        } else if (setName.startsWith("vulcan")) {
            power = "fsang:vulcan"; model = 2;
        } else if (setName.startsWith("green_goblin")) {
            power = "fsang:super_soldier_goblin"; model = 10;
        } else if (setName.startsWith("red_skull")) {
            power = "fsang:super_soldier_red_skull"; model = 10;
        } else if (setName.startsWith("rexsplode")) {
            power = "fsang:self_detonation"; model = 2;
        } else if (setName.startsWith("forgetmenot")) {
            power = "fsang:forgetmenot"; model = 2;
        } else if (setName.startsWith("angel")) {
            power = "fsang:angel"; model = 2;
        } else if (setName.startsWith("lobo")) {
            power = "fsang:lobo"; model = 0;
        } else if (setName.startsWith("sandman")) {
            power = "fsang:sandman"; model = 0;
        }

        if (power == null) return ItemStack.EMPTY;
        ItemStack syringe = stackForId("fsang:syringe_filled");
        if (syringe.isEmpty()) return ItemStack.EMPTY;
        CompoundTag tag = syringe.getOrCreateTag();
        tag.putString("fsang_stored_power", power);
        tag.putInt("CustomModelData", model);
        if (variant != null) tag.putString("fsang_stored_variant", variant);
        return syringe;
    }

    private static void addIfPresent(List<ItemStack> out, String itemId) {
        ItemStack stack = stackForId(itemId);
        if (!stack.isEmpty()) out.add(stack);
    }

    private static ItemStack stackForId(String itemId) {
        ResourceLocation id = ResourceLocation.tryParse(itemId);
        if (id == null) return ItemStack.EMPTY;
        Item item = BuiltInRegistries.ITEM.get(id);
        return item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item);
    }

    private static List<List<String>> relatedComponentPatterns(String path) {
        if ((path.contains("iron_man") || path.contains("ironman") || path.contains("iron-man") || path.startsWith("mark_"))
                && (path.contains("suit") || path.contains("armor") || path.contains("armour") || path.contains("costume")
                    || path.contains("helmet") || path.contains("chestplate") || path.contains("leggings") || path.contains("boots")))
            return List.of(List.of("reactor", "arc_reactor", "power_core"));

        if (path.contains("lantern") && (path.contains("suit") || path.contains("armor") || path.contains("armour")
                || path.contains("costume") || path.contains("helmet") || path.contains("chestplate")
                || path.contains("leggings") || path.contains("boots"))) {
            for (String colour : List.of("green", "blue", "red", "orange", "yellow")) {
                if (path.contains(colour + "_lantern"))
                    return List.of(List.of("=" + colour + "_lantern_ring"), List.of("=" + colour + "_lantern"),
                            List.of("=" + colour + "_lantern_power_battery"));
            }
            return List.of(List.of("=lantern_ring"));
        }

        if ((path.contains("invincible") || path.contains("omniman") || path.contains("omni_man") || path.contains("viltrumite"))
                && (path.contains("suit") || path.contains("armor") || path.contains("armour")
                || path.contains("costume") || path.contains("helmet") || path.contains("chestplate") || path.contains("leggings") || path.contains("boots")))
            return List.of(List.of("serum", "compound", "viltrum", "vial"));

        if (path.contains("reverse_flash") && (path.contains("suit") || path.contains("armor") || path.contains("armour")
                || path.contains("costume") || path.contains("helmet") || path.contains("chestplate") || path.contains("leggings") || path.contains("boots")))
            return List.of(List.of("=reverse_flash_ring"), List.of("=flash_shield"));
        if (!path.contains("black_flash") && path.contains("flash") && (path.contains("suit") || path.contains("armor") || path.contains("armour")
                || path.contains("costume") || path.contains("helmet") || path.contains("chestplate") || path.contains("leggings") || path.contains("boots")))
            return List.of(List.of("=flash_ring"));
        return List.of();
    }

    private static void scanTaczGuns() {
        try {
            Class<?> api = Class.forName("com.tacz.guns.api.TimelessAPI");
            Method allGunsMethod = api.getDeclaredMethod("getAllCommonGunIndex");
            Object result = allGunsMethod.invoke(null);
            if (!(result instanceof Set<?> entries)) return;
            for (Object object : entries) {
                try {
                    if (!(object instanceof Map.Entry<?, ?> entry)) continue;
                    if (!(entry.getKey() instanceof ResourceLocation gunId)) continue;
                    Object index = entry.getValue();
                    if (index == null) continue;
                    Object gunData = index.getClass().getMethod("getGunData").invoke(index);
                    if (gunData == null) continue;
                    Object ammoValue = gunData.getClass().getMethod("getAmmoId").invoke(gunData);
                    if (!(ammoValue instanceof ResourceLocation ammoId)) continue;
                    if (ammoId.toString().isBlank() || "tacz:empty".equals(ammoId.toString())) continue;
                    TACZ_GUNS.add(new TaczGun(gunId, ammoId));
                } catch (Exception ignoredEntry) {
                    // Skip malformed gun-pack entries only.
                }
            }
            TACZ_GUNS.sort(Comparator.comparing(g -> g.gunId().toString()));
        } catch (Exception | LinkageError ignored) {
            TACZ_GUNS.clear();
        }
    }

    private static List<ItemStack> createTaczWeaponBundle(Random random) {
        if (TACZ_GUNS.isEmpty()) return List.of();
        Item gunItem = BuiltInRegistries.ITEM.get(new ResourceLocation("tacz", "modern_kinetic_gun"));
        Item ammoItem = BuiltInRegistries.ITEM.get(new ResourceLocation("tacz", "ammo"));
        if (gunItem == Items.AIR || ammoItem == Items.AIR) return List.of();
        TaczGun definition = TACZ_GUNS.get(random.nextInt(TACZ_GUNS.size()));
        ItemStack gun = new ItemStack(gunItem);
        gun.getOrCreateTag().putString("GunId", definition.gunId().toString());
        ItemStack ammo = new ItemStack(ammoItem);
        ammo.getOrCreateTag().putString("AmmoId", definition.ammoId().toString());
        ammo.setCount(Math.max(1, Math.min(ammo.getMaxStackSize(), 24)));
        return List.of(gun, ammo);
    }

    private static void addRelatedComponents(List<ItemStack> out, Item item, Random random) {
        List<ItemStack> exact = EXACT_RELATED_COMPONENTS.get(item);
        if (exact != null) {
            for (ItemStack component : exact) {
                boolean duplicate = out.stream().anyMatch(existing -> !existing.isEmpty()
                        && existing.getItem() == component.getItem()
                        && ItemStack.isSameItemSameTags(existing, component));
                if (!duplicate) out.add(component.copy());
            }
        }

        List<List<Item>> groups = RELATED_COMPONENTS.get(item);
        if (groups == null || groups.isEmpty()) return;
        for (List<Item> candidates : groups) {
            if (candidates.isEmpty()) continue;
            Item component = candidates.get(random.nextInt(candidates.size()));
            boolean alreadyPresent = out.stream().anyMatch(stack -> !stack.isEmpty() && stack.getItem() == component);
            if (!alreadyPresent) out.add(new ItemStack(component));
        }
    }

    private static void addItemAndRelated(List<ItemStack> out, Item item, Random random) {
        if (item == null || item == Items.AIR) return;
        out.add(new ItemStack(item));
        addRelatedComponents(out, item, random);
    }

    private static int[] weights(LootProfile profile) {
        // Order: FOOD, CLOTHING, ARMOR, MELEE, FIREARMS, TECH, POTIONS, SERUMS, SPECIAL, MISC, VEHICLE.
        return switch (profile) {
            case GARAGE -> new int[]{22,0,0,34,0,28,0,0,0,0,10};
            case LUXURY, CITY_LUXURY -> new int[]{15,12,12,10,10,12,4,4,0,12,2};
            case PARK -> new int[]{28,6,3,10,12,4,3,2,0,26,0};
            case SCRAPYARD -> new int[]{18,10,1,4,2,5,2,2,0,48,2};
            case CASTLE -> new int[]{1,8,25,30,3,0,12,4,0,10,0};
            case APARTMENTS -> new int[]{22,16,12,8,8,10,3,4,0,8,2};
            case CITY_SMALL_HOUSE -> new int[]{28,25,4,4,10,8,2,2,0,10,2};
            case CITY_CHEMICAL -> new int[]{0,0,0,0,0,0,35,55,0,0,0};
            case CITY_HIGHRISE -> new int[]{18,5,20,12,15,12,4,3,0,8,5};
            case CITY_CORPORATE -> new int[]{5,3,18,10,16,20,5,7,0,6,7};
            case MATRIX, GENERAL -> new int[]{12,12,10,10,12,12,5,4,0,20,7};
        };
    }

    private static float setChance(LootProfile profile) {
        return switch (profile) {
            case GARAGE -> 0.0f;
            case PARK -> 0.035f;
            case SCRAPYARD -> 0.012f;
            case CASTLE -> 0.24f;
            case LUXURY, CITY_LUXURY, APARTMENTS -> 0.18f;
            case CITY_SMALL_HOUSE -> 0.035f;
            case CITY_CHEMICAL -> 0.01f;
            case CITY_HIGHRISE -> 0.14f;
            case CITY_CORPORATE -> 0.16f;
            case MATRIX -> 0.14f;
            case GENERAL -> 0.10f;
        };
    }

    /** Hero armor is deliberately rarer than clothing; district profile controls its appearance. */
    private static float heroArmorSetChance(LootProfile profile) {
        return switch (profile) {
            case GARAGE, CITY_CHEMICAL -> 0.0f;
            case PARK -> 0.02f;
            case SCRAPYARD -> 0.003f;
            case CASTLE -> 0.10f;
            case LUXURY, CITY_LUXURY, APARTMENTS -> 0.06f;
            case CITY_SMALL_HOUSE -> 0.015f;
            case CITY_HIGHRISE -> 0.08f;
            case CITY_CORPORATE -> 0.10f;
            case MATRIX -> 0.14f;
            case GENERAL -> 0.05f;
        };
    }

    private static float specialChance(LootProfile profile) {
        return switch (profile) {
            case SCRAPYARD -> SCRAP_SPECIAL_CHANCE;
            case CITY_CHEMICAL, CITY_CORPORATE -> 0.12f;
            case LUXURY, CITY_LUXURY, APARTMENTS, CASTLE, CITY_HIGHRISE -> 0.075f;
            case MATRIX -> 0.055f; // Keep Matrix's established profile; only the shared special-item roll is added.
            case PARK, GARAGE, CITY_SMALL_HOUSE -> 0.05f;
            case GENERAL -> DEFAULT_SPECIAL_CHANCE;
        };
    }

    private static Item chooseSpecialItem(Random random, LootProfile profile) {
        List<Item> candidates = new ArrayList<>();
        if (profile == LootProfile.CITY_CHEMICAL) {
            candidates.addAll(SERUMS);
            candidates.addAll(POTIONS);
        } else {
            for (Item item : SPECIAL) {
                if (HERO_ARMOR_ITEMS.contains(item)) continue;
                ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
                if (id == null) continue;
                String path = id.getPath().toLowerCase(Locale.ROOT);
                if (profile == LootProfile.CASTLE) {
                    boolean fantasySpecial = path.contains("artifact") || path.contains("relic") || path.contains("ring")
                            || path.contains("amulet") || path.contains("talisman") || path.contains("medallion")
                            || path.contains("infinity_stone") || path.contains("gauntlet") || path.contains("lantern")
                            || path.contains("sorcerybook") || path.contains("essence") || path.contains("capsule")
                            || path.contains("necrosword") || path.contains("mjolnir") || path.contains("stormbreaker")
                            || path.contains("trident") || path.contains("shazam_staff") || path.contains("scarab")
                            || path.contains("contract") || path.contains("scroll");
                    if (!fantasySpecial || isTechItem(path) || isVehicleItem(path) || isSerumItem(path)) continue;
                }
                if (profile == LootProfile.GARAGE && (item instanceof ArmorItem || HERO_ARMOR_ITEMS.contains(item) || isWearableClothing(path)
                        || isFirearmItem(path, id.getNamespace()))) continue;
                candidates.add(item);
            }
        }
        if (candidates.isEmpty()) return null;
        return candidates.get(random.nextInt(candidates.size()));
    }

    private static List<Item> pool(Category category) {
        return switch (category) {
            case FOOD -> FOOD;
            case CLOTHING -> CLOTHING;
            case ARMOR -> ARMOR;
            case MELEE -> MELEE;
            case FIREARMS -> FIREARMS;
            case TECH -> TECH;
            case POTIONS -> POTIONS;
            case SERUMS -> SERUMS;
            case SPECIAL -> SPECIAL;
            case VEHICLE -> VEHICLE;
            case MISC -> MISC;
        };
    }

    private static Item chooseItem(Random random, LootProfile profile) {
        return chooseItem(random, profile, false);
    }

    private static Item chooseItem(Random random, LootProfile profile, boolean suppressLooseArmor) {
        int[] configured = weights(profile);
        if (suppressLooseArmor && configured.length > 2) configured[2] = 0;
        Category[] categories = Category.values();
        int availableWeight = 0;
        for (int i = 0; i < categories.length; i++)
            if (!pool(categories[i]).isEmpty()) availableWeight += configured[i];
        if (availableWeight <= 0) return Items.IRON_INGOT;
        int roll = random.nextInt(availableWeight);
        for (int i = 0; i < categories.length; i++) {
            List<Item> candidates = pool(categories[i]);
            if (candidates.isEmpty() || configured[i] <= 0) continue;
            if (roll < configured[i]) return candidates.get(random.nextInt(candidates.size()));
            roll -= configured[i];
        }
        return Items.IRON_INGOT;
    }

    public static synchronized LootResult generateProfileContainerLootResult(Random random, int targetStacks,
                                                                                boolean allowWearableSet, LootProfile profile) {
        ensureScanned();
        List<ItemStack> out = new ArrayList<>();
        boolean wearableSetDropped = false;
        boolean heroArmorSetDropped = false;
        LootProfile safeProfile = profile == null ? LootProfile.GENERAL : profile;

        if (allowWearableSet) {
            if (!HERO_ARMOR_SETS.isEmpty() && random.nextFloat() < heroArmorSetChance(safeProfile)) {
                List<Item> set = HERO_ARMOR_SETS.get(random.nextInt(HERO_ARMOR_SETS.size()));
                for (Item piece : set) out.add(new ItemStack(piece));
                for (Item piece : set) addRelatedComponents(out, piece, random);
                wearableSetDropped = true;
                heroArmorSetDropped = true;
            } else if (!CLOTHING_SETS.isEmpty() && random.nextFloat() < setChance(safeProfile)) {
                List<Item> set = CLOTHING_SETS.get(random.nextInt(CLOTHING_SETS.size()));
                for (Item piece : set) out.add(new ItemStack(piece));
                wearableSetDropped = true;
            }
        }

        int count = Math.max(4, targetStacks);
        if (safeProfile == LootProfile.SCRAPYARD) count = 3 + random.nextInt(4);
        if (safeProfile == LootProfile.CITY_CORPORATE || safeProfile == LootProfile.CITY_HIGHRISE) count = Math.max(10, targetStacks);
        for (int i = 0; i < count; i++) {
            Item item;
            if (safeProfile == LootProfile.SCRAPYARD && !LOW_QUALITY.isEmpty() && random.nextFloat() < 0.70f) {
                item = LOW_QUALITY.get(random.nextInt(LOW_QUALITY.size()));
            } else {
                item = chooseItem(random, safeProfile, heroArmorSetDropped);
            }
            addItemAndRelated(out, item, random);
        }

        Item specialItem = chooseSpecialItem(random, safeProfile);
        if (specialItem != null && random.nextFloat() < specialChance(safeProfile))
            addItemAndRelated(out, specialItem, random);

        float taczChance = switch (safeProfile) {
            case GARAGE, CITY_CHEMICAL, SCRAPYARD -> 0.0f;
            case PARK, CITY_SMALL_HOUSE -> 0.035f;
            case CASTLE -> 0.025f;
            case LUXURY, CITY_LUXURY, APARTMENTS -> 0.16f;
            case CITY_HIGHRISE -> 0.20f;
            case CITY_CORPORATE -> 0.24f;
            case MATRIX -> 0.12f;
            case GENERAL -> 0.06f;
        };
        if (!TACZ_GUNS.isEmpty() && random.nextFloat() < taczChance) out.addAll(createTaczWeaponBundle(random));

        if (out.isEmpty()) out.add(new ItemStack(Items.IRON_INGOT, 2 + random.nextInt(4)));
        return new LootResult(out, wearableSetDropped);
    }

    public static synchronized ItemStack randomTechnologyItem(Random random) {
        ensureScanned();
        if (!TECH.isEmpty()) return new ItemStack(TECH.get(random.nextInt(TECH.size())));
        return new ItemStack(Items.REDSTONE, 1 + random.nextInt(3));
    }

    public static synchronized ItemStack randomSpecialItem(Random random) {
        ensureScanned();
        if (SPECIAL.isEmpty()) return ItemStack.EMPTY;
        return new ItemStack(SPECIAL.get(random.nextInt(SPECIAL.size())));
    }

    public static synchronized LootResult generateContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.GENERAL);
    }

    public static synchronized List<ItemStack> generateContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateContainerLootResult(random, targetStacks, allowWearableSet).items();
    }

    public static synchronized LootResult generateVehicleContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.GARAGE);
    }

    public static synchronized List<ItemStack> generateVehicleContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateVehicleContainerLootResult(random, targetStacks, allowWearableSet).items();
    }

    public static synchronized LootResult generateParkContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.PARK);
    }

    public static synchronized LootResult generateScrapyardContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.SCRAPYARD);
    }

    public static synchronized List<ItemStack> generateScrapyardContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateScrapyardContainerLootResult(random, targetStacks, allowWearableSet).items();
    }

    /** Matrix keeps its established high-value mix, with the shared low-frequency special-item roll. */
    public static synchronized LootResult generateMatrixContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        List<ItemStack> out = new ArrayList<>();
        boolean setDropped = false;
        if (allowWearableSet && random.nextFloat() < 0.14f
                && (!HERO_ARMOR_SETS.isEmpty() || !CLOTHING_SETS.isEmpty())) {
            // Keep Matrix's original 14% set roll and its original weighting by available set count.
            List<List<Item>> matrixSets = new ArrayList<>(HERO_ARMOR_SETS);
            matrixSets.addAll(CLOTHING_SETS);
            List<Item> set = matrixSets.get(random.nextInt(matrixSets.size()));
            for (Item piece : set) out.add(new ItemStack(piece));
            if (set.stream().anyMatch(HERO_ARMOR_ITEMS::contains))
                for (Item piece : set) addRelatedComponents(out, piece, random);
            setDropped = true;
        }
        int count = Math.max(8, targetStacks - out.size());
        for (int i = 0; i < count; i++) {
            Item item;
            float roll = random.nextFloat();
            if (roll < 0.62f && !VALUABLE.isEmpty()) item = VALUABLE.get(random.nextInt(VALUABLE.size()));
            else if (roll < 0.86f && !CLOTHING.isEmpty()) item = CLOTHING.get(random.nextInt(CLOTHING.size()));
            else if (!COMMON.isEmpty()) item = COMMON.get(random.nextInt(COMMON.size()));
            else item = !VALUABLE.isEmpty() ? VALUABLE.get(random.nextInt(VALUABLE.size())) : Items.IRON_INGOT;
            addItemAndRelated(out, item, random);
        }
        int replacements = Math.max(2, targetStacks / 3);
        for (int i = 0; i < out.size() && replacements > 0 && !VALUABLE.isEmpty(); i++) {
            if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.9f) {
                out.set(i, new ItemStack(VALUABLE.get(random.nextInt(VALUABLE.size()))));
                replacements--;
            }
        }
        Item specialItem = chooseSpecialItem(random, LootProfile.MATRIX);
        if (specialItem != null && random.nextFloat() < specialChance(LootProfile.MATRIX))
            addItemAndRelated(out, specialItem, random);
        if (!TACZ_GUNS.isEmpty() && random.nextFloat() < 0.12f) out.addAll(createTaczWeaponBundle(random));
        return new LootResult(out, setDropped);
    }

    public static synchronized LootResult generateCastleContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.CASTLE);
    }

    public static synchronized LootResult generateLuxuryContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        return generateProfileContainerLootResult(random, targetStacks, allowWearableSet, LootProfile.LUXURY);
    }

    public static synchronized List<ItemStack> generateGarageLoot(Random random, int targetStacks) {
        return generateProfileContainerLootResult(random, targetStacks, true, LootProfile.GARAGE).items();
    }

    public static synchronized ItemStack randomStack(Random random) {
        List<ItemStack> stacks = generateContainerLoot(random, 1, false);
        return stacks.isEmpty() ? ItemStack.EMPTY : stacks.get(0);
    }

    private static boolean isProtectedLoot(ItemStack stack) {
        if (stack.isEmpty()) return true;
        Item item = stack.getItem();
        if (item instanceof ArmorItem || HERO_ARMOR_ITEMS.contains(item) || CLOTHING.contains(item)) return true;
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
        return id != null && "tacz".equals(id.getNamespace())
                && ("modern_kinetic_gun".equals(id.getPath()) || "ammo".equals(id.getPath()));
    }

    private static boolean isHeroArmorItem(ResourceLocation id, Item item, String path) {
        String namespace = id.getNamespace();
        if ("potato".equals(namespace)) return POTATO_HERO_ARMOR_PATHS.contains(path);
        if ("fsang".equals(namespace) || "throgaddon".equals(namespace)) {
            return item instanceof ArmorItem || hasArmorSlotSuffix(path);
        }
        boolean knownHeroNamespace = namespace.contains("marvel") || namespace.contains("superhero")
                || namespace.contains("invincible") || namespace.contains("boys")
                || namespace.contains("arrz") || namespace.contains("legends")
                || namespace.contains("godsandheroes") || namespace.contains("wildfyre");
        if (knownHeroNamespace) {
            return item instanceof ArmorItem || hasArmorSlotSuffix(path)
                    || endsWithAny(path, "_suit", "_costume", "_armor", "_armour");
        }
        return item instanceof ArmorItem && hasHeroArmorKeyword(path);
    }

    private static boolean isOnePieceHeroArmorSet(String setKey, Item item) {
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
        if (id == null) return false;
        if (Set.of("fsang", "throgaddon", "potato").contains(id.getNamespace())) return false;
        EquipmentSlot slot = armorEquipmentSlot(item, id.getPath());
        return slot == EquipmentSlot.CHEST || endsWithAny(id.getPath(), "_suit", "_costume", "_armor", "_armour");
    }

    private static boolean hasHeroArmorKeyword(String path) {
        return containsAny(path, "iron_man", "ironman", "spider", "superman", "supergirl", "superboy",
                "batman", "flash", "lantern", "invincible", "omniman", "omni_man", "viltrum",
                "homelander", "soldier_boy", "thor", "hulk", "wolverine", "magneto", "cyclops",
                "deadpool", "captain_america", "captainamerica", "wonder_woman", "wonderwoman",
                "aquaman", "shazam", "black_adam", "blackadam", "sentry", "vision", "ant_man",
                "antman", "green_goblin", "venom", "carnage", "galactus", "doctor_doom",
                "dr_doom", "doom", "black_panther", "daredevil", "moon_knight", "moonknight",
                "hawkeye", "hawkgirl", "superhero", "hero_suit", "hero_armor");
    }

    private static boolean containsAny(String value, String... fragments) {
        for (String fragment : fragments) if (value.contains(fragment)) return true;
        return false;
    }

    private static boolean hasArmorSlotSuffix(String path) {
        return endsWithAny(path, "_helmet", "_helm", "_head", "_mask", "_visor", "_cowl",
                "_chestplate", "_chest", "_torso", "_body", "_leggings", "_legs",
                "_pants", "_boots", "_feet", "_shoes");
    }

    private static EquipmentSlot armorEquipmentSlot(Item item, String path) {
        if (item instanceof ArmorItem armor) return armor.getEquipmentSlot();
        if (endsWithAny(path, "_helmet", "_helm", "_head", "_mask", "_visor", "_cowl")) return EquipmentSlot.HEAD;
        if (endsWithAny(path, "_chestplate", "_chest", "_torso", "_body")) return EquipmentSlot.CHEST;
        if (endsWithAny(path, "_leggings", "_legs", "_pants")) return EquipmentSlot.LEGS;
        if (endsWithAny(path, "_boots", "_feet", "_shoes")) return EquipmentSlot.FEET;
        return null;
    }

    private static boolean isUnusableSerumIngredient(String path) {
        return path.equals("syringe") || path.equals("syringe_empty") || path.equals("syringe_filled")
                || path.equals("human_dna") || path.equals("super_soldier_dna")
                || path.equals("viltrumite_dna") || path.equals("viltrumite_fossil")
                || path.equals("x_gene") || path.endsWith("_fossil")
                || path.equals("human_blood_syringe");
    }

    private static boolean isWearableClothing(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("clothing") || p.contains("outfit") || p.contains("costume") || p.contains("jacket")
                || p.contains("shirt") || p.contains("hoodie") || p.contains("pants") || p.contains("trousers")
                || p.contains("suit") || p.contains("uniform") || p.contains("coat") || p.contains("hat")
                || p.contains("glove") || p.contains("scarf") || p.contains("dress") || p.contains("boots")
                || p.contains("shoes") || p.contains("sneaker") || p.contains("skirt") || p.contains("vest")
                || p.contains("helmet") || p.contains("mask") || p.contains("cape") || p.contains("robe")
                || p.contains("armor") || p.contains("armour")
                || p.contains("tunic") || p.contains("sweater") || p.contains("blouse") || p.contains("shorts");
    }

    private static ClothingSlot clothingSlot(String path) {
        if (endsWithAny(path, "_helmet", "_helm", "_head", "_mask", "_hood", "_hat", "_cap", "_beanie", "_cowl", "_crown")
                || startsWithAny(path, "helmet_", "helm_", "head_", "mask_", "hood_", "hat_", "cap_")) return ClothingSlot.HEAD;
        if (endsWithAny(path, "_chestplate", "_chest", "_torso", "_jacket", "_coat", "_shirt", "_hoodie", "_top", "_vest", "_tunic", "_robe", "_sweater", "_blouse", "_jersey")
                || startsWithAny(path, "chestplate_", "chest_", "torso_", "jacket_", "coat_", "shirt_", "hoodie_", "top_", "vest_", "tunic_", "robe_")) return ClothingSlot.CHEST;
        if (endsWithAny(path, "_leggings", "_legs", "_pants", "_trousers", "_shorts", "_skirt")
                || startsWithAny(path, "leggings_", "legs_", "pants_", "trousers_", "shorts_", "skirt_")) return ClothingSlot.LEGS;
        if (endsWithAny(path, "_boots", "_feet", "_shoes", "_sneakers", "_sandals")
                || startsWithAny(path, "boots_", "feet_", "shoes_", "sneakers_", "sandals_")) return ClothingSlot.FEET;
        if (endsWithAny(path, "_gloves", "_glove", "_hands", "_gauntlets", "_bracers")
                || startsWithAny(path, "gloves_", "glove_", "hands_", "gauntlets_", "bracers_")) return ClothingSlot.HANDS;
        return null;
    }

    private static String clothingSetName(String path, ClothingSlot slot) {
        String[] suffixes = switch (slot) {
            case HEAD -> new String[]{"_helmet", "_helm", "_head", "_mask", "_hood", "_hat", "_cap", "_beanie", "_cowl", "_crown"};
            case CHEST -> new String[]{"_chestplate", "_chest", "_torso", "_jacket", "_coat", "_shirt", "_hoodie", "_top", "_vest", "_tunic", "_robe", "_sweater", "_blouse", "_jersey"};
            case LEGS -> new String[]{"_leggings", "_legs", "_pants", "_trousers", "_shorts", "_skirt"};
            case FEET -> new String[]{"_boots", "_feet", "_shoes", "_sneakers", "_sandals"};
            case HANDS -> new String[]{"_gloves", "_glove", "_hands", "_gauntlets", "_bracers"};
        };
        for (String suffix : suffixes) if (path.endsWith(suffix)) return path.substring(0, path.length() - suffix.length());
        String[] prefixes = switch (slot) {
            case HEAD -> new String[]{"helmet_", "helm_", "head_", "mask_", "hood_", "hat_", "cap_"};
            case CHEST -> new String[]{"chestplate_", "chest_", "torso_", "jacket_", "coat_", "shirt_", "hoodie_", "top_", "vest_", "tunic_", "robe_"};
            case LEGS -> new String[]{"leggings_", "legs_", "pants_", "trousers_", "shorts_", "skirt_"};
            case FEET -> new String[]{"boots_", "feet_", "shoes_", "sneakers_", "sandals_"};
            case HANDS -> new String[]{"gloves_", "glove_", "hands_", "gauntlets_", "bracers_"};
        };
        for (String prefix : prefixes) if (path.startsWith(prefix)) return path.substring(prefix.length());
        return path;
    }

    private static boolean startsWithAny(String value, String... prefixes) {
        for (String prefix : prefixes) if (value.startsWith(prefix)) return true;
        return false;
    }

    private static boolean isOnePieceOutfit(String path) {
        return endsWithAny(path, "_suit", "_outfit", "_costume", "_uniform", "_onesie", "_dress", "_cape", "_clothing", "_armor", "_armour");
    }

    private static boolean endsWithAny(String value, String... suffixes) {
        for (String suffix : suffixes) if (value.endsWith(suffix)) return true;
        return false;
    }

    private static boolean isVehicleItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("wheel") || p.contains("tire") || p.contains("tyre") || p.contains("engine")
                || p.contains("vehicle") || p.contains("car_") || p.startsWith("car") || p.contains("motor")
                || p.contains("brake") || p.contains("steering") || p.contains("suspension") || p.contains("fuel_tank")
                || p.contains("rotor") || p.contains("wing") || p.contains("propeller") || p.contains("jet");
    }

    private static boolean isFirearmItem(String path, String namespace) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("gun") || p.contains("rifle") || p.contains("pistol") || p.contains("shotgun")
                || p.contains("blaster") || p.contains("railgun") || p.contains("launcher") || p.contains("crossbow")
                || p.contains("bow") || p.contains("ammo") || p.contains("bullet") || p.contains("grenade")
                || p.contains("missile") || p.contains("firearm") || p.contains("revolver") || p.contains("sniper")
                || p.contains("laser") || p.contains("cannon") || p.contains("minigun") || p.contains("gatling")
                || p.contains("beam_rifle") || p.contains("energy_rifle");
    }

    private static boolean isMeleeItem(String path, String namespace) {
        String p = path.toLowerCase(Locale.ROOT);
        String mod = namespace.toLowerCase(Locale.ROOT);
        boolean dedicatedMeleePack = mod.contains("marbled") || mod.contains("deltaforce_melee")
                || mod.contains("melee_pack") || mod.equals("delta_wt");
        if (dedicatedMeleePack || (mod.equals("wom") && !isFirearmItem(p, mod))) return true;
        return p.contains("sword") || p.contains("blade") || p.contains("katana") || p.contains("saber")
                || p.contains("sabre") || p.contains("spear") || p.contains("lance") || (p.contains("axe") && !p.contains("pickaxe"))
                || p.contains("mace") || p.contains("hammer") || p.contains("staff") || p.contains("wand")
                || p.contains("dagger") || p.contains("knife") || p.contains("scythe") || p.contains("club")
                || p.contains("melee") || p.contains("lightsaber") || p.contains("light_saber") || p.contains("trident")
                || p.contains("glaive") || p.contains("halberd") || p.contains("polearm") || p.contains("rapier")
                || p.contains("nunchaku") || p.contains("tonfa") || p.contains("machete") || p.contains("cleaver")
                || p.contains("sickle") || p.contains("flail") || p.contains("morningstar") || p.contains("warhammer")
                || p.contains("battleaxe") || p.contains("greatsword") || p.contains("sai");
    }

    private static boolean isTechItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("reactor") || p.contains("arc_core") || p.contains("power_core") || p.contains("battery")
                || p.contains("circuit") || p.contains("wire") || p.contains("component") || p.contains("mechanical")
                || p.contains("technology") || p.contains("tech_") || p.endsWith("_tech") || p.contains("device")
                || p.contains("motor") || p.contains("engine") || p.contains("gear") || p.contains("rotor")
                || p.contains("turbine") || p.contains("fuel_tank") || p.contains("cyberware") || p.contains("implant")
                || p.contains("scanner") || p.contains("module") || p.contains("processor") || p.contains("chip");
    }

    private static boolean isPotionItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("potion") || p.contains("elixir") || p.contains("brew") || p.contains("antidote")
                || p.contains("tonic") || p.contains("poison") || p.contains("alchemy");
    }

    private static boolean isSerumItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("serum") || p.contains("syringe") || p.contains("compound") || p.contains("symbiote")
                || p.contains("symbiont") || p.contains("viltrum") || p.contains("vial") || p.contains("inject")
                || p.contains("injection") || p.contains("formula") || p.contains("mutagen") || p.contains("transfusion")
                || p.contains("super_soldier") || p.contains("v24") || p.contains("blood_sample") || p.contains("dose");
    }

    private static boolean isSpecialItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("artifact") || p.contains("relic") || p.contains("ring") || p.contains("amulet")
                || p.contains("talisman") || p.contains("medallion") || p.contains("infinity_stone")
                || p.contains("symbiote") || p.contains("symbiont") || p.contains("serum") || p.contains("compound")
                || p.contains("reactor") || p.contains("power_core") || p.contains("gadget") || p.contains("device")
                || p.contains("lantern") || p.contains("gauntlet") || p.contains("superpower") || p.contains("hero_token")
                || p.contains("capsule") || p.contains("essence") || p.contains("knull") || p.contains("necrosword")
                || p.contains("mjolnir") || p.contains("stormbreaker") || p.contains("trident")
                || p.contains("shazam_staff") || p.contains("scarab") || p.contains("contract")
                || p.contains("shield") || p.contains("falcon_wings") || p.contains("web_shooters")
                || p.contains("batarang") || p.contains("bat_gun") || p.contains("utility_belt")
                || p.contains("belt") || p.contains("pumpkin_bomb") || p.contains("vial")
                || (p.contains("syringe") && !p.contains("filled") && !p.contains("empty")
                    && !p.contains("human_blood"))
                || p.contains("sorcerybook") || p.contains("martialscroll")
                || p.contains("webshooter") || p.contains("backpack") || p.equals("drug");
    }

    private static boolean isValuableItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return isFirearmItem(p, "") || isMeleeItem(p, "") || p.contains("armor") || p.contains("armour")
                || isSpecialItem(p) || p.contains("energy") || p.contains("ammo") || p.contains("cyberware")
                || p.contains("shield") || p.contains("power") || p.contains("launcher");
    }

    private static boolean isLowQualityItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("scrap") || p.contains("rust") || p.contains("broken") || p.contains("old_")
                || p.contains("damaged") || p.contains("junk") || p.contains("worn") || p.contains("dirty")
                || p.contains("basic") || p.contains("wooden") || p.contains("stone_") || p.contains("copper_")
                || p.contains("leather") || p.contains("cloth") || p.contains("rope") || p.contains("wire");
    }

    private static boolean excluded(ResourceLocation id) {
        String p = id.getPath().toLowerCase(Locale.ROOT);
        if ("tacz".equals(id.getNamespace()) && Set.of("modern_kinetic_gun", "ammo", "ammo_box", "attachment").contains(p)) return true;
        return Set.of("air", "barrier", "command_block", "chain_command_block", "repeating_command_block",
                "structure_block", "jigsaw", "light", "structure_void", "knowledge_book").contains(p)
                || p.contains("spawn_egg") || p.contains("debug") || p.contains("test_item") || p.contains("_spawn");
    }

    private static String armorSetName(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        for (String suffix : List.of("_armor_helmet", "_armor_chestplate", "_armor_leggings", "_armor_boots",
                "_armor_head", "_armor_chest", "_armor_legs", "_armor_feet", "_helmet", "_helm", "_head",
                "_mask", "_visor", "_cowl", "_chestplate", "_chest", "_torso", "_body", "_leggings", "_legs",
                "_pants", "_boots", "_feet", "_shoes")) {
            if (p.endsWith(suffix)) return p.substring(0, p.length() - suffix.length());
        }
        for (String prefix : List.of("helmet_", "helm_", "head_", "mask_", "chestplate_", "chest_", "torso_",
                "leggings_", "legs_", "pants_", "boots_", "feet_", "shoes_")) {
            if (p.startsWith(prefix)) return p.substring(prefix.length());
        }
        return p;
    }

    private static void ensureScanned() {
        if (!scanned) scan();
    }
}
