package com.geko.garageauction.structure;

import com.geko.garageauction.loot.LootScanner;
import com.geko.garageauction.loot.LootScanner.LootProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.Container;

import java.util.*;

/** Procedural locations and loot handling for Garage Auction. */
public final class MarketplaceBuilder {
    private MarketplaceBuilder() {}

    private static BlockPos oriented(BlockPos origin, Direction right, Direction forward, int x, int z) {
        return origin.relative(right, x).relative(forward, z);
    }

    private static int surfaceY(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    /**
     * Prepare a safe footprint without cutting existing terrain.
     *
     * The old median-height algorithm removed every column above the median, which could erase
     * hills, tree trunks and even buildings across hundreds of blocks. The new algorithm chooses
     * the highest natural surface as the build plane, rejects steep/occupied sites, and only adds
     * a shallow dirt foundation below that plane. A void world gets a floating foundation at the
     * command user's height instead of silently placing the district below the world.
     */
    private static int prepareFootprint(ServerLevel level, BlockPos center, int radius, Block floor,
                                        boolean circular, int maxStructureHeight) {
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            if (circular && x * x + z * z > radius * radius) continue;
            int h = surfaceY(level, center.getX() + x, center.getZ() + z);
            min = Math.min(min, h);
            max = Math.max(max, h);
        }

        if (max == Integer.MIN_VALUE) return center.getY();

        boolean voidWorld = max <= level.getMinBuildHeight() + 1;
        int base;
        if (voidWorld) {
            int desiredBase = center.getY() - 1;
            int highestSafeBase = level.getMaxBuildHeight() - maxStructureHeight - 3;
            base = Math.max(level.getMinBuildHeight() + 8, Math.min(desiredBase, highestSafeBase));
        } else {
            int allowedVariation = radius >= 200 ? 12 : (radius >= 100 ? 8 : 6);
            if (max - min > allowedVariation) {
                throw new IllegalArgumentException("Участок слишком неровный (перепад " + (max - min)
                        + " блоков). Выбери более ровную площадку. Генератор больше не срезает рельеф.");
            }
            base = max;
        }

        if (base <= level.getMinBuildHeight() || base + maxStructureHeight >= level.getMaxBuildHeight() - 2) {
            throw new IllegalArgumentException("Для этой локации недостаточно вертикального места. Выбери площадку ниже.");
        }

        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        // Validate the complete footprint before changing blocks or deleting dropped entities.
        // Player-built floors, roofs, trees and containers are not treated as natural terrain.
        if (!voidWorld) {
            for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
                if (circular && x * x + z * z > radius * radius) continue;
                int wx = center.getX() + x;
                int wz = center.getZ() + z;
                int top = surfaceY(level, wx, wz);
                pos.set(wx, top - 1, wz);
                BlockState ground = level.getBlockState(pos);
                if (!isNaturalGround(ground) && !ground.is(floor)) {
                    throw new IllegalArgumentException("Площадка занята постройками, деревьями или неестественным покрытием. "
                            + "Выбери свободную ровную территорию; генератор не будет удалять существующий ландшафт.");
                }
                if (level.getBlockEntity(pos) != null) {
                    throw new IllegalArgumentException("На площадке найдены контейнеры или другие блоки с данными. "
                            + "Выбери свободную территорию, чтобы не потерять их содержимое.");
                }
            }
        }

        // Re-generating a district also clears dropped loot and only villagers spawned by this mod.
        AABB cleanupBounds = new AABB(center.getX() - radius, Math.max(level.getMinBuildHeight(), base - 8),
                center.getZ() - radius, center.getX() + radius + 1, level.getMaxBuildHeight(),
                center.getZ() + radius + 1);
        level.getEntitiesOfClass(ItemEntity.class, cleanupBounds).stream()
                .filter(entity -> !circular || Math.pow(entity.getX() - center.getX(), 2)
                        + Math.pow(entity.getZ() - center.getZ(), 2) <= radius * radius)
                .forEach(entity -> entity.discard());
        level.getEntitiesOfClass(Villager.class, cleanupBounds).stream()
                .filter(v -> v.getPersistentData().getBoolean("garageauction_generated"))
                .filter(v -> !circular || Math.pow(v.getX() - center.getX(), 2)
                        + Math.pow(v.getZ() - center.getZ(), 2) <= radius * radius)
                .forEach(v -> v.discard());

        for (int x = -radius; x <= radius; x++) for (int z = -radius; z <= radius; z++) {
            if (circular && x * x + z * z > radius * radius) continue;
            int wx = center.getX() + x;
            int wz = center.getZ() + z;
            int top = voidWorld ? base : surfaceY(level, wx, wz);

            // Add foundation only into low ground. Never remove or replace blocks above the natural surface.
            if (!voidWorld && top < base) {
                for (int y = top; y < base - 1; y++) {
                    pos.set(wx, y, wz);
                    if (level.getBlockState(pos).isAir()) level.setBlock(pos, Blocks.DIRT.defaultBlockState(), 3);
                }
            }

            // Clear only overhanging leaves; tree trunks and all solid terrain/buildings were rejected above.
            for (int y = base; y < Math.min(level.getMaxBuildHeight(), base + 24); y++) {
                pos.set(wx, y, wz);
                Block aboveGround = level.getBlockState(pos).getBlock();
                if (aboveGround instanceof LeavesBlock || aboveGround instanceof BushBlock)
                    level.removeBlock(pos, false);
            }

            pos.set(wx, base - 1, wz);
            level.setBlock(pos, floor.defaultBlockState(), 3);
        }
        return base;
    }

    private static boolean isNaturalGround(BlockState state) {
        Block block = state.getBlock();
        return block == Blocks.GRASS_BLOCK || block == Blocks.DIRT || block == Blocks.COARSE_DIRT
                || block == Blocks.ROOTED_DIRT || block == Blocks.PODZOL || block == Blocks.MYCELIUM
                || block == Blocks.STONE || block == Blocks.GRANITE || block == Blocks.DIORITE
                || block == Blocks.ANDESITE || block == Blocks.DEEPSLATE || block == Blocks.TUFF
                || block == Blocks.CALCITE || block == Blocks.SAND || block == Blocks.RED_SAND
                || block == Blocks.GRAVEL || block == Blocks.CLAY || block == Blocks.MOSS_BLOCK
                || block == Blocks.MUD || block == Blocks.SNOW_BLOCK || block == Blocks.SNOW || block == Blocks.POWDER_SNOW || block == Blocks.ICE
                || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE || block == Blocks.NETHERRACK
                || block == Blocks.SOUL_SAND || block == Blocks.SOUL_SOIL || block == Blocks.END_STONE
                || block == Blocks.BASALT || block == Blocks.BLACKSTONE || block == Blocks.CRIMSON_NYLIUM
                || block == Blocks.WARPED_NYLIUM || block == Blocks.TERRACOTTA;
    }

    public static void generatePark(ServerLevel level, BlockPos playerPos, float yaw) {
        generatePark(level, playerPos, yaw, level.getRandom().nextLong(), true);
    }

    private static void generatePark(ServerLevel level, BlockPos playerPos, float yaw, long seed, boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite(), right=f.getClockWise();
        BlockPos o=playerPos.relative(f,14);
        int base=prepareFootprint(level,o,102,Blocks.GRASS_BLOCK,true,24);
        // Large circular green, stone perimeter and planted outer ring.
        for(int x=-102;x<=102;x++) for(int z=-102;z<=102;z++) {
            double d=Math.sqrt(x*x+z*z); if(d>102) continue;
            BlockPos p=o.offset(x,base-1-o.getY(),z);
            if(d>94) level.setBlock(p,Blocks.STONE_BRICKS.defaultBlockState(),3);
            else if(d>91 && r.nextFloat()<.25f) level.setBlock(p,Blocks.MOSSY_STONE_BRICKS.defaultBlockState(),3);
            else level.setBlock(p,Blocks.GRASS_BLOCK.defaultBlockState(),3);
        }
        // Thick hedge wall and trees around the edge.
        for(int a=0;a<360;a++) {
            double ang=a*Math.PI/180.0;
            BlockPos p=o.offset((int)(96*Math.cos(ang)),base-o.getY(),(int)(96*Math.sin(ang)));
            for(int y=0;y<3;y++) for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++)
                level.setBlock(p.offset(dx,y,dz),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
            if(a%18==0) parkTree(level,p,r);
        }
        // Central monument.
        BlockPos c=o;
        for(int y=0;y<3;y++) for(int x=-7+y;x<=7-y;x++) for(int z=-7+y;z<=7-y;z++)
            level.setBlock(c.offset(x,base-o.getY()+y-1,z),Blocks.POLISHED_ANDESITE.defaultBlockState(),3);
        for(int y=2;y<16;y++) {
            int rad=y<9?3:2;
            for(int x=-rad;x<=rad;x++) for(int z=-rad;z<=rad;z++) if(Math.abs(x)+Math.abs(z)<=rad+1)
                level.setBlock(c.offset(x,base-o.getY()+y,z),(y%3==0?Blocks.GRAY_CONCRETE:Blocks.STONE_BRICKS).defaultBlockState(),3);
        }
        // Four broad paths and secondary cross paths.
        for(int n=-2;n<=2;n++) for(int t=-90;t<=90;t++) {
            for(int w=-1;w<=1;w++) {
                BlockPos p=oriented(o,right,f,n*2+w, t);
                if(p.getX()<o.getX()-100 || p.getX()>o.getX()+100) continue;
                level.setBlock(p.offset(0,base-o.getY()-1,0),Blocks.SMOOTH_STONE.defaultBlockState(),3);
            }
            BlockPos q=oriented(o,right,f,t,n*2);
            level.setBlock(q.offset(0,base-o.getY()-1,0),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        }
        // Flower beds alongside paths.
        Block[] flowers={Blocks.POPPY,Blocks.DANDELION,Blocks.BLUE_ORCHID,Blocks.CORNFLOWER,Blocks.ALLIUM,Blocks.OXEYE_DAISY,Blocks.RED_TULIP,Blocks.AZURE_BLUET};
        for(int i=0;i<280;i++) {
            int x=r.nextInt(176)-88,z=r.nextInt(176)-88;
            if(x*x+z*z>88*88) continue;
            BlockPos p=o.offset(x,base-o.getY(),z);
            if(level.getBlockState(p).isAir() && r.nextFloat()<.72f) level.setBlock(p,flowers[r.nextInt(flowers.length)].defaultBlockState(),3);
        }
        // Benches and lamps near the central paths.
        for(int a=0;a<16;a++) {
            double ang=a*Math.PI/8; int x=(int)(17*Math.cos(ang)),z=(int)(17*Math.sin(ang));
            BlockPos p=o.offset(x,base-o.getY(),z);
            level.setBlock(p,Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.NORTH),3);
            if(a%2==0) { level.setBlock(p.above(3),Blocks.LANTERN.defaultBlockState(),3); }
        }
        // 24 cottages in three rings, with enough room for paths between them.
        Block[] roofs={Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL,Blocks.ORANGE_WOOL,Blocks.PURPLE_WOOL,Blocks.CYAN_WOOL,Blocks.MAGENTA_WOOL};
        int idx=1;
        for(int ring=0;ring<3;ring++) for(int i=0;i<8;i++) {
            double ang=i*Math.PI/4+(ring%2==0?0:Math.PI/8);
            int rad=ring==0?43:ring==1?65:84;
            BlockPos h=o.offset((int)(rad*Math.cos(ang)),base-o.getY(),(int)(rad*Math.sin(ang)));
            buildParkCottage(level,h,idx++,roofs[r.nextInt(roofs.length)],r);
        }
        if (register) registerLocation(level,"park",playerPos,yaw,seed,base,102,24,14,true);
    }

    private static void parkTree(ServerLevel level,BlockPos p,RandomSource r) {
        int h=4+r.nextInt(3);
        for(int y=0;y<h;y++) level.setBlock(p.above(y),Blocks.OAK_LOG.defaultBlockState(),3);
        for(int x=-2;x<=2;x++) for(int y=h-2;y<=h+1;y++) for(int z=-2;z<=2;z++)
            if(x*x+z*z+(y-h)*(y-h)<=7 && r.nextFloat()<.88f)
                level.setBlock(p.offset(x,y,z),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
    }

    private static void buildParkCottage(ServerLevel level,BlockPos p,int index,Block roof,RandomSource r) {
        int w=9,d=10; Block[] woods={Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,Blocks.BIRCH_PLANKS,Blocks.DARK_OAK_PLANKS};
        Block wall=woods[r.nextInt(woods.length)];
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=p.offset(x,0,z); level.setBlock(q,Blocks.OAK_PLANKS.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) for(int y=1;y<=4;y++)
                if(!(z==0&&x==4&&y<=2)) level.setBlock(q.above(y),wall.defaultBlockState(),3);
        }
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) level.setBlock(p.offset(x,5,z),roof.defaultBlockState(),3);
        level.setBlock(p.offset(4,1,0),Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH),3);
        level.setBlock(p.offset(4,2,0),Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH).setValue(DoorBlock.HALF,DoubleBlockHalf.UPPER),3);
        level.setBlock(p.offset(2,1,2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(6,1,2),Blocks.CARTOGRAPHY_TABLE.defaultBlockState(),3);
        if(r.nextBoolean()) {
            ArmorStand stand=EntityType.ARMOR_STAND.create(level);
            if(stand!=null) { stand.moveTo(p.getX()+4.5,p.getY()+1,p.getZ()+6.5,r.nextFloat()*360,0); level.addFreshEntity(stand); }
        }
        fillGarageContainers(level,p,w,d,4+r.nextInt(3),r,true,LootProfile.PARK);
    }

    public static void generateScrapyard(ServerLevel level,BlockPos playerPos,float yaw) {
        generateScrapyard(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateScrapyard(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        BlockPos o=playerPos.relative(f,10);
        int base=prepareFootprint(level,o,48,Blocks.COARSE_DIRT,false,12);
        Block[] ground={Blocks.COARSE_DIRT,Blocks.MUD,Blocks.ROOTED_DIRT,Blocks.PODZOL,Blocks.MOSS_BLOCK};
        for(int x=-48;x<=48;x++) for(int z=-42;z<=48;z++) {
            BlockPos p=o.offset(x,base-o.getY()-1,z);
            if(r.nextFloat()<.12f) level.setBlock(p,ground[r.nextInt(ground.length)].defaultBlockState(),3);
        }
        // Perimeter walls of wreckage; no gravel in the palette.
        for(int side=-1;side<=1;side+=2) for(int z=-38;z<=42;z+=3+r.nextInt(3))
            rubbleMound(level,o.offset(side*(40+r.nextInt(5)),base-o.getY(),z),3+r.nextInt(4),2+r.nextInt(4),r);
        for(int x=-40;x<=40;x+=4+r.nextInt(3)) rubbleMound(level,o.offset(x,base-o.getY(),-35-r.nextInt(5)),3+r.nextInt(4),2+r.nextInt(4),r);
        // Main muddy access tracks.
        for(int lane=-1;lane<=1;lane++) for(int z=-5;z<=46;z++) for(int x=-2;x<=2;x++) {
            BlockPos p=oriented(o,right,f,lane*22+x,z).offset(0,base-o.getY()-1,0);
            if(r.nextFloat()<.22f) level.setBlock(p,Blocks.PODZOL.defaultBlockState(),3);
            else if(r.nextFloat()<.12f) level.setBlock(p,Blocks.COARSE_DIRT.defaultBlockState(),3);
        }
        // 20 irregular trash heaps. Containers are placed beside/on clear ground, never buried.
        for(int i=0;i<20;i++) {
            int x=r.nextInt(74)-37,z=r.nextInt(68)-20;
            BlockPos mound=o.offset(x,base-o.getY(),z);
            int moundRadius=3+r.nextInt(4);
            rubbleMound(level,mound,moundRadius,2+r.nextInt(5),r);
            int containers=2+r.nextInt(3);
            for(int c=0;c<containers;c++) {
                int dx=(c%2==0?-1:1)*(moundRadius+2), dz=(c/2)*(moundRadius+2);
                BlockPos cp=mound.offset(dx,0,dz);
                placeLootContainer(level,cp,r,16+r.nextInt(8),false,false,true);
            }
        }
        // A few isolated searchable barrels among the debris.
        for(int i=0;i<14;i++) {
            BlockPos p=o.offset(r.nextInt(82)-41,base-o.getY(),r.nextInt(72)-24);
            placeLootContainer(level,p,r,15+r.nextInt(8),false,false,true);
        }
        if (register) registerLocation(level,"scrapyard",playerPos,yaw,seed,base,48,12,10,false);
    }

    private static void rubbleMound(ServerLevel level,BlockPos center,int radius,int height,RandomSource r) {
        BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        for(int y=0;y<height;y++) for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            double limit=radius-y*.48; if(x*x+z*z>limit*limit || r.nextFloat()<.13f) continue;
            p.set(center.getX()+x,center.getY()+y,center.getZ()+z);
            level.setBlock(p,randomTrashBlock(r).defaultBlockState(),3);
        }
    }

    private static Block randomTrashBlock(RandomSource r) {
        Block[] palette={Blocks.COBBLESTONE,Blocks.MOSSY_COBBLESTONE,Blocks.ANDESITE,Blocks.DIORITE,Blocks.COBBLED_DEEPSLATE,
            Blocks.BRICKS,Blocks.MOSSY_STONE_BRICKS,Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,Blocks.IRON_BLOCK,
            Blocks.CUT_COPPER,Blocks.DIRT,Blocks.ROOTED_DIRT,Blocks.CHAIN,Blocks.GRAY_CONCRETE,
            Blocks.BLACK_CONCRETE,Blocks.DEEPSLATE_BRICKS,Blocks.CRACKED_STONE_BRICKS};
        return palette[r.nextInt(palette.length)];
    }

    public static void generateGarages(ServerLevel level,BlockPos playerPos,float yaw) {
        generateGarages(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateGarages(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        BlockPos o=playerPos.relative(f,12);
        int base=prepareFootprint(level,o,52,Blocks.GRAY_CONCRETE,false,14);
        // Blue-grey enclosed yard.
        for(int x=-50;x<=50;x++) for(int z=-50;z<=50;z++) if(Math.abs(x)==50||Math.abs(z)==50) {
            for(int y=0;y<5;y++) level.setBlock(o.offset(x,base-o.getY()+y,z),Blocks.BLUE_TERRACOTTA.defaultBlockState(),3);
            if((x+z)%8==0) level.setBlock(o.offset(x,base-o.getY()+5,z),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        int idx=1;
        for(int row=0;row<3;row++) for(int col=0;col<4;col++) {
            BlockPos p=oriented(o,right,f,-31+col*21,-28+row*27).above(base-o.getY());
            buildWorkshopGarage(level,p,idx++,r);
        }
        // Concrete lanes between the rows.
        for(int z=-46;z<=46;z++) for(int x=-2;x<=2;x++)
            level.setBlock(o.offset(x,base-o.getY()-1,z),Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
        for(int i=0;i<12;i++) {
            BlockPos lamp=o.offset((i%2==0?-1:1)*46,base-o.getY(),-42+i*7);
            level.setBlock(lamp,Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
            level.setBlock(lamp.above(4),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        if (register) registerLocation(level,"workshops",playerPos,yaw,seed,base,52,14,12,false);
    }

    private static void buildWorkshopGarage(ServerLevel level,BlockPos p,int index,RandomSource r) {
        int w=13,d=15,h=5;
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=p.offset(x,0,z);
            level.setBlock(q,Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) for(int y=1;y<=h;y++) {
                if(z==0 && x>=3 && x<=w-4 && y<=4) continue;
                level.setBlock(q.above(y), (r.nextInt(4)==0?Blocks.LIGHT_GRAY_CONCRETE:Blocks.BLUE_TERRACOTTA).defaultBlockState(),3);
            }
            if(yRoofEdge(x,z,w,d)) level.setBlock(q.above(h+1),Blocks.GRAY_CONCRETE.defaultBlockState(),3);
        }
        // Oversized solid iron-block garage shutter.
        for(int x=3;x<=w-4;x++) for(int y=1;y<=4;y++) level.setBlock(p.offset(x,y,0),Blocks.IRON_BLOCK.defaultBlockState(),3);
        BlockPos sign=p.offset(w/2,h+1,1);
        level.setBlock(sign,Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(w-2,1,2),Blocks.ANVIL.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,d-2),Blocks.SMITHING_TABLE.defaultBlockState(),3);
        fillGarageContainers(level,p,w,d,4+r.nextInt(3),r,true,LootProfile.GARAGE);
        level.setBlock(p.offset(w/2, h+2, d-2),Blocks.SEA_LANTERN.defaultBlockState(),3);
    }

    private static boolean yRoofEdge(int x,int z,int w,int d) { return x==0||x==w-1||z==0||z==d-1; }

    /** A landscaped premium residential district with four two-storey villas. */
    public static void generateLuxuryDistrict(ServerLevel level,BlockPos playerPos,float yaw) {
        generateLuxuryDistrict(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateLuxuryDistrict(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite();
        BlockPos o=playerPos.relative(f,16);
        int base=prepareFootprint(level,o,290,Blocks.GRASS_BLOCK,true,24);

        // Circular marble perimeter: polished diorite, calcite and quartz, with four monumental gates.
        for(int x=-286;x<=286;x++) for(int z=-286;z<=286;z++) {
            double d=Math.sqrt(x*x+z*z);
            if(d<281||d>286) continue;
            boolean gate=(Math.abs(x)<=7 && Math.abs(z)>=280)||(Math.abs(z)<=7 && Math.abs(x)>=280);
            if(gate) continue;
            for(int y=0;y<11;y++) {
                Block wall=(y==0||y==10)?Blocks.QUARTZ_BLOCK:
                        ((x+z+y)%7==0?Blocks.CALCITE:Blocks.POLISHED_DIORITE);
                level.setBlock(o.offset(x,base-o.getY()+y,z),wall.defaultBlockState(),3);
            }
            if((x+z)%9==0) level.setBlock(o.offset(x,base-o.getY()+11,z),Blocks.QUARTZ_BLOCK.defaultBlockState(),3);
        }
        // Gate piers and lanterns at the four cardinal entrances.
        for(Direction dir:Direction.Plane.HORIZONTAL) {
            for(int side:new int[]{-1,1}) {
                BlockPos pier=o.relative(dir,282).relative(dir.getClockWise(),side*9).offset(0,base-o.getY(),0);
                for(int y=0;y<13;y++) level.setBlock(pier.above(y),y%4==0?Blocks.QUARTZ_BLOCK.defaultBlockState():Blocks.POLISHED_DIORITE.defaultBlockState(),3);
                level.setBlock(pier.above(13),Blocks.SEA_LANTERN.defaultBlockState(),3);
            }
        }

        // Main avenues are broad; residential streets between houses stay deliberately narrow.
        for(int axis:new int[]{-170,0,170}) for(int t=-278;t<=278;t++) for(int w=-5;w<=5;w++) {
            if(Math.abs(axis+w)<=278 && (axis+w)*(axis+w)+t*t<=278*278)
                level.setBlock(o.offset(axis+w,base-o.getY()-1,t),Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
            if(Math.abs(axis+w)<=278 && t*t+(axis+w)*(axis+w)<=278*278)
                level.setBlock(o.offset(t,base-o.getY()-1,axis+w),Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
        }
        for(int gx=-9;gx<=8;gx++) for(int gz=-9;gz<=8;gz++) {
            int roadX=gx*34+17, roadZ=gz*34+17;
            for(int w=-2;w<=2;w++) for(int t=-278;t<=278;t++) {
                if(roadX*roadX+t*t<=278*278)
                    level.setBlock(o.offset(roadX+w,base-o.getY()-1,t),Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
                if(t*t+(roadZ+w)*(roadZ+w)<=278*278)
                    level.setBlock(o.offset(t,base-o.getY()-1,roadZ+w),Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
            }
        }

        // Small central plaza and monument replace the old fountain.
        for(int x=-25;x<=25;x++) for(int z=-25;z<=25;z++) {
            if(x*x+z*z>25*25) continue;
            level.setBlock(o.offset(x,base-o.getY()-1,z),Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
        }
        for(int y=0;y<2;y++) for(int x=-4+y;x<=4-y;x++) for(int z=-4+y;z<=4-y;z++)
            level.setBlock(o.offset(x,base-o.getY()+y,z),Blocks.POLISHED_DIORITE.defaultBlockState(),3);
        for(int y=2;y<=8;y++) {
            int rad=y<6?2:1;
            for(int x=-rad;x<=rad;x++) for(int z=-rad;z<=rad;z++)
                if(Math.abs(x)+Math.abs(z)<=rad+1)
                    level.setBlock(o.offset(x,base-o.getY()+y,z),(y%2==0?Blocks.QUARTZ_BLOCK:Blocks.CALCITE).defaultBlockState(),3);
        }
        level.setBlock(o.offset(0,base-o.getY()+9,0),Blocks.SEA_LANTERN.defaultBlockState(),3);

        // Dense, legible street grid: around 120 two-storey villas, with 7–10 containers in every house.
        int houseIndex=1;
        for(int gx=-8;gx<=8;gx++) for(int gz=-8;gz<=8;gz++) {
            if(Math.floorMod(gx,5)==0 || Math.floorMod(gz,5)==0) continue; // broad avenues
            int x=gx*34, z=gz*34;
            if(x*x+z*z>268*268 || x*x+z*z<48*48) continue;
            if((x-10)*(x-10)+(z-11)*(z-11)>270*270) continue;
            Direction front=gz<0?Direction.SOUTH:Direction.NORTH;
            BlockPos house=o.offset(x-10,base-o.getY(),z-11);
            buildLuxuryVilla(level,house,houseIndex++,r,front,7+r.nextInt(4));
            // Private front garden details and short stone paths from each villa to the lane.
            int fx=front==Direction.EAST?21:front==Direction.WEST?-1:10;
            int fz=front==Direction.SOUTH?23:front==Direction.NORTH?-1:11;
            for(int step=1;step<=5;step++) {
                BlockPos path=house.offset(fx+(front==Direction.EAST?step:front==Direction.WEST?-step:0),-1,
                        fz+(front==Direction.SOUTH?step:front==Direction.NORTH?-step:0));
                level.setBlock(path,Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
            }
            for(int side:new int[]{-2,22}) {
                BlockPos planter=house.offset(side,0,front==Direction.SOUTH?24:-2);
                level.setBlock(planter,r.nextBoolean()?Blocks.POTTED_POPPY.defaultBlockState():Blocks.POTTED_BLUE_ORCHID.defaultBlockState(),3);
            }
        }

        // Street furniture, lamps, trimmed trees and flower islands along the main avenues.
        for(int axis:new int[]{-170,0,170}) for(int t=-250;t<=250;t+=18) {
            for(int side:new int[]{-8,8}) {
                if((axis+side)*(axis+side)+t*t>278*278) continue;
                BlockPos lamp=o.offset(axis+side,base-o.getY(),t);
                for(int y=0;y<5;y++) level.setBlock(lamp.above(y),Blocks.QUARTZ_PILLAR.defaultBlockState(),3);
                level.setBlock(lamp.above(5),Blocks.SEA_LANTERN.defaultBlockState(),3);
                if(t%36==0) {
                    BlockPos tree=lamp.relative(Direction.EAST,4);
                    parkTree(level,tree,r);
                }
            }
        }
        if(register) registerLocation(level,"luxury",playerPos,yaw,seed,base,290,24,16,true);
    }


    private static void buildLuxuryVilla(ServerLevel level,BlockPos p,int index,RandomSource r,Direction front,int containerCount) {
        int w=21,d=23;
        int frontZ=front==Direction.SOUTH?d-1:0;
        int doorX=w/2;

        // Foundation and the two internal floors.
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            level.setBlock(p.offset(x,0,z),Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
            if(!(x>=2&&x<=6&&z==3)) level.setBlock(p.offset(x,5,z),Blocks.QUARTZ_BLOCK.defaultBlockState(),3);
        }

        // White exterior walls with large blue-glass windows on both storeys.
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            if(x!=0&&x!=w-1&&z!=0&&z!=d-1) continue;
            for(int y=1;y<=4;y++) {
                if(z==frontZ && x==doorX && y<=2) continue;
                boolean window=isVillaWindow(x,z,y,w,d);
                level.setBlock(p.offset(x,y,z),window?Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState():Blocks.WHITE_CONCRETE.defaultBlockState(),3);
            }
            for(int y=6;y<=9;y++) {
                boolean window=isVillaWindow(x,z,y-5,w,d);
                level.setBlock(p.offset(x,y,z),window?Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState():Blocks.WHITE_CONCRETE.defaultBlockState(),3);
            }
            level.setBlock(p.offset(x,10,z),Blocks.WHITE_CONCRETE.defaultBlockState(),3);
        }

        // Flat quartz roof with a low parapet and a small roof terrace.
        for(int x=0;x<w;x++) for(int z=0;z<d;z++)
            level.setBlock(p.offset(x,11,z),Blocks.QUARTZ_SLAB.defaultBlockState(),3);
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) if(x==0||x==w-1||z==0||z==d-1)
            level.setBlock(p.offset(x,12,z),Blocks.WHITE_CONCRETE.defaultBlockState(),3);
        for(int x=8;x<=12;x++) for(int z=8;z<=13;z++)
            level.setBlock(p.offset(x,11,z),Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(),3);

        // Entrance door, balcony and a few interior partitions to create separate rooms.
        level.setBlock(p.offset(doorX,1,frontZ),Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING,front),3);
        level.setBlock(p.offset(doorX,2,frontZ),Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING,front).setValue(DoorBlock.HALF,DoubleBlockHalf.UPPER),3);
        level.setBlock(p.offset(doorX,6,frontZ),Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING,front),3);
        level.setBlock(p.offset(doorX,7,frontZ),Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING,front).setValue(DoorBlock.HALF,DoubleBlockHalf.UPPER),3);
        int balconyZ=front==Direction.SOUTH?d:-1;
        for(int x=doorX-3;x<=doorX+3;x++) {
            level.setBlock(p.offset(x,5,balconyZ),Blocks.QUARTZ_SLAB.defaultBlockState(),3);
            level.setBlock(p.offset(x,6,balconyZ),Blocks.LIGHT_BLUE_STAINED_GLASS_PANE.defaultBlockState(),3);
        }
        for(int z=4;z<d-4;z++) {
            if(z==10||z==11||z==12) continue;
            level.setBlock(p.offset(10,1,z),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
            level.setBlock(p.offset(10,2,z),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
            level.setBlock(p.offset(10,3,z),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
        }
        for(int x=1;x<w-1;x++) {
            if(x>=9&&x<=11) continue;
            level.setBlock(p.offset(x,6,11),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
            level.setBlock(p.offset(x,7,11),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
            level.setBlock(p.offset(x,8,11),Blocks.WHITE_TERRACOTTA.defaultBlockState(),3);
        }

        // A usable stair run, living room, kitchen, dining area and upstairs bedrooms.
        for(int i=0;i<5;i++)
            level.setBlock(p.offset(2+i,1+i,3),Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.EAST),3);
        for(int x=3;x<=6;x++) level.setBlock(p.offset(x,1,16),Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.NORTH),3);
        level.setBlock(p.offset(5,1,18),Blocks.QUARTZ_SLAB.defaultBlockState(),3);
        level.setBlock(p.offset(14,1,3),Blocks.QUARTZ_BLOCK.defaultBlockState(),3);
        level.setBlock(p.offset(15,1,3),Blocks.QUARTZ_BLOCK.defaultBlockState(),3);
        level.setBlock(p.offset(16,1,3),Blocks.SMOKER.defaultBlockState(),3);
        level.setBlock(p.offset(17,1,3),Blocks.FURNACE.defaultBlockState(),3);
        level.setBlock(p.offset(18,1,3),Blocks.CAULDRON.defaultBlockState(),3);
        level.setBlock(p.offset(14,1,7),Blocks.OAK_FENCE.defaultBlockState(),3);
        level.setBlock(p.offset(14,2,7),Blocks.QUARTZ_SLAB.defaultBlockState(),3);
        level.setBlock(p.offset(17,1,7),Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.WEST),3);
        level.setBlock(p.offset(18,1,7),Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.WEST),3);
        level.setBlock(p.offset(3,6,15),Blocks.BOOKSHELF.defaultBlockState(),3);
        level.setBlock(p.offset(4,6,15),Blocks.BOOKSHELF.defaultBlockState(),3);
        level.setBlock(p.offset(17,6,15),Blocks.BOOKSHELF.defaultBlockState(),3);
        level.setBlock(p.offset(18,6,15),Blocks.LECTERN.defaultBlockState(),3);
        level.setBlock(p.offset(5,6,18),Blocks.QUARTZ_SLAB.defaultBlockState(),3);
        level.setBlock(p.offset(15,6,18),Blocks.FLOWER_POT.defaultBlockState(),3);
        level.setBlock(p.offset(15,6,17),Blocks.LANTERN.defaultBlockState(),3);
        placeBed(level,p.offset(4,6,8),Blocks.WHITE_BED,Direction.NORTH);
        placeBed(level,p.offset(15,6,8),Blocks.LIGHT_BLUE_BED,Direction.NORTH);

        // Soft lighting and white/blue interior accents.
        for(int[] lamp:new int[][]{{3,3,5},{17,3,5},{3,8,5},{17,8,5},{9,3,18},{9,8,18}})
            level.setBlock(p.offset(lamp[0],lamp[1],lamp[2]),Blocks.SEA_LANTERN.defaultBlockState(),3);
        for(int[] rug:new int[][]{{5,1,11},{6,1,11},{7,1,11},{14,6,11},{15,6,11},{16,6,11}})
            level.setBlock(p.offset(rug[0],rug[1],rug[2]),Blocks.LIGHT_BLUE_CARPET.defaultBlockState(),3);

        // 7–10 containers per villa, concentrated in the room corners and stacked vertically.
        int[][] storage={{2,1,2},{2,2,2},{18,1,2},{18,2,2},{2,1,20},{2,2,20},
                {18,1,20},{18,2,20},{2,6,2},{18,6,2},{2,6,20},{18,6,20}};
        boolean wearableSetUsed=false;
        for(int i=0;i<Math.min(containerCount,storage.length);i++) {
            BlockPos container=p.offset(storage[i][0],storage[i][1],storage[i][2]);
            boolean setDropped=placeLuxuryLootContainer(level,container,r,9+r.nextInt(5),!wearableSetUsed);
            if(setDropped) wearableSetUsed=true;
        }

        // Clipped white garden hedges, azaleas and blue-white flower beds.
        for(int x=2;x<w-2;x+=4) {
            int frontBushZ=front==Direction.SOUTH?d+2:-3;
            int backBushZ=front==Direction.SOUTH?-3:d+2;
            placeVillaBush(level,p.offset(x,0,backBushZ),r);
            if(Math.abs(x-doorX)>2) placeVillaBush(level,p.offset(x,0,frontBushZ),r);
        }
        for(int z=3;z<d-2;z+=5) {
            placeVillaBush(level,p.offset(-3,0,z),r);
            placeVillaBush(level,p.offset(w+2,0,z),r);
        }
        Block[] flowers={Blocks.WHITE_TULIP,Blocks.AZURE_BLUET,Blocks.BLUE_ORCHID,Blocks.ALLIUM};
        for(int i=0;i<12;i++) {
            int x=r.nextBoolean()?-4:w+3;
            int z=2+r.nextInt(d-4);
            level.setBlock(p.offset(x,0,z),flowers[r.nextInt(flowers.length)].defaultBlockState(),3);
        }
    }

    private static boolean isVillaWindow(int x,int z,int y,int w,int d) {
        if(y!=2&&y!=3) return false;
        if((z==0||z==d-1) && ((x>=3&&x<=7)||(x>=13&&x<=17))) return true;
        return (x==0||x==w-1) && ((z>=5&&z<=8)||(z>=14&&z<=17));
    }

    private static void placeBed(ServerLevel level,BlockPos footPos,Block bedBlock,Direction facing) {
        if(!(bedBlock instanceof BedBlock bed)) return;
        var foot=bed.defaultBlockState().setValue(BedBlock.FACING,facing).setValue(BedBlock.PART,BedPart.FOOT);
        level.setBlock(footPos,foot,3);
        level.setBlock(footPos.relative(facing),foot.setValue(BedBlock.PART,BedPart.HEAD),3);
    }

    private static void placeVillaBush(ServerLevel level,BlockPos p,RandomSource r) {
        Block leaves=r.nextBoolean()?Blocks.AZALEA_LEAVES:Blocks.FLOWERING_AZALEA_LEAVES;
        level.setBlock(p,leaves.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
        if(r.nextBoolean()) level.setBlock(p.above(),leaves.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
    }

    /** Five-storey white-and-green residential district with furnished rooms and 15-30 containers per block. */
    public static void generateApartments(ServerLevel level, BlockPos playerPos, float yaw) {
        generateApartments(level, playerPos, yaw, level.getRandom().nextLong(), true);
    }

    private static void generateApartments(ServerLevel level, BlockPos playerPos, float yaw, long seed, boolean register) {
        RandomSource r = RandomSource.create(seed);
        Direction f = Direction.fromYRot(yaw).getOpposite();
        BlockPos o = playerPos.relative(f, 16);
        int base = prepareFootprint(level, o, 290, Blocks.GRASS_BLOCK, true, 28);

        for (int x = -286; x <= 286; x++) for (int z = -286; z <= 286; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d < 281 || d > 286) continue;
            boolean gate = (Math.abs(x) <= 8 && Math.abs(z) >= 280) || (Math.abs(z) <= 8 && Math.abs(x) >= 280);
            if (gate) continue;
            for (int y = 0; y < 15; y++) {
                Block wall = y == 0 || y == 14 ? Blocks.WHITE_CONCRETE
                        : (y % 5 == 0 ? Blocks.LIME_CONCRETE : Blocks.QUARTZ_BLOCK);
                level.setBlock(o.offset(x, base - o.getY() + y, z), wall.defaultBlockState(), 3);
            }
            if ((x + z) % 11 == 0) level.setBlock(o.offset(x, base - o.getY() + 15, z), Blocks.LIME_STAINED_GLASS.defaultBlockState(), 3);
        }

        for (int axis : new int[]{-170, 0, 170}) for (int t = -278; t <= 278; t++) for (int w = -5; w <= 5; w++) {
            if ((axis + w) * (axis + w) + t * t <= 278 * 278)
                level.setBlock(o.offset(axis + w, base - o.getY() - 1, t), Blocks.SMOOTH_QUARTZ.defaultBlockState(), 3);
            if (t * t + (axis + w) * (axis + w) <= 278 * 278)
                level.setBlock(o.offset(t, base - o.getY() - 1, axis + w), Blocks.SMOOTH_QUARTZ.defaultBlockState(), 3);
        }
        for (int gx = -6; gx <= 6; gx++) for (int gz = -6; gz <= 6; gz++) {
            if (Math.floorMod(gx, 3) == 0 || Math.floorMod(gz, 3) == 0) continue;
            int x = gx * 48, z = gz * 48;
            if (x * x + z * z > 268 * 268 || x * x + z * z < 48 * 48) continue;
            BlockPos building = o.offset(x - 12, base - o.getY(), z - 12);
            buildApartmentBlock(level, building, r);
            for (int side : new int[]{-4, 28}) {
                BlockPos hedge = building.offset(side, 0, 4 + r.nextInt(16));
                placeVillaBush(level, hedge, r);
            }
        }

        buildWarriorMonument(level, o.offset(-8, base - o.getY() - 1, -8));
        for (int axis : new int[]{-170, 0, 170}) for (int t = -250; t <= 250; t += 20) {
            int tx = axis + (axis == 0 ? 12 : 10);
            if (tx * tx + t * t > 278 * 278) continue;
            BlockPos tree = o.offset(tx, base - o.getY(), t);
            parkTree(level, tree, r);
        }
        if (register) registerLocation(level, "apartments", playerPos, yaw, seed, base, 290, 28, 16, true);
    }

    private static void buildApartmentBlock(ServerLevel level, BlockPos p, RandomSource r) {
        int w = 25, d = 25, floors = 5, floorHeight = 4;
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
            level.setBlock(p.offset(x, 0, z), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
            for (int floor = 1; floor < floors; floor++)
                level.setBlock(p.offset(x, floor * floorHeight, z), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
            level.setBlock(p.offset(x, floors * floorHeight, z), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
        }
        for (int floor = 0; floor < floors; floor++) {
            int y0 = floor * floorHeight;
            for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
                if (x != 0 && x != w - 1 && z != 0 && z != d - 1) continue;
                for (int y = 1; y <= 3; y++) {
                    boolean window = (y == 2 || y == 3) && ((x % 5 == 0) || (z % 5 == 0));
                    Block facade = window ? Blocks.LIME_STAINED_GLASS : Blocks.WHITE_CONCRETE;
                    level.setBlock(p.offset(x, y0 + y, z), facade.defaultBlockState(), 3);
                }
            }
            // Room partitions, with a clear doorway between the two halves.
            for (int y = 1; y <= 3; y++) {
                for (int z = 2; z < d - 2; z++) if (z != 11 && z != 12 && z != 13)
                    level.setBlock(p.offset(12, y0 + y, z), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
                for (int x = 2; x < w - 2; x++) if (x != 11 && x != 12 && x != 13)
                    level.setBlock(p.offset(x, y0 + y, 12), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
            }
            placeBed(level, p.offset(3, y0 + 1, 18), floor % 2 == 0 ? Blocks.WHITE_BED : Blocks.LIME_BED, Direction.NORTH);
            level.setBlock(p.offset(19, y0 + 1, 4), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
            level.setBlock(p.offset(20, y0 + 1, 4), Blocks.BOOKSHELF.defaultBlockState(), 3);
            level.setBlock(p.offset(19, y0 + 1, 19), Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.WEST), 3);
            // Three stair blocks rise to the next landing; the top floor keeps a roof access stair.
            if (floor < floors - 1) {
                for (int step = 0; step < 3; step++)
                    level.setBlock(p.offset(3 + step, y0 + 1 + step, 4), Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.EAST), 3);
            }
        }
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++)
            if (x == 0 || x == w - 1 || z == 0 || z == d - 1)
                level.setBlock(p.offset(x, floors * floorHeight + 1, z), Blocks.LIME_CONCRETE.defaultBlockState(), 3);

        level.setBlock(p.offset(w / 2, 1, 0), Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH), 3);
        level.setBlock(p.offset(w / 2, 2, 0), Blocks.IRON_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH).setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 3);

        List<BlockPos> storage = new ArrayList<>();
        int[][] local = {{2, 2}, {22, 2}, {2, 8}, {22, 8}, {2, 16}, {22, 16}};
        for (int floor = 0; floor < floors; floor++) for (int[] pos : local)
            storage.add(p.offset(pos[0], floor * floorHeight + 1, pos[1]));
        Collections.shuffle(storage, new Random(r.nextLong()));
        int count = 15 + r.nextInt(16);
        boolean wearableSetUsed = false;
        for (int i = 0; i < count; i++) {
            boolean setDropped = placeProfileLootContainer(level, storage.get(i), r, 8 + r.nextInt(6), !wearableSetUsed,
                    LootProfile.APARTMENTS, 0.42f, false);
            if (setDropped) wearableSetUsed = true;
        }
    }

    private static void buildWarriorMonument(ServerLevel level, BlockPos p) {
        for (int y = 0; y < 3; y++) for (int x = -5 + y; x <= 5 - y; x++) for (int z = -5 + y; z <= 5 - y; z++)
            level.setBlock(p.offset(x, y, z), Blocks.POLISHED_DIORITE.defaultBlockState(), 3);
        for (int y = 3; y <= 8; y++) {
            level.setBlock(p.offset(-1, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(p.offset(0, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(p.offset(1, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(p.offset(0, y, 1), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        }
        for (int y = 9; y <= 12; y++) for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++)
            level.setBlock(p.offset(x, y, z), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        for (int y = 7; y <= 10; y++) {
            level.setBlock(p.offset(-2, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(p.offset(2, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        }
        // Raised sword and shield silhouette makes the monument readable from the main avenues.
        for (int y = 7; y <= 16; y++) level.setBlock(p.offset(4, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        for (int x = 3; x <= 5; x++) level.setBlock(p.offset(x, 16, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        for (int x = -5; x <= -3; x++) for (int y = 7; y <= 10; y++)
            level.setBlock(p.offset(x, y, 0), Blocks.IRON_BLOCK.defaultBlockState(), 3);
    }

    /** Mixed-use industrial city: residential quarters, chemical works and four central corporate towers. */
    public static void generateCity(ServerLevel level, BlockPos playerPos, float yaw) {
        generateCity(level, playerPos, yaw, level.getRandom().nextLong(), true);
    }

    private static void generateCity(ServerLevel level, BlockPos playerPos, float yaw, long seed, boolean register) {
        RandomSource r = RandomSource.create(seed);
        Direction f = Direction.fromYRot(yaw).getOpposite();
        BlockPos o = playerPos.relative(f, 18);
        int radius = 435;
        int base = prepareFootprint(level, o, radius, Blocks.GRASS_BLOCK, true, 185);

        // High perimeter wall with regular towers and gates.
        for (int x = -430; x <= 430; x++) for (int z = -430; z <= 430; z++) {
            double d = Math.sqrt(x * x + z * z);
            if (d < 426 || d > 430) continue;
            boolean gate = (Math.abs(x) < 12 && Math.abs(z) > 420) || (Math.abs(z) < 12 && Math.abs(x) > 420);
            if (gate) continue;
            for (int y = 0; y < 17; y++) {
                Block wall = y == 0 || y == 16 ? Blocks.WHITE_CONCRETE : (y % 4 == 0 ? Blocks.LIGHT_GRAY_CONCRETE : Blocks.STONE_BRICKS);
                level.setBlock(o.offset(x, base - o.getY() + y, z), wall.defaultBlockState(), 3);
            }
        }
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            for (int side : new int[]{-1, 1}) {
                BlockPos tower = o.relative(dir, 422).relative(dir.getClockWise(), side * 13).offset(0, base - o.getY(), 0);
                for (int y = 0; y < 23; y++) for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++)
                    if (Math.abs(dx) == 3 || Math.abs(dz) == 3)
                        level.setBlock(tower.offset(dx, y, dz), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
                level.setBlock(tower.above(23), Blocks.SEA_LANTERN.defaultBlockState(), 3);
            }
        }

        // Wide asphalt roads and dashed lane markings; each axis is a clear transport corridor.
        for (int axis = -360; axis <= 360; axis += 120) {
            for (int t = -420; t <= 420; t++) for (int w = -5; w <= 5; w++) {
                if ((axis + w) * (axis + w) + t * t <= 422 * 422)
                    level.setBlock(o.offset(axis + w, base - o.getY() - 1, t), Blocks.GRAY_CONCRETE.defaultBlockState(), 3);
                if (t * t + (axis + w) * (axis + w) <= 422 * 422)
                    level.setBlock(o.offset(t, base - o.getY() - 1, axis + w), Blocks.GRAY_CONCRETE.defaultBlockState(), 3);
            }
            for (int t = -410; t <= 410; t += 12) {
                for (int lane : new int[]{-2, 2}) {
                    level.setBlock(o.offset(axis + lane, base - o.getY() - 1, t), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
                    level.setBlock(o.offset(t, base - o.getY() - 1, axis + lane), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
                }
            }
        }

        // Central business district: one 58-storey landmark and three 20-35-storey headquarters.
        buildCorporateTower(level, o.offset(-18, base - o.getY(), -18), 58, 37, 37, r, true);
        buildCorporateTower(level, o.offset(-88, base - o.getY(), -78), 28, 31, 31, r, false);
        buildCorporateTower(level, o.offset(58, base - o.getY(), -78), 34, 31, 31, r, false);
        buildCorporateTower(level, o.offset(-15, base - o.getY(), 72), 23, 33, 33, r, false);

        // Low-rise residential quarter: detached houses with food, clothes and a guaranteed small tech item.
        for (int x = -330; x <= -205; x += 42) for (int z = -170; z <= 170; z += 43) {
            if (x * x + z * z > 410 * 410) continue;
            buildCitySmallHouse(level, o.offset(x - 7, base - o.getY(), z - 8), r);
        }

        // Wealthy homes in their own northern quarter.
        for (int x = -145; x <= 145; x += 48) for (int z = -315; z <= -235; z += 46) {
            if (x * x + z * z < 125 * 125) continue;
            buildLuxuryVilla(level, o.offset(x - 10, base - o.getY(), z - 11), r.nextInt(9999), r,
                    z < -270 ? Direction.SOUTH : Direction.NORTH, 7 + r.nextInt(4));
        }

        // Residential high-rises on the eastern side of the city.
        for (int x = 205; x <= 330; x += 62) for (int z = -185; z <= 185; z += 92) {
            if (x * x + z * z > 410 * 410) continue;
            buildCityResidentialTower(level, o.offset(x - 13, base - o.getY(), z - 13), 8 + r.nextInt(5), r);
        }

        // Two separate chemical/biotech campuses. Their containers use only serums, potions and compounds.
        buildChemicalPlant(level, o.offset(-155, base - o.getY(), 245), r);
        buildChemicalPlant(level, o.offset(95, base - o.getY(), 275), r);

        // A moderate resident population, tagged so restoreStructures can remove and respawn them cleanly.
        for (int i = 0; i < 28; i++) {
            int x = -310 + (i % 4) * 42;
            int z = -150 + (i / 4) * 43;
            BlockPos spawn = o.offset(x, base - o.getY(), z);
            Villager villager = EntityType.VILLAGER.create(level);
            if (villager != null) {
                villager.moveTo(spawn.getX() + 0.5, base, spawn.getZ() + 0.5, r.nextFloat() * 360.0f, 0.0f);
                villager.setPersistenceRequired();
                villager.getPersistentData().putBoolean("garageauction_generated", true);
                level.addFreshEntity(villager);
            }
        }

        if (register) registerLocation(level, "city", playerPos, yaw, seed, base, radius, 185, 18, true);
    }

    private static void buildCitySmallHouse(ServerLevel level, BlockPos p, RandomSource r) {
        int w = 15, d = 17, h = 6;
        Block[] walls = {Blocks.WHITE_CONCRETE, Blocks.SMOOTH_STONE, Blocks.BRICKS, Blocks.LIGHT_GRAY_CONCRETE};
        Block wall = walls[r.nextInt(walls.length)];
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
            level.setBlock(p.offset(x, 0, z), Blocks.STONE_BRICKS.defaultBlockState(), 3);
            if (x == 0 || x == w - 1 || z == 0 || z == d - 1)
                for (int y = 1; y <= h; y++) {
                    boolean window = (y == 2 || y == 3) && ((x == 0 || x == w - 1) && z % 4 == 0 || (z == 0 || z == d - 1) && x % 4 == 0);
                    level.setBlock(p.offset(x, y, z), window ? Blocks.GREEN_STAINED_GLASS.defaultBlockState() : wall.defaultBlockState(), 3);
                }
        }
        // Seven stepped roof layers form a clear triangular gable, with stairs on the sloped edges.
        for (int layer = 0; layer <= w / 2; layer++) for (int x = layer; x < w - layer; x++) for (int z = 0; z < d; z++) {
            int roofY = h + 1 + layer;
            if (x == layer)
                level.setBlock(p.offset(x, roofY, z), Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.EAST), 3);
            else if (x == w - 1 - layer)
                level.setBlock(p.offset(x, roofY, z), Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.WEST), 3);
            else level.setBlock(p.offset(x, roofY, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
        }
        level.setBlock(p.offset(w / 2, 1, 0), Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH), 3);
        level.setBlock(p.offset(w / 2, 2, 0), Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH).setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 3);
        placeBed(level, p.offset(3, 1, 11), Blocks.WHITE_BED, Direction.NORTH);
        level.setBlock(p.offset(10, 1, 3), Blocks.FURNACE.defaultBlockState(), 3);
        level.setBlock(p.offset(11, 1, 3), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
        Set<Long> used = new HashSet<>();
        int count = 5 + r.nextInt(4);
        boolean wearableSetUsed = false;
        for (int i = 0; i < count; i++) {
            BlockPos pos = null;
            for (int tries = 0; tries < 40; tries++) {
                int x = 2 + r.nextInt(w - 4), z = 2 + r.nextInt(d - 4);
                if ((x >= 9 && x <= 12 && z >= 2 && z <= 4) || (x >= 2 && x <= 4 && z >= 10 && z <= 13)) continue;
                BlockPos candidate = p.offset(x, 1, z);
                if (used.add(candidate.asLong())) { pos = candidate; break; }
            }
            if (pos != null) {
                boolean setDropped = placeProfileLootContainer(level, pos, r, 8 + r.nextInt(5), !wearableSetUsed,
                        LootProfile.CITY_SMALL_HOUSE, 0.38f, i == 0);
                if (setDropped) wearableSetUsed = true;
            }
        }
    }

    private static void buildCityResidentialTower(ServerLevel level, BlockPos p, int floors, RandomSource r) {
        int w = 27, d = 27, floorHeight = 3;
        for (int floor = 0; floor <= floors; floor++) {
            int y0 = floor * floorHeight;
            for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
                boolean shaft = x >= 12 && x <= 14 && z >= 12 && z <= 14;
                if (!shaft) level.setBlock(p.offset(x, y0, z), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
            }
        }
        for (int y = 1; y < floors * floorHeight; y++) for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
            if (x != 0 && x != w - 1 && z != 0 && z != d - 1) continue;
            boolean window = y % 3 != 0 && ((x + z) % 3 != 0);
            level.setBlock(p.offset(x, y, z), window ? Blocks.GREEN_STAINED_GLASS.defaultBlockState() : Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
        }
        boolean wearableSetUsed = false;
        for (int floor = 0; floor < floors; floor++) {
            int y = floor * floorHeight;
            for (int step = 0; step < 2; step++)
                level.setBlock(p.offset(4 + step, y + 1 + step, 4), Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.EAST), 3);
            for (int dy = 1; dy <= 2; dy++) {
                for (int z = 3; z < d - 3; z++) if (z < 11 || z > 15)
                    level.setBlock(p.offset(13, y + dy, z), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
                for (int x = 3; x < w - 3; x++) if (x < 11 || x > 15)
                    level.setBlock(p.offset(x, y + dy, 13), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
            }
            placeBed(level, p.offset(4, y + 1, 18), floor % 2 == 0 ? Blocks.WHITE_BED : Blocks.LIME_BED, Direction.NORTH);
            level.setBlock(p.offset(19, y + 1, 5), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
            boolean firstSet = placeProfileLootContainer(level, p.offset(3, y + 1, 8), r, 10 + r.nextInt(5),
                    !wearableSetUsed, LootProfile.CITY_HIGHRISE, 0.42f, false);
            if (firstSet) wearableSetUsed = true;
            if (floor % 2 == 0) {
                boolean secondSet = placeProfileLootContainer(level, p.offset(w - 5, y + 1, d - 8), r, 10 + r.nextInt(5),
                        !wearableSetUsed, LootProfile.CITY_HIGHRISE, 0.42f, false);
                if (secondSet) wearableSetUsed = true;
            }
            if (floor % 3 == 0) level.setBlock(p.offset(19, y + 1, 5), Blocks.LECTERN.defaultBlockState(), 3);
        }
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++)
            if (x == 0 || x == w - 1 || z == 0 || z == d - 1)
                level.setBlock(p.offset(x, floors * floorHeight + 1, z), Blocks.LIME_CONCRETE.defaultBlockState(), 3);
    }

    private static void buildCorporateTower(ServerLevel level, BlockPos p, int floors, int w, int d, RandomSource r, boolean landmark) {
        int floorHeight = 3, midX = w / 2, midZ = d / 2;
        int totalHeight = floors * floorHeight;
        for (int floor = 0; floor <= floors; floor++) {
            int y0 = floor * floorHeight;
            for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
                boolean elevatorShaft = x >= midX - 1 && x <= midX && z >= midZ - 1 && z <= midZ;
                if (!elevatorShaft) level.setBlock(p.offset(x, y0, z), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
            }
        }
        for (int y = 1; y < totalHeight; y++) for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
            if (x != 0 && x != w - 1 && z != 0 && z != d - 1) continue;
            boolean corner = (x == 0 || x == w - 1) && (z == 0 || z == d - 1);
            boolean glass = !corner && y % 3 != 0;
            Block facade = glass ? (landmark ? Blocks.LIGHT_BLUE_STAINED_GLASS : Blocks.GREEN_STAINED_GLASS) : Blocks.WHITE_CONCRETE;
            level.setBlock(p.offset(x, y, z), facade.defaultBlockState(), 3);
        }
        boolean wearableSetUsed = false;
        for (int floor = 0; floor < floors; floor++) {
            int y = floor * floorHeight;
            // Open 2x2 elevator shaft, glassed on its sides; stairs form a separate emergency route.
            for (int step = 0; step < 3; step++)
                level.setBlock(p.offset(4 + step, y + 1 + step, 4), Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.EAST), 3);
            if (!landmark || floor < floors - 3) {
                for (int dy = 1; dy <= 2; dy++) {
                    for (int z = 4; z < d - 4; z++) if (z < midZ - 2 || z > midZ + 2)
                        level.setBlock(p.offset(midX - 7, y + dy, z), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
                    for (int x = 4; x < w - 4; x++) if (x < midX - 2 || x > midX + 2)
                        level.setBlock(p.offset(x, y + dy, midZ + 7), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
                }
            }
            if (landmark && floor >= floors - 3) {
                level.setBlock(p.offset(10, y + 1, 10), Blocks.LECTERN.defaultBlockState(), 3);
                level.setBlock(p.offset(11, y + 1, 10), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
                level.setBlock(p.offset(12, y + 1, 10), Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.NORTH), 3);
                level.setBlock(p.offset(w - 11, y + 1, d - 11), Blocks.BOOKSHELF.defaultBlockState(), 3);
            }
            if (landmark || floor % 2 == 0) {
                boolean setDropped = placeProfileLootContainer(level, p.offset(5, y + 1, 9), r, 12 + r.nextInt(6),
                        !wearableSetUsed, LootProfile.CITY_CORPORATE, 0.42f, false);
                if (setDropped) wearableSetUsed = true;
            }
            if (landmark || floor % 3 == 0) {
                boolean setDropped = placeProfileLootContainer(level, p.offset(w - 6, y + 1, d - 9), r, 12 + r.nextInt(6),
                        !wearableSetUsed, LootProfile.CITY_CORPORATE, 0.42f, false);
                if (setDropped) wearableSetUsed = true;
            }
            if (floor % 4 == 0) {
                level.setBlock(p.offset(8, y + 1, d - 7), Blocks.LECTERN.defaultBlockState(), 3);
                level.setBlock(p.offset(9, y + 1, d - 7), Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.WEST), 3);
            }
        }
        // Transparent elevator shaft, with a two-block landing opening on the east side of every floor.
        if (landmark) {
            for (int y = 1; y < totalHeight; y++) {
                for (int offset = 0; offset < 2; offset++) {
                    level.setBlock(p.offset(midX - 2, y, midZ - 1 + offset), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(p.offset(midX - 1 + offset, y, midZ - 2), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(p.offset(midX - 1 + offset, y, midZ + 1), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 3);
                    if (y % floorHeight == 1 || y % floorHeight == 2)
                        level.setBlock(p.offset(midX + 1, y, midZ - 1 + offset), Blocks.AIR.defaultBlockState(), 3);
                    else
                        level.setBlock(p.offset(midX + 1, y, midZ - 1 + offset), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 3);
                }
            }
        }

        // Landmark's upper three floors are connected executive space with a gently curved panoramic facade.
        if (landmark) {
            for (int floor = Math.max(0, floors - 3); floor < floors; floor++) {
                int y0 = floor * floorHeight;
                for (int z = 4; z < d - 4; z++) {
                    int curve = Math.abs(z - midZ) / 8;
                    int x = w - 1 + curve;
                    for (int y = 1; y <= 2; y++)
                        level.setBlock(p.offset(x, y0 + y, z), Blocks.LIGHT_BLUE_STAINED_GLASS.defaultBlockState(), 3);
                }
                for (int x = 10; x < w - 10; x++)
                    level.setBlock(p.offset(x, y0 + 1, midZ), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
            }
            for (int y = totalHeight - 8; y < totalHeight - 1; y++) {
                level.setBlock(p.offset(9, y, 9), Blocks.SEA_LANTERN.defaultBlockState(), 3);
                level.setBlock(p.offset(w - 10, y, 9), Blocks.SEA_LANTERN.defaultBlockState(), 3);
            }
            level.setBlock(p.offset(midX, totalHeight + 1, midZ), Blocks.SEA_LANTERN.defaultBlockState(), 3);
        }
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++)
            if (x == 0 || x == w - 1 || z == 0 || z == d - 1)
                level.setBlock(p.offset(x, totalHeight + 1, z), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
    }

    private static void buildChemicalPlant(ServerLevel level, BlockPos p, RandomSource r) {
        int w = 49, d = 43;
        for (int x = 0; x < w; x++) for (int z = 0; z < d; z++) {
            level.setBlock(p.offset(x, 0, z), Blocks.GRAY_CONCRETE.defaultBlockState(), 3);
            if (x == 0 || x == w - 1 || z == 0 || z == d - 1)
                for (int y = 1; y <= 7; y++) level.setBlock(p.offset(x, y, z), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), 3);
        }
        // Main processing hall and two elevated chemical stacks.
        for (int x = 5; x < 29; x++) for (int z = 5; z < 22; z++) {
            if (x == 5 || x == 28 || z == 5 || z == 21)
                for (int y = 1; y <= 8; y++) level.setBlock(p.offset(x, y, z), y == 4 ? Blocks.GREEN_STAINED_GLASS.defaultBlockState() : Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(p.offset(x, 9, z), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        }
        for (int tower = 0; tower < 1; tower++) {
            int tx = 34, tz = 11;
            for (int y = 1; y <= 31; y++) for (int dx = 0; dx < 7; dx++) for (int dz = 0; dz < 7; dz++) {
                if (dx == 0 || dx == 6 || dz == 0 || dz == 6)
                    level.setBlock(p.offset(tx + dx, y, tz + dz), y % 5 == 0 ? Blocks.GREEN_STAINED_GLASS.defaultBlockState() : Blocks.IRON_BARS.defaultBlockState(), 3);
            }
            for (int x = 0; x < 9; x++) for (int z = 0; z < 9; z++)
                if (x == 0 || x == 8 || z == 0 || z == 8)
                    level.setBlock(p.offset(tx - 1 + x, 32, tz - 1 + z), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        }
        for (int i = 0; i < 14; i++) {
            int x = 3 + r.nextInt(w - 6), z = 3 + r.nextInt(d - 6);
            if (x >= 5 && x <= 28 && z >= 5 && z <= 21) continue;
            if (x >= 33 && x <= 41 && z >= 10 && z <= 18) continue;
            placeProfileLootContainer(level, p.offset(x, 1, z), r, 10 + r.nextInt(6), false, LootProfile.CITY_CHEMICAL, 0.35f, false);
        }
    }


    public static void generateArena(ServerLevel level,BlockPos playerPos,float yaw) {
        generateArena(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateArena(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        BlockPos o=playerPos.relative(Direction.fromYRot(yaw).getOpposite(),12);
        int base=prepareFootprint(level,o,62,Blocks.STONE_BRICKS,true,18);
        for(int x=-60;x<=60;x++) for(int z=-60;z<=60;z++) {
            double d=Math.sqrt(x*x+z*z); if(d>60) continue;
            BlockPos p=o.offset(x,base-o.getY()-1,z);
            level.setBlock(p,d<38?Blocks.SMOOTH_STONE.defaultBlockState():Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            if(d>48) for(int y=0;y<5;y++) level.setBlock(p.above(y+1),Blocks.STONE_BRICKS.defaultBlockState(),3);
        }
        // Tiered circular spectator stands.
        for(int ring=39;ring<=57;ring++) {
            int rise=(ring-39)/3;
            for(int a=0;a<720;a++) {
                double ang=a*Math.PI/360; int x=(int)(ring*Math.cos(ang)),z=(int)(ring*Math.sin(ang));
                BlockPos p=o.offset(x,base-o.getY()+rise,z);
                level.setBlock(p,ring%2==0?Blocks.POLISHED_ANDESITE.defaultBlockState():Blocks.GRAY_CONCRETE.defaultBlockState(),3);
                if(ring%3==0) level.setBlock(p.above(),Blocks.STONE_BRICK_STAIRS.defaultBlockState(),3);
            }
        }
        // Four lighting towers outside the fighting floor; no containers or loot.
        for(int a=0;a<16;a++) {
            double ang=a*Math.PI/8; int x=(int)(55*Math.cos(ang)),z=(int)(55*Math.sin(ang));
            BlockPos p=o.offset(x,base-o.getY(),z);
            for(int y=0;y<11;y++) level.setBlock(p.above(y),Blocks.IRON_BARS.defaultBlockState(),3);
            level.setBlock(p.above(11),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        for(int a=0;a<8;a++) {
            double ang=a*Math.PI/4; BlockPos p=o.offset((int)(33*Math.cos(ang)),base-o.getY(),(int)(33*Math.sin(ang)));
            level.setBlock(p,Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        if(register) registerLocation(level,"arena",playerPos,yaw,seed,base,62,18,12,true);
    }

    /** Spawn the huge circular glitch biome with infected buildings and strong loot. */
    public static void generateMatrix(ServerLevel level,BlockPos playerPos,float yaw) {
        generateMatrix(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateMatrix(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite();
        BlockPos o=playerPos.relative(f,12);
        int radius=315;
        int base=prepareFootprint(level,o,radius,Blocks.BLACK_TERRACOTTA,true,28);
        Block[] palette={Blocks.BLACK_TERRACOTTA,Blocks.GREEN_TERRACOTTA,Blocks.BLUE_TERRACOTTA,
                Blocks.RED_TERRACOTTA,Blocks.ORANGE_TERRACOTTA,Blocks.PINK_TERRACOTTA,Blocks.LIGHT_BLUE_TERRACOTTA};
        int[][] heights=new int[radius*2+1][radius*2+1];

        // Pixelated, uneven terrain: the base layer is stable while coloured ridges rise and fall above it.
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            double distance=Math.sqrt(x*x+z*z);
            if(distance>radius) continue;
            Random column=new Random(seed + (long)x*341873128712L + (long)z*132897987541L);
            double waves=Math.sin(x*0.043+Math.cos(z*0.027))*4.0 + Math.cos(z*0.039-x*0.021)*3.0;
            int h=Math.max(0,Math.min(13,4+(int)Math.round(waves)+column.nextInt(5)-2));
            heights[x+radius][z+radius]=h;
            int colour=column.nextInt(palette.length);
            for(int y=0;y<=h;y++) {
                Block block=(y==h || y%3==0)?palette[(colour+(y==h?0:y/3))%palette.length]:palette[colour];
                level.setBlock(o.offset(x,base-o.getY()+y,z),block.defaultBlockState(),3);
            }
        }

        // Jagged fissures cut down through the coloured surface; their edges look like broken pixels.
        for(int crack=0;crack<24;crack++) {
            double angle=r.nextDouble()*Math.PI*2.0;
            int jitter=0;
            for(int step=4;step<radius-5;step++) {
                jitter+=r.nextInt(3)-1;
                int cx=(int)Math.round(Math.cos(angle)*step)+jitter;
                int cz=(int)Math.round(Math.sin(angle)*step)-jitter/2;
                int width=1+r.nextInt(3);
                for(int dx=-width;dx<=width;dx++) for(int dz=-width;dz<=width;dz++) {
                    if(cx*cx+cz*cz>radius*radius) continue;
                    int x=cx+dx,z=cz+dz;
                    if(x < -radius || x > radius || z < -radius || z > radius || x*x+z*z>radius*radius) continue;
                    int h=heights[x+radius][z+radius];
                    int top=base+h;
                    Block fissure=(r.nextInt(5)==0?Blocks.GREEN_TERRACOTTA:Blocks.BLACK_TERRACOTTA);
                    for(int depth=0;depth<Math.min(3,h+1);depth++)
                        level.setBlock(o.offset(x,top-depth-o.getY(),z),fissure.defaultBlockState(),3);
                    if(Math.abs(dx)==width || Math.abs(dz)==width)
                        level.setBlock(o.offset(x,top+1-o.getY(),z),palette[r.nextInt(palette.length)].defaultBlockState(),3);
                }
            }
        }

        // Mixed structures imported from the park, scrapyard, workshop yard and luxury district.
        int imported=0;
        for(int gx=-7;gx<=7;gx++) for(int gz=-7;gz<=7;gz++) {
            int x=gx*38+(r.nextInt(7)-3),z=gz*38+(r.nextInt(7)-3);
            if(x*x+z*z>260*260 || r.nextFloat()<0.30f) continue;
            int roll=r.nextInt(100);
            if(roll<22) {
                BlockPos c=prepareSmallPad(level,o.offset(x,0,z),5,5,Blocks.BLACK_TERRACOTTA);
                BlockPos p=c.offset(-4,0,-5);
                Block[] parkRoofs={Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL,Blocks.ORANGE_WOOL,Blocks.PURPLE_WOOL};
                buildParkCottage(level,p,imported+1,parkRoofs[r.nextInt(parkRoofs.length)],r);
                infectExterior(level,p,9,10,6,palette,r);
            } else if(roll<47) {
                BlockPos c=prepareSmallPad(level,o.offset(x,0,z),7,8,Blocks.BLACK_TERRACOTTA);
                BlockPos p=c.offset(-6,0,-7);
                buildWorkshopGarage(level,p,imported+1,r);
                infectExterior(level,p,13,15,7,palette,r);
            } else if(roll<63) {
                BlockPos c=prepareSmallPad(level,o.offset(x,0,z),11,12,Blocks.BLACK_TERRACOTTA);
                BlockPos p=c.offset(-10,0,-11);
                buildLuxuryVilla(level,p,imported+1,r,r.nextBoolean()?Direction.SOUTH:Direction.NORTH,7+r.nextInt(4));
                infectExterior(level,p,21,23,14,palette,r);
            } else {
                BlockPos c=o.offset(x,base-o.getY()+heights[Math.max(0,Math.min(radius*2,x+radius))][Math.max(0,Math.min(radius*2,z+radius))],z);
                int moundRadius=3+r.nextInt(3);
                rubbleMound(level,c,moundRadius,3+r.nextInt(5),r);
                for(int n=0;n<2+r.nextInt(3);n++)
                    placeLootContainer(level,c.offset((n%2==0?-1:1)*(moundRadius+1),0,(n/2)*(moundRadius+1)),r,18+r.nextInt(8),false,false,true);
            }
            imported++;
        }

        // The Matrix's own sealed square garages: no door, break through the terracotta wall to enter.
        for(int i=0;i<16;i++) {
            double angle=i*Math.PI/8.0;
            int x=(int)(280*Math.cos(angle)),z=(int)(280*Math.sin(angle));
            BlockPos c=prepareSmallPad(level,o.offset(x,0,z),8,8,Blocks.BLACK_TERRACOTTA);
            buildMatrixGarage(level,c.offset(-6,0,-6),r,palette);
        }

        // A small number of loose searchable containers scattered across the broken terrain.
        for(int i=0;i<42;i++) {
            int x=r.nextInt(520)-260,z=r.nextInt(520)-260;
            if(x*x+z*z>270*270) { i--; continue; }
            int y=surfaceY(level,o.getX()+x,o.getZ()+z);
            placeMatrixLootContainer(level,new BlockPos(o.getX()+x,y,o.getZ()+z),r,20+r.nextInt(8),false);
        }
        if(register) registerLocation(level,"matrix",playerPos,yaw,seed,base,radius,28,12,true);
    }

    private static BlockPos prepareSmallPad(ServerLevel level,BlockPos center,int halfX,int halfZ,Block floor) {
        int base=surfaceY(level,center.getX(),center.getZ());
        BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
        for(int x=-halfX;x<=halfX;x++) for(int z=-halfZ;z<=halfZ;z++) {
            int wx=center.getX()+x,wz=center.getZ()+z,top=surfaceY(level,wx,wz);
            if(top>base) for(int y=top-1;y>=base;y--) {pos.set(wx,y,wz);level.removeBlock(pos,false);}
            else if(top<base) for(int y=top-1;y<base-1;y++) {pos.set(wx,y,wz);level.setBlock(pos,Blocks.DIRT.defaultBlockState(),3);}
            pos.set(wx,base-1,wz);level.setBlock(pos,floor.defaultBlockState(),3);
        }
        return new BlockPos(center.getX(),base,center.getZ());
    }

    private static void infectExterior(ServerLevel level,BlockPos p,int w,int d,int height,Block[] palette,RandomSource r) {
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            boolean edge=x==0||x==w-1||z==0||z==d-1;
            for(int y=1;y<=height;y++) {
                boolean roofPixel=(y==5||y==6||y==11||y==height-1);
                if(!edge && !roofPixel) continue;
                if(r.nextFloat()>0.27f) continue;
                BlockPos at=p.offset(x,y,z);
                if(level.getBlockState(at).isAir() || level.getBlockState(at).getBlock() instanceof DoorBlock) continue;
                level.setBlock(at,palette[r.nextInt(palette.length)].defaultBlockState(),3);
            }
        }
    }

    private static void buildMatrixGarage(ServerLevel level,BlockPos p,RandomSource r,Block[] palette) {
        int w=13,d=13,h=5;
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            level.setBlock(p.offset(x,0,z),palette[r.nextInt(palette.length)].defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1)
                for(int y=1;y<=h;y++) level.setBlock(p.offset(x,y,z),palette[r.nextInt(palette.length)].defaultBlockState(),3);
            level.setBlock(p.offset(x,h+1,z),palette[r.nextInt(palette.length)].defaultBlockState(),3);
        }
        int count=3+r.nextInt(5); Set<Long> used=new HashSet<>(); boolean setUsed=false;
        for(int i=0;i<count;i++) {
            int x=2+r.nextInt(w-4),z=2+r.nextInt(d-4);
            BlockPos barrel=p.offset(x,1,z);
            if(!used.add(barrel.asLong())) {i--;continue;}
            if(placeMatrixBarrel(level,barrel,r,22+r.nextInt(7),!setUsed)) setUsed=true;
        }
    }

    private static boolean placeMatrixBarrel(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowSet) {
        ContainerPlacement placement = findContainerPlacement(level, pos, r, 1.0f);
        if (placement == null) return false;
        level.setBlock(placement.pos(), Blocks.BARREL.defaultBlockState(), 3);
        BlockEntity be=level.getBlockEntity(placement.pos());
        if(be instanceof Container container) {
            LootScanner.LootResult loot=LootScanner.generateMatrixContainerLootResult(new Random(r.nextLong()),target,allowSet);
            fillRandomSlots(container,loot.items(),r);
            be.getPersistentData().putString("GarageAuctionLootProfile", LootProfile.MATRIX.name());
            return loot.includesWearableSet();
        }
        return false;
    }

    private static boolean placeMatrixLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowSet) {
        ContainerPlacement placement = findContainerPlacement(level, pos, r, 0.55f);
        if (placement == null) return false;
        level.setBlock(placement.pos(), placement.barrel() ? Blocks.BARREL.defaultBlockState() : Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity be=level.getBlockEntity(placement.pos());
        if(be instanceof Container container) {
            LootScanner.LootResult loot=LootScanner.generateMatrixContainerLootResult(new Random(r.nextLong()),target,allowSet);
            fillRandomSlots(container,loot.items(),r);
            be.getPersistentData().putString("GarageAuctionLootProfile", LootProfile.MATRIX.name());
            return loot.includesWearableSet();
        }
        return false;
    }

    /** Medieval castle yard with a cobblestone curtain wall and barrel-only armories. */
    public static void generateCastles(ServerLevel level,BlockPos playerPos,float yaw) {
        generateCastles(level,playerPos,yaw,level.getRandom().nextLong(),true);
    }

    private static void generateCastles(ServerLevel level,BlockPos playerPos,float yaw,long seed,boolean register) {
        RandomSource r=RandomSource.create(seed);
        Direction f=Direction.fromYRot(yaw).getOpposite();
        BlockPos o=playerPos.relative(f,12);
        int base=prepareFootprint(level,o,132,Blocks.COARSE_DIRT,true,22);
        for(int x=-130;x<=130;x++) for(int z=-130;z<=130;z++) {
            double d=Math.sqrt(x*x+z*z); if(d>130) continue;
            BlockPos ground=o.offset(x,base-o.getY()-1,z);
            level.setBlock(ground,d<95?Blocks.STONE_BRICKS.defaultBlockState():Blocks.COBBLESTONE.defaultBlockState(),3);
        }
        // Thick circular defensive wall with battlements and four gatehouses.
        for(int x=-129;x<=129;x++) for(int z=-129;z<=129;z++) {
            double d=Math.sqrt(x*x+z*z); if(d<124||d>129) continue;
            boolean gate=(Math.abs(x)<=6&&Math.abs(z)>=123)||(Math.abs(z)<=6&&Math.abs(x)>=123);
            if(gate) continue;
            for(int y=0;y<8;y++) {
                Block wall=(y==0||y==7)?Blocks.STONE_BRICKS:((x+z)%5==0?Blocks.MOSSY_STONE_BRICKS:Blocks.COBBLESTONE);
                level.setBlock(o.offset(x,base-o.getY()+y,z),wall.defaultBlockState(),3);
            }
            if((x+z)%4==0) level.setBlock(o.offset(x,base-o.getY()+8,z),Blocks.STONE_BRICK_WALL.defaultBlockState(),3);
        }
        for(Direction dir:Direction.Plane.HORIZONTAL) for(int side:new int[]{-1,1}) {
            BlockPos tower=o.relative(dir,124).relative(dir.getClockWise(),side*8).offset(0,base-o.getY(),0);
            for(int y=0;y<11;y++) for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++)
                if(Math.abs(dx)==2||Math.abs(dz)==2) level.setBlock(tower.offset(dx,y,dz),y%3==0?Blocks.STONE_BRICKS.defaultBlockState():Blocks.COBBLESTONE.defaultBlockState(),3);
            level.setBlock(tower.above(11),Blocks.TORCH.defaultBlockState(),3);
        }
        // Two rings of small keeps, all with 5–8 barrels and a maximum of two complete sets each.
        for(int ring=0;ring<2;ring++) {
            int count=ring==0?8:12,rad=ring==0?62:96;
            for(int i=0;i<count;i++) {
                double angle=(Math.PI*2*i/count)+(ring==0?0:Math.PI/count);
                int x=(int)(rad*Math.cos(angle)),z=(int)(rad*Math.sin(angle));
                BlockPos c=prepareSmallPad(level,o.offset(x,0,z),11,11,Blocks.STONE_BRICKS);
                buildCastleKeep(level,c.offset(-9,0,-10),r);
            }
        }
        // A central armory keep gives the medieval district a readable focal point.
        BlockPos center=prepareSmallPad(level,o,13,13,Blocks.STONE_BRICKS);
        buildCastleKeep(level,center.offset(-11,0,-11),r);
        if(register) registerLocation(level,"castles",playerPos,yaw,seed,base,132,22,12,true);
    }

    private static void buildCastleKeep(ServerLevel level,BlockPos p,RandomSource r) {
        int w=19,d=21,h=7;
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            level.setBlock(p.offset(x,0,z),Blocks.STONE_BRICKS.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) {
                for(int y=1;y<=h;y++) level.setBlock(p.offset(x,y,z),(r.nextInt(5)==0?Blocks.MOSSY_STONE_BRICKS:Blocks.COBBLESTONE).defaultBlockState(),3);
                if((x+z)%2==0) level.setBlock(p.offset(x,h+1,z),Blocks.STONE_BRICK_WALL.defaultBlockState(),3);
            }
        }
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) level.setBlock(p.offset(x,h+1,z),Blocks.STONE_BRICKS.defaultBlockState(),3);
        // Four raised corner towers and a single correctly fitted oak entrance.
        for(int tx:new int[]{0,w-3}) for(int tz:new int[]{0,d-3}) {
            for(int x=0;x<3;x++) for(int z=0;z<3;z++) for(int y=1;y<=h+3;y++)
                if(x==0||x==2||z==0||z==2) level.setBlock(p.offset(tx+x,y,tz+z),Blocks.STONE_BRICKS.defaultBlockState(),3);
            for(int x=0;x<3;x++) for(int z=0;z<3;z++) level.setBlock(p.offset(tx+x,h+4,tz+z),Blocks.COBBLESTONE.defaultBlockState(),3);
        }
        int doorX=w/2;
        for(int y=1;y<=2;y++) level.setBlock(p.offset(doorX,y,0),Blocks.AIR.defaultBlockState(),3);
        level.setBlock(p.offset(doorX,1,0),Blocks.DARK_OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH),3);
        level.setBlock(p.offset(doorX,2,0),Blocks.DARK_OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH).setValue(DoorBlock.HALF,DoubleBlockHalf.UPPER),3);
        // Armory details; every storage block is a barrel, never a chest.
        level.setBlock(p.offset(3,1,3),Blocks.GRINDSTONE.defaultBlockState(),3);
        level.setBlock(p.offset(w-4,1,3),Blocks.ANVIL.defaultBlockState(),3);
        level.setBlock(p.offset(3,1,d-4),Blocks.SMITHING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(w-4,1,d-4),Blocks.FLETCHING_TABLE.defaultBlockState(),3);
        int count=5+r.nextInt(4); Set<Long> used=new HashSet<>(); int sets=0;
        for(int i=0;i<count;i++) {
            BlockPos barrel=null;
            for(int tries=0;tries<40;tries++) {
                int x=2+r.nextInt(w-4),z=2+r.nextInt(d-4);
                BlockPos candidate=p.offset(x,1,z);
                if(used.add(candidate.asLong())) {barrel=candidate;break;}
            }
            if(barrel!=null && placeCastleBarrel(level,barrel,r,18+r.nextInt(8),sets<2)) sets++;
        }
        for(int x=4;x<w-4;x+=5) level.setBlock(p.offset(x,h+2,d/2),Blocks.TORCH.defaultBlockState(),3);
    }

    private static boolean placeCastleBarrel(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowSet) {
        ContainerPlacement placement = findContainerPlacement(level, pos, r, 1.0f);
        if (placement == null) return false;
        level.setBlock(placement.pos(), Blocks.BARREL.defaultBlockState(), 3);
        BlockEntity be=level.getBlockEntity(placement.pos());
        if(be instanceof Container container) {
            LootScanner.LootResult loot=LootScanner.generateCastleContainerLootResult(new Random(r.nextLong()),target,allowSet);
            fillRandomSlots(container,loot.items(),r);
            be.getPersistentData().putString("GarageAuctionLootProfile", LootProfile.CASTLE.name());
            return loot.includesWearableSet();
        }
        return false;
    }

    private static void registerLocation(ServerLevel level,String type,BlockPos playerPos,float yaw,long seed,
                                         int base,int radius,int maxHeight,int offset,boolean circular) {
        StructureRegistryData.get(level).add(new StructureRegistryData.LocationRecord(
                type,playerPos.getX(),base,playerPos.getZ(),yaw,seed,radius,maxHeight,offset,circular));
    }

    /** Restores every location registered by this mod in the current dimension, in place. */
    public static int restoreStructures(ServerLevel level) {
        List<StructureRegistryData.LocationRecord> records=StructureRegistryData.get(level).getLocations();
        int restored=0;
        for(StructureRegistryData.LocationRecord record:records) {
            BlockPos anchor=new BlockPos(record.x(),record.y(),record.z());
            if(record.type().startsWith("batch_")) {
                String batchType=record.type().substring(6);
                BlockPos clearCenter=switch(batchType) {
                    case "square" -> anchor.offset(4,0,5);
                    case "workshop" -> anchor.offset(6,0,7);
                    case "luxury" -> anchor.offset(10,0,11);
                    default -> anchor;
                };
                clearGeneratedArea(level,clearCenter,record.y(),record.radius(),record.maxHeight(),false);
                rebuildBatchObject(level,batchType,anchor,record.seed());
                restored++;
                continue;
            }
            Direction forward=Direction.fromYRot(record.yaw()).getOpposite();
            BlockPos center=anchor.relative(forward,record.offset());
            clearGeneratedArea(level,center,record.y(),record.radius(),record.maxHeight(),record.circular());
            switch(record.type()) {
                case "park" -> generatePark(level,anchor,record.yaw(),record.seed(),false);
                case "scrapyard" -> generateScrapyard(level,anchor,record.yaw(),record.seed(),false);
                case "workshops" -> generateGarages(level,anchor,record.yaw(),record.seed(),false);
                case "luxury" -> generateLuxuryDistrict(level,anchor,record.yaw(),record.seed(),false);
                case "arena" -> generateArena(level,anchor,record.yaw(),record.seed(),false);
                case "matrix" -> generateMatrix(level,anchor,record.yaw(),record.seed(),false);
                case "castles" -> generateCastles(level,anchor,record.yaw(),record.seed(),false);
                case "apartments" -> generateApartments(level,anchor,record.yaw(),record.seed(),false);
                case "city" -> generateCity(level,anchor,record.yaw(),record.seed(),false);
                default -> { continue; }
            }
            restored++;
        }
        return restored;
    }

    private static void clearGeneratedArea(ServerLevel level,BlockPos center,int baseY,int radius,int maxHeight,boolean circular) {
        BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
        int maxY=Math.min(level.getMaxBuildHeight()-1,baseY+maxHeight);
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            if(circular && x*x+z*z>radius*radius) continue;
            for(int y=baseY;y<=maxY;y++) {
                pos.set(center.getX()+x,y,center.getZ()+z);
                if(!level.getBlockState(pos).isAir()) level.removeBlock(pos,false);
            }
        }
        AABB bounds = new AABB(center.getX()-radius,Math.max(level.getMinBuildHeight(),baseY-8),center.getZ()-radius,
                center.getX()+radius+1,maxY+1,center.getZ()+radius+1);
        level.getEntitiesOfClass(ArmorStand.class, bounds).stream()
                .filter(entity -> !circular || Math.pow(entity.getX()-center.getX(),2)+Math.pow(entity.getZ()-center.getZ(),2) <= radius*radius)
                .forEach(entity -> entity.discard());
        level.getEntitiesOfClass(ItemEntity.class, bounds).stream()
                .filter(entity -> !circular || Math.pow(entity.getX()-center.getX(),2)+Math.pow(entity.getZ()-center.getZ(),2) <= radius*radius)
                .forEach(entity -> entity.discard());
        level.getEntitiesOfClass(Villager.class, bounds).stream()
                .filter(v -> v.getPersistentData().getBoolean("garageauction_generated"))
                .filter(v -> !circular || Math.pow(v.getX()-center.getX(),2)+Math.pow(v.getZ()-center.getZ(),2) <= radius*radius)
                .forEach(v -> v.discard());
    }

    private static void rebuildBatchObject(ServerLevel level,String type,BlockPos p,long seed) {
        RandomSource r=RandomSource.create(seed);
        switch(type) {
            case "square" -> buildParkCottage(level,p,1,new Block[]{Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL}[r.nextInt(4)],r);
            case "workshop" -> buildWorkshopGarage(level,p,1,r);
            case "luxury" -> buildLuxuryVilla(level,p,1,r,Direction.SOUTH,7+r.nextInt(4));
            case "scrapyard" -> {
                int moundRadius=4+r.nextInt(3);
                rubbleMound(level,p,moundRadius,3+r.nextInt(4),r);
                for(int c=0;c<3;c++) placeLootContainer(level,p.offset((c-1)*(moundRadius+2),0,moundRadius+2),r,16+r.nextInt(8),false,false,true);
            }
        }
    }

    /** Spawn a requested number of independent objects in a straight row in front of the player. */
    public static int spawnBatch(ServerLevel level,BlockPos playerPos,float yaw,String type,int count) {
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        int made=0;
        String normalized=type.toLowerCase(Locale.ROOT);
        int spacing=("luxury".equals(normalized)||"villa".equals(normalized))?28:16;
        for(int i=0;i<count;i++) {
            BlockPos p=playerPos.relative(f,8).relative(right,(int)((i-(count-1)/2.0)*spacing));
            int y=surfaceY(level,p.getX(),p.getZ()); p=new BlockPos(p.getX(),y,p.getZ());
            long itemSeed=level.getRandom().nextLong();
            String storedType;
            int radius,maxHeight;
            if(normalized.equals("square")) {storedType="square";radius=7;maxHeight=10;}
            else if(normalized.equals("workshop")||normalized.equals("garage")) {storedType="workshop";radius=8;maxHeight=12;}
            else if(normalized.equals("luxury")||normalized.equals("villa")) {storedType="luxury";radius=13;maxHeight=16;}
            else if(normalized.equals("scrapyard")||normalized.equals("trash")) {storedType="scrapyard";radius=8;maxHeight=10;}
            else throw new IllegalArgumentException("Тип: square, workshop, luxury или scrapyard");
            rebuildBatchObject(level,storedType,p,itemSeed);
            StructureRegistryData.get(level).add(new StructureRegistryData.LocationRecord(
                    "batch_"+storedType,p.getX(),p.getY(),p.getZ(),0.0f,itemSeed,radius,maxHeight,0,false));
            made++;
        }
        return made;
    }

    private static void fillGarageContainers(ServerLevel level,BlockPos p,int w,int d,int count,RandomSource r,
                                             boolean allowWearableSet,LootProfile profile) {
        Set<Long> used=new HashSet<>(); boolean wearableSetUsed=false;
        for(int i=0;i<count;i++) {
            BlockPos cp=null;
            for(int tries=0;tries<60;tries++) {
                int x=1+r.nextInt(w-2),z=1+r.nextInt(d-2);
                if(z<3 && x>w/2-2 && x<w/2+2) continue;
                BlockPos candidate=p.offset(x,1,z);
                if(used.add(candidate.asLong())) {cp=candidate;break;}
            }
            if(cp==null) continue;
            boolean setDropped=placeProfileLootContainer(level,cp,r,12+r.nextInt(8),allowWearableSet&&!wearableSetUsed,
                    profile,0.38f,false);
            if(setDropped) wearableSetUsed=true;
        }
    }

    private static boolean placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowWearableSet) {
        return placeProfileLootContainer(level,pos,r,target,allowWearableSet,LootProfile.GENERAL,0.38f,false);
    }

    private static boolean placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowWearableSet,
                                               boolean vehicleBonus) {
        return placeProfileLootContainer(level,pos,r,target,allowWearableSet,
                vehicleBonus?LootProfile.GARAGE:LootProfile.GENERAL,0.38f,false);
    }

    private static boolean placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowWearableSet,
                                               boolean vehicleBonus,boolean scrapyardBonus) {
        LootProfile profile = scrapyardBonus ? LootProfile.SCRAPYARD
                : vehicleBonus ? LootProfile.GARAGE : LootProfile.GENERAL;
        return placeProfileLootContainer(level,pos,r,target,allowWearableSet,profile,0.38f,false);
    }

    private static boolean placeProfileLootContainer(ServerLevel level,BlockPos desired,RandomSource r,int target,
                                                      boolean allowWearableSet,LootProfile profile,float barrelChance,
                                                      boolean guaranteeTechnology) {
        ContainerPlacement placement = findContainerPlacement(level, desired, r, barrelChance);
        if (placement == null) return false;

        level.setBlock(placement.pos(), placement.barrel() ? Blocks.BARREL.defaultBlockState()
                : Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity be=level.getBlockEntity(placement.pos());
        if(be instanceof Container container) {
            LootScanner.LootResult loot=LootScanner.generateProfileContainerLootResult(new Random(r.nextLong()),target,
                    allowWearableSet,profile);
            List<ItemStack> items=new ArrayList<>(loot.items());
            ItemStack guaranteed=guaranteeTechnology?LootScanner.randomTechnologyItem(new Random(r.nextLong())):ItemStack.EMPTY;
            if(!guaranteed.isEmpty()) items.add(guaranteed.copy());
            fillRandomSlots(container,items,r);
            if(!guaranteed.isEmpty()) container.setItem(container.getContainerSize()-1,guaranteed);
            be.getPersistentData().putString("GarageAuctionLootProfile",profile.name());
            return loot.includesWearableSet();
        }
        return false;
    }

    /**
     * Find a container position without trapping a chest.
     * A container is never placed above a chest. A chest may sit above a barrel; if a barrel is
     * requested directly above another barrel, that is also safe. Chests are placed only where
     * their lid has clear space above.
     */
    private static ContainerPlacement findContainerPlacement(ServerLevel level, BlockPos desired,
                                                               RandomSource random, float barrelChance) {
        int[][] offsets = {
                {0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1},
                {1, 1}, {1, -1}, {-1, 1}, {-1, -1},
                {2, 0}, {-2, 0}, {0, 2}, {0, -2},
                {2, 1}, {-2, 1}, {2, -1}, {-2, -1},
                {1, 2}, {-1, 2}, {1, -2}, {-1, -2}
        };

        for (int rise = 0; rise <= 5; rise++) {
            for (int[] offset : offsets) {
                BlockPos candidate = desired.offset(offset[0], rise, offset[1]);
                if (candidate.getY() <= level.getMinBuildHeight()
                        || candidate.getY() >= level.getMaxBuildHeight() - 1
                        || !level.getBlockState(candidate).isAir()) continue;

                BlockEntity below = level.getBlockEntity(candidate.below());
                if (below instanceof ChestBlockEntity) continue; // Never place anything above a chest.

                BlockEntity above = level.getBlockEntity(candidate.above());
                boolean barrel = random.nextFloat() < barrelChance;

                // A chest stacked on a barrel is the preferred safe arrangement.
                if (below instanceof BarrelBlockEntity && barrelChance < 0.99f) barrel = false;

                // A chest cannot open if another container or a solid roof is directly above it.
                if (!barrel) {
                    BlockState aboveState = level.getBlockState(candidate.above());
                    if (above instanceof Container || (!aboveState.isAir() && !aboveState.canBeReplaced())) {
                        if (above instanceof ChestBlockEntity || above instanceof BarrelBlockEntity) {
                            barrel = true; // A barrel below the upper container remains accessible.
                        } else {
                            continue;
                        }
                    }
                }

                return new ContainerPlacement(candidate, barrel);
            }
        }
        return null;
    }

    private record ContainerPlacement(BlockPos pos, boolean barrel) {}

    private static boolean placeLuxuryLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowWearableSet) {
        return placeProfileLootContainer(level,pos,r,target,allowWearableSet,LootProfile.LUXURY,0.45f,false);
    }

    private static void fillRandomSlots(Container container,List<ItemStack> loot,RandomSource r) {
        container.clearContent();
        int size=container.getContainerSize();
        List<ItemStack> items=new ArrayList<>();
        for(ItemStack stack:loot) if(stack!=null&&!stack.isEmpty()) items.add(stack.copy());
        // Always at least one item, even if a registry scan unexpectedly returned nothing.
        if(items.isEmpty()) items.add(new ItemStack(Items.IRON_INGOT,2+r.nextInt(5)));
        Collections.shuffle(items,new Random(r.nextLong()));
        List<Integer> slots=new ArrayList<>(); for(int i=0;i<size;i++) slots.add(i);
        Collections.shuffle(slots,new Random(r.nextLong()));
        int n=Math.min(size,items.size());
        for(int i=0;i<n;i++) container.setItem(slots.get(i),items.get(i));
        container.setChanged();
    }

    /** Refreshes chest/barrel loot. New city containers retain their own district-specific profile. */
    public static int refreshLoot(ServerLevel level,BlockPos center,int radius,String lootMode) {
        int changed=0;
        boolean tall="city".equals(lootMode)||"apartments".equals(lootMode);
        int minY=tall?level.getMinBuildHeight():Math.max(level.getMinBuildHeight(),center.getY()-8);
        int maxY=tall?level.getMaxBuildHeight()-1:Math.min(level.getMaxBuildHeight()-1,center.getY()+24);
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        int minChunkX=(center.getX()-radius)>>4,maxChunkX=(center.getX()+radius)>>4;
        int minChunkZ=(center.getZ()-radius)>>4,maxChunkZ=(center.getZ()+radius)>>4;
        for(int cx=minChunkX;cx<=maxChunkX;cx++) for(int cz=minChunkZ;cz<=maxChunkZ;cz++) {
            LevelChunk chunk=level.getChunk(cx,cz);
            for(BlockEntity be:chunk.getBlockEntities().values()) {
                BlockPos pos=be.getBlockPos();
                int dx=pos.getX()-center.getX(),dz=pos.getZ()-center.getZ();
                if(pos.getY()<minY||pos.getY()>maxY||Math.abs(dx)>radius||Math.abs(dz)>radius) continue;
                if(("luxury".equals(lootMode)||"matrix".equals(lootMode)||"castles".equals(lootMode)
                        ||"apartments".equals(lootMode)||"city".equals(lootMode)) && dx*dx+dz*dz>radius*radius) continue;
                if(!(be instanceof ChestBlockEntity) && !(be instanceof BarrelBlockEntity)) continue;
                if(!(be instanceof Container container)) continue;

                LootProfile profile=null;
                String stored=be.getPersistentData().getString("GarageAuctionLootProfile");
                if(!stored.isBlank()) {
                    try { profile=LootProfile.valueOf(stored); } catch(IllegalArgumentException ignored) { profile=null; }
                }
                if(profile==null) profile=switch(lootMode) {
                    case "vehicle" -> LootProfile.GARAGE;
                    case "scrapyard" -> LootProfile.SCRAPYARD;
                    case "luxury" -> LootProfile.LUXURY;
                    case "matrix" -> LootProfile.MATRIX;
                    case "castles" -> LootProfile.CASTLE;
                    case "park" -> LootProfile.PARK;
                    case "apartments" -> LootProfile.APARTMENTS;
                    case "city" -> LootProfile.CITY_CORPORATE;
                    default -> LootProfile.GENERAL;
                };
                int target=switch(profile) {
                    case SCRAPYARD -> 5+r.nextInt(3);
                    case CITY_CORPORATE, CITY_HIGHRISE -> 12+r.nextInt(7);
                    case LUXURY, CITY_LUXURY, APARTMENTS -> 10+r.nextInt(6);
                    default -> 12+r.nextInt(9);
                };
                LootScanner.LootResult loot=profile==LootProfile.MATRIX
                        ? LootScanner.generateMatrixContainerLootResult(new Random(r.nextLong()),target,true)
                        : LootScanner.generateProfileContainerLootResult(new Random(r.nextLong()),target,true,profile);
                fillRandomSlots(container,loot.items(),r);
                be.getPersistentData().putString("GarageAuctionLootProfile",profile.name());
                changed++;
            }
        }
        return changed;
    }

    /** Teleports a player to a floor of the 58-storey landmark, but only from inside its lobby/footprint. */
    public static boolean useCityLift(ServerLevel level,ServerPlayer player,int floor) {
        if(floor<1||floor>58) return false;
        StructureRegistryData.LocationRecord nearest=null;
        double best=Double.MAX_VALUE;
        for(StructureRegistryData.LocationRecord record:StructureRegistryData.get(level).getLocations()) {
            if(!"city".equals(record.type())) continue;
            Direction forward=Direction.fromYRot(record.yaw()).getOpposite();
            BlockPos center=new BlockPos(record.x(),record.y(),record.z()).relative(forward,record.offset());
            double dx=player.getX()-center.getX(),dz=player.getZ()-center.getZ();
            double distance=dx*dx+dz*dz;
            if(distance<best) {best=distance;nearest=record;}
        }
        if(nearest==null||best>38.0*38.0) return false;
        Direction forward=Direction.fromYRot(nearest.yaw()).getOpposite();
        BlockPos center=new BlockPos(nearest.x(),nearest.y(),nearest.z()).relative(forward,nearest.offset());
        double x=center.getX()+2.5;
        double z=center.getZ()+0.5;
        double y=nearest.y()+1+(floor-1)*3;
        if(y>=level.getMaxBuildHeight()-2) return false;
        player.teleportTo(level,x,y,z,Set.of(),player.getYRot(),player.getXRot());
        return true;
    }

    /** Legacy compatibility: clears only a bounded cube, retained for internal tooling. */
    public static int clear(ServerLevel level,BlockPos center,int radius) {
        int removed=0; BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        int minY=Math.max(level.getMinBuildHeight(),center.getY()-8),maxY=Math.min(level.getMaxBuildHeight()-1,center.getY()+24);
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) for(int y=minY;y<=maxY;y++) {
            p.set(center.getX()+x,y,z);
            if(!level.getBlockState(p).isAir()) {level.removeBlock(p,false);removed++;}
        }
        return removed;
    }
}
