# 0.6.1 integration notes

## Runtime compatibility
- Minecraft 1.20.1 / Forge 47.4.28 / Java 17.
- Addons remain optional at compile time. Garage Auction uses the live item registry and exact resource IDs, so it does not add hard dependencies on FSang18, Throg's Addon or Potato Heroes.

## Armor classification
- `fsang` and `throgaddon` Palladium armor pieces are recognized as hero armor before clothing/ordinary armor classification.
- `potato` one-piece Palladium suits are recognized by the exact item IDs read from Potato v2's `addon/potato/items` definitions.
- Two-, three- and four-slot suits are grouped by namespace and normalized slot suffix when the addon defines those pieces. FSang18 chest-only suit entries are treated as one-piece suits; head-only accessories are not promoted to full suits. Other modded hero armor must form at least a two-piece group or an explicit one-piece chest suit.
- FSang18 chest-only suit-set entries (including the Hulkbuster chest suits) are handled explicitly. All valid suit groups remain eligible for loot; no suit is silently removed just because the addon does not define a matching syringe.
- Other `ArmorItem` entries whose registry paths contain a known superhero/character name are kept out of the clothing pool and grouped separately when their slots match.
- A container can receive one hero armor set at most. Hero armor pieces are excluded from the ordinary random armor pool; clothing sets use a separate probability roll. The Matrix keeps its 14% combined wearable-set roll and its high-value profile.

## FSang18's Heroes v12.5.7 (verified from uploaded JAR)
- Mark 50 set -> `fsang:iron_man_core_mark_50`.
- Model 50 set -> `fsang:iron_man_nano_50`.
- Model 37 set -> `fsang:iron_man_nano_37`.
- Other Iron Man model suits use `fsang:iron_man_arc_reactor_1` through `_4`; tier selection follows the suit family/model where known.
- Invincible -> `fsang:syringe_filled` with NBT `fsang_stored_power=fsang:viltrumite_human` and `CustomModelData=11`.
- Omni-Man and Viltrumite variants -> `fsang:syringe_filled` with `fsang_stored_power=fsang:viltrumite` and `CustomModelData=11`.
- Spider-Man variants, speedsters, Kryptonian suits, Invincible/Omni-Man, Wolverine, Cyclops, Magneto, Thor, Aquaman, Homelander, Soldier Boy, Translucent, Hulk, Wonder Woman, Shazam, Sentry, Storm, X-Men and several other recognizable suits use power IDs/CustomModelData present in the addon's injectable-power data. Batman, Falcon, Captain America, Blue Beetle, Ghost Rider and other suits receive original same-mod gear where a matching item-power mapping exists. Costumes with no defined syringe are not assigned invented NBT powers.
- The generated syringe uses the real `fsang:syringe_filled` item and the same `fsang_stored_power` / `CustomModelData` keys used by the addon's KubeJS recipes and item tooltip script. No item attributes or suit NBT are fabricated.

## Throg's Addon 1.5.7 (verified from uploaded JAR)
- Spider-Man costume sets -> `throgaddon:spiderman_dna_syringe`.
- Insomniac Spider-Man -> `throgaddon:iron_spider_backpack`.
- Miles costume sets -> `throgaddon:spidermanmiles_dna_syringe`.
- Wolverine sets -> `bone_claws_dna_syringe`, `regenaration_dna_syringe`, `adamantium_syringe`.
- Cyclops -> `cyclops_dna_syringe`.
- Magneto -> `magnetism_dna_syringe`.
- Deadpool -> `regenaration_dna_syringe`.
- These are the real item IDs used by the addon's KubeJS right-click handlers; the generic empty syringe is not added as a serum.

## Potato Heroes v2 (verified from uploaded JAR)
- 38 actual Palladium armor items are registered as one-piece hero suits (excluding the addon's test suit and non-Palladium wings item).
- Examples include Batman, Superman variants, Flash variants, Aquaman, Wonder Woman, Invincible, Omni-Man, Thragg, Vision, Ikaris, Atom, Hawkgirl, Shazam and Nova.
- Their item-power mappings grant abilities directly from the suit item. No serum is invented for suits where the addon does not define one.
- `potato:lantern_ring` and `potato:x_k_vial` remain independently discoverable special/serum items.

## Loot profile rules
- Hero armor is not clothing and cannot be selected as a random loose armor piece.
- At most one hero suit bundle is added to one chest/barrel; the selected bundle contains only one character's items.
- Hero suit chance is intentionally low in ordinary locations and higher in castles, high-rises and corporate buildings. Garages and chemical facilities do not roll hero armor.
- Original registered `Item` objects are used. The only custom NBT written is the FSang filled syringe data matching the addon's own recipe format.
- Existing `arrzenhanced` same-namespace Flash/Lantern component matching is retained for other installed mods.

## Terrain and containers
- Footprint placement no longer cuts high columns down to a median. It validates the entire ground surface, refuses occupied/uneven sites, selects the highest natural surface, and adds only a shallow dirt foundation below it.
- Void worlds use the command user's Y coordinate for a generated platform.
- Old dropped item entities and mod-generated villagers are removed within the registered footprint before regeneration.
- A chest is never placed above another chest. Chests require clear space above; a chest may sit on a barrel. Barrels can be stacked. The placement routine searches nearby free positions rather than forcing an inaccessible container into a stack.
- `/restorestructures` clears old generated inventories/block entities and dropped items within each registered footprint, then rebuilds from the saved seed. The base floor/foundation remains.
