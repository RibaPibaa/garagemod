package com.geko.garageauction;

import com.geko.garageauction.command.GarageCommands;
import com.geko.garageauction.game.GarageGameManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(GarageAuctionMod.MODID)
public class GarageAuctionMod {
    public static final String MODID = "garageauction";

    public GarageAuctionMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(GarageGameManager.class);
    }

    private void registerCommands(RegisterCommandsEvent event) {
        GarageCommands.register(event.getDispatcher());
    }
}
