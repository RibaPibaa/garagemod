package com.geko.garageauction.command;

import com.geko.garageauction.game.GarageGameManager;
import com.geko.garageauction.loot.LootScanner;
import com.geko.garageauction.structure.MarketplaceBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class GarageCommands {
    private GarageCommands() {}
    public static void register(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> d) {
        d.register(Commands.literal("garages").requires(s -> s.hasPermission(2))
            .then(Commands.argument("size", StringArgumentType.word()).suggests((c,b)->{b.suggest("small");b.suggest("medium");b.suggest("large");return b.buildFuture();})
            .executes(ctx -> { String size=StringArgumentType.getString(ctx,"size").toLowerCase(); if(!size.matches("small|medium|large")){ctx.getSource().sendFailure(Component.literal("Use: /garages small|medium|large"));return 0;} if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0; MarketplaceBuilder.generate(p.serverLevel(),p.blockPosition(),p.getYRot(),size); ctx.getSource().sendSuccess(()->Component.literal("Marketplace generated: "+size),true); return 1; })));
        d.register(Commands.literal("clearstructure").requires(s->s.hasPermission(2)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;int n=MarketplaceBuilder.clear(p.serverLevel(),p.blockPosition(),100);ctx.getSource().sendSuccess(()->Component.literal("Removed "+n+" generated blocks."),true);return 1;}));
        d.register(Commands.literal("cleargarages").requires(s->s.hasPermission(2)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;int n=MarketplaceBuilder.clear(p.serverLevel(),p.blockPosition(),70);GarageGameManager.resetAuctions();ctx.getSource().sendSuccess(()->Component.literal("Cleared "+n+" generated blocks."),true);return 1;}));
        d.register(Commands.literal("garageloot").requires(s->s.hasPermission(2)).executes(ctx->{LootScanner.ScanSummary x=LootScanner.scan();ctx.getSource().sendSuccess(()->Component.literal("Found "+x.total()+" items in "+x.byMod().size()+" mod namespaces."),false);return 1;}));
        d.register(Commands.literal("garagejoin").then(Commands.argument("id",IntegerArgumentType.integer(0)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.joinAuction(p,IntegerArgumentType.getInteger(ctx,"id"));return 1;})));
        d.register(Commands.literal("rate100").then(Commands.argument("amount",IntegerArgumentType.integer(1)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;return GarageGameManager.bid(p,IntegerArgumentType.getInteger(ctx,"amount"))?1:0;})));
        d.register(Commands.literal("arenajoin").then(Commands.argument("id",IntegerArgumentType.integer(0,2)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.joinArena(p,IntegerArgumentType.getInteger(ctx,"id"));return 1;})));
        d.register(Commands.literal("garagebalance").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;int money=GarageGameManager.balance(p);p.sendSystemMessage(Component.literal("Balance: $"+money));return 1;}));
        d.register(Commands.literal("mystorage").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.openStorage(p);return 1;}));
        d.register(Commands.literal("mystorageleave").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.leaveStorage(p);return 1;}));
    }
}
