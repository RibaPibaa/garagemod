package com.geko.garageauction.command;

import com.geko.garageauction.game.GarageGameManager;
import com.geko.garageauction.loot.LootScanner;
import com.geko.garageauction.structure.MarketplaceBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class GarageCommands {
    private GarageCommands() {}
    public static void register(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> d) {
        d.register(Commands.literal("garagesspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            MarketplaceBuilder.generate(p.serverLevel(), p.blockPosition(), p.getYRot(), "medium");
            ctx.getSource().sendSuccess(() -> Component.literal("Abandoned scrapyard generated. Garages: 12."), true);
            return 1;
        }));
        d.register(Commands.literal("clearstructure").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            int n=MarketplaceBuilder.clear(p.serverLevel(),p.blockPosition(),52);
            ctx.getSource().sendSuccess(() -> Component.literal("Removed " + n + " blocks."),true); return 1;
        }));
        d.register(Commands.literal("cleargarages").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            int n=MarketplaceBuilder.clear(p.serverLevel(),p.blockPosition(),52);
            GarageGameManager.resetAuctions();
            ctx.getSource().sendSuccess(() -> Component.literal("Cleared scrapyard area: " + n + " blocks."),true); return 1;
        }));
        d.register(Commands.literal("garageloot").requires(s->s.hasPermission(2)).executes(ctx->{
            LootScanner.ScanSummary x=LootScanner.scan();
            ctx.getSource().sendSuccess(()->Component.literal("Found "+x.total()+" eligible items across "+x.byMod().size()+" mod namespaces."),false); return 1;
        }));
        d.register(Commands.literal("garagejoin").then(Commands.argument("id",IntegerArgumentType.integer(0)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.joinAuction(p,IntegerArgumentType.getInteger(ctx,"id"));return 1;})));
        d.register(Commands.literal("rate100").then(Commands.argument("amount",IntegerArgumentType.integer(1)).executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;return GarageGameManager.bid(p,IntegerArgumentType.getInteger(ctx,"amount"))?1:0;})));
        d.register(Commands.literal("garagebalance").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;p.sendSystemMessage(Component.literal("Balance: $"+GarageGameManager.balance(p)));return 1;}));
        d.register(Commands.literal("mystorage").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.openStorage(p);return 1;}));
        d.register(Commands.literal("mystorageleave").executes(ctx->{if(!(ctx.getSource().getEntity() instanceof ServerPlayer p))return 0;GarageGameManager.leaveStorage(p);return 1;}));
    }

}
