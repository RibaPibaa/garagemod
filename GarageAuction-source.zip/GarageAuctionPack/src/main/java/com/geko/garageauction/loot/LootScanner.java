package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.util.*;

/** Runtime item discovery. It reads the final Forge item registry, after every mod has registered. */
public final class LootScanner {
    private LootScanner() {}
    public record ScanSummary(int total, Map<String,Integer> byMod) {}
    private enum Kind { ARMOR, WEAPON, TOOL, FOOD, BLOCK, OTHER }
    private static final Map<String,List<Item>> MOD_ITEMS = new TreeMap<>();
    private static final Map<String,List<Item>> ARMOR_SETS = new TreeMap<>();
    private static List<Item> ALL = List.of();
    private static boolean scanned;

    public static synchronized ScanSummary scan() {
        MOD_ITEMS.clear(); ARMOR_SETS.clear(); List<Item> all=new ArrayList<>();
        for(Item item:BuiltInRegistries.ITEM) if(isCandidate(item)) {
            ResourceLocation id=BuiltInRegistries.ITEM.getKey(item); all.add(item);
            MOD_ITEMS.computeIfAbsent(id.getNamespace(),k->new ArrayList<>()).add(item);
            if(item instanceof ArmorItem armor) {
                String setKey=id.getNamespace()+":"+normalizeArmorName(id.getPath());
                ARMOR_SETS.computeIfAbsent(setKey,k->new ArrayList<>()).add(item);
            }
        }
        ALL=List.copyOf(all); scanned=true;
        Map<String,Integer> counts=new TreeMap<>(); MOD_ITEMS.forEach((k,v)->counts.put(k,v.size()));
        return new ScanSummary(ALL.size(),Collections.unmodifiableMap(counts));
    }
    public static List<Item> candidates() { if(!scanned) scan(); return ALL; }
    public static boolean isCandidate(Item item) {
        ResourceLocation id=BuiltInRegistries.ITEM.getKey(item);
        if(id==null||item==Items.AIR) return false;
        String p=id.getPath().toLowerCase(Locale.ROOT);
        if(p.contains("spawn_egg")||p.contains("debug")||p.contains("test_item")||p.contains("_spawn")) return false;
        return !Set.of("air","barrier","command_block","chain_command_block","repeating_command_block","structure_block","jigsaw","light","structure_void","knowledge_book").contains(p);
    }
    private static String normalizeArmorName(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        for(String suffix:List.of("_helmet","_head","_mask","_chestplate","_chest","_leggings","_legs","_boots","_feet"))
            if(p.endsWith(suffix)) return p.substring(0,p.length()-suffix.length());
        return p;
    }
    private static Kind kind(Item i) {
        if(i instanceof ArmorItem) return Kind.ARMOR;
        if(i instanceof SwordItem || i instanceof BowItem || i instanceof CrossbowItem || i instanceof TridentItem) return Kind.WEAPON;
        if(i instanceof TieredItem || i instanceof ShearsItem || i instanceof FishingRodItem) return Kind.TOOL;
        if(i.getFoodProperties(i.getDefaultInstance(),null)!=null) return Kind.FOOD;
        if(i instanceof BlockItem) return Kind.BLOCK;
        return Kind.OTHER;
    }
    /** Generates a garage-wide loot batch. Armor sets are inserted as a complete set, never mixed piece-by-piece. */
    public static List<ItemStack> generateGarageLoot(Random random,int targetStacks) {
        if(!scanned) scan(); List<ItemStack> out=new ArrayList<>(); if(ALL.isEmpty()) return out;
        List<String> namespaces=new ArrayList<>(MOD_ITEMS.keySet());
        for(int n=0;n<targetStacks;n++) {
            String mod=namespaces.get(random.nextInt(namespaces.size()));
            List<Item> pool=MOD_ITEMS.get(mod); List<Item> filtered=new ArrayList<>();
            Kind wanted=switch(random.nextInt(6)){case 0->Kind.ARMOR;case 1->Kind.WEAPON;case 2->Kind.TOOL;case 3->Kind.FOOD;case 4->Kind.BLOCK;default->Kind.OTHER;};
            for(Item i:pool) if(kind(i)==wanted) filtered.add(i);
            if(filtered.isEmpty()) for(Item i:pool) if(kind(i)!=Kind.BLOCK) filtered.add(i);
            if(filtered.isEmpty()) filtered.addAll(pool);
            Item chosen=filtered.get(random.nextInt(filtered.size()));
            if(chosen instanceof ArmorItem armor && random.nextFloat()<0.75f) {
                ResourceLocation id=BuiltInRegistries.ITEM.getKey(chosen);
                List<Item> set=ARMOR_SETS.get(id.getNamespace()+":"+normalizeArmorName(id.getPath()));
                if(set!=null) {
                    EnumSet<EquipmentSlot> added=EnumSet.noneOf(EquipmentSlot.class);
                    for(Item piece:set) if(piece instanceof ArmorItem a && added.add(a.getEquipmentSlot())) out.add(new ItemStack(piece));
                    if(!added.contains(EquipmentSlot.HEAD)||!added.contains(EquipmentSlot.CHEST)||!added.contains(EquipmentSlot.LEGS)||!added.contains(EquipmentSlot.FEET)) out.add(new ItemStack(chosen));
                    n+=Math.max(0,added.size()-1); continue;
                }
            }
            int max=chosen.getDefaultInstance().getMaxStackSize(); int count=max>1&&random.nextFloat()<0.3f?1+random.nextInt(Math.min(8,max)):1;
            out.add(new ItemStack(chosen,count));
        }
        return out;
    }
    public static ItemStack randomStack(Random random) {
        List<ItemStack> stacks=generateGarageLoot(random,1); return stacks.isEmpty()?ItemStack.EMPTY:stacks.get(0);
    }
}
