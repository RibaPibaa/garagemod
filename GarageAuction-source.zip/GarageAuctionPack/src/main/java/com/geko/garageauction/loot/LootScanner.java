package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.util.*;

/** Discovers items from the live registry. Every eligible registered item has equal selection probability. */
public final class LootScanner {
    private LootScanner() {}
    public record ScanSummary(int total, Map<String,Integer> byMod) {}
    private static final List<Item> ALL = new ArrayList<>();
    private static final Map<String,List<Item>> ARMOR_SETS = new HashMap<>();
    private static boolean scanned;

    public static synchronized ScanSummary scan() {
        ALL.clear(); ARMOR_SETS.clear(); Map<String,Integer> counts=new TreeMap<>();
        for(Item item:BuiltInRegistries.ITEM) {
            ResourceLocation id=BuiltInRegistries.ITEM.getKey(item);
            if(!isCandidate(item,id)) continue;
            ALL.add(item); counts.merge(id.getNamespace(),1,Integer::sum);
            if(item instanceof ArmorItem) ARMOR_SETS.computeIfAbsent(id.getNamespace()+":"+normalizeArmorName(id.getPath()),k->new ArrayList<>()).add(item);
        }
        scanned=true;
        return new ScanSummary(ALL.size(),Collections.unmodifiableMap(counts));
    }

    private static boolean isCandidate(Item item, ResourceLocation id) {
        if(id==null||item==Items.AIR) return false;
        String p=id.getPath().toLowerCase(Locale.ROOT);
        if(p.contains("spawn_egg")||p.contains("debug")||p.contains("test_item")||p.contains("_spawn")) return false;
        return !Set.of("air","barrier","command_block","chain_command_block","repeating_command_block","structure_block","jigsaw","light","structure_void","knowledge_book").contains(p);
    }

    private static String normalizeArmorName(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        for(String suffix:List.of("_helmet","_head","_mask","_chestplate","_chest","_leggings","_legs","_boots","_feet"))
            if(p.endsWith(suffix)) return p.substring(0,p.length()-suffix.length());
        return p;
    }

    public static synchronized List<ItemStack> generateGarageLoot(Random random,int targetStacks) {
        if(!scanned) scan();
        List<ItemStack> result=new ArrayList<>();
        if(ALL.isEmpty()) return result;
        boolean armorSetAlreadyAdded=false;
        for(int i=0;i<targetStacks;i++) {
            // Uniform draw from all eligible items across all installed mods, not namespace-weighted.
            Item chosen=ALL.get(random.nextInt(ALL.size()));
            if(chosen instanceof ArmorItem armor && !armorSetAlreadyAdded && random.nextFloat()<0.18f) {
                ResourceLocation id=BuiltInRegistries.ITEM.getKey(chosen);
                List<Item> set=ARMOR_SETS.get(id.getNamespace()+":"+normalizeArmorName(id.getPath()));
                if(set!=null && set.size()>=2) {
                    EnumMap<EquipmentSlot,Item> pieces=new EnumMap<>(EquipmentSlot.class);
                    for(Item piece:set) if(piece instanceof ArmorItem a) pieces.put(a.getEquipmentSlot(),piece);
                    // Only consider a real multi-piece set; do not combine unrelated pieces.
                    if(pieces.size()>=2) {
                        for(Item piece:pieces.values()) result.add(new ItemStack(piece));
                        armorSetAlreadyAdded=true;
                        continue;
                    }
                }
            }
            ItemStack stack=new ItemStack(chosen);
            int max=stack.getMaxStackSize();
            if(max>1 && random.nextFloat()<.25f) stack.setCount(1+random.nextInt(Math.min(max,4)));
            result.add(stack);
        }
        return result;
    }

    public static ItemStack randomStack(Random random) {
        List<ItemStack> stacks=generateGarageLoot(random,1);
        return stacks.isEmpty()?ItemStack.EMPTY:stacks.get(0);
    }
}
