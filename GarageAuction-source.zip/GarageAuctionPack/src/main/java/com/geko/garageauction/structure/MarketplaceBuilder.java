package com.geko.garageauction.structure;

import com.geko.garageauction.loot.LootScanner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.item.ItemStack;

import java.util.*;

public final class MarketplaceBuilder {
    private MarketplaceBuilder() {}

    public static void generate(ServerLevel level, BlockPos origin, float yaw, String size) {
        int garages = switch (size) { case "small" -> 4; case "large" -> 16; default -> 9; };
        int width = size.equals("small") ? 2 : size.equals("large") ? 4 : 3;
        int spacing = 13;
        clear(level, origin, size.equals("large") ? 100 : 70);
        buildGround(level, origin, 70);
        buildEntrance(level, origin);
        int index = 0;
        for (int row = 0; row < (garages + width - 1) / width; row++) {
            for (int col = 0; col < width && index < garages; col++) {
                BlockPos p = origin.offset((col - (width - 1) / 2) * spacing, 0, 12 + row * 15);
                buildGarage(level, p, index++, RandomSource.create(level.getRandom().nextLong()));
            }
        }
        buildArena(level, origin.offset(0, 0, -34), 14, Blocks.STONE_BRICKS);
        buildArena(level, origin.offset(-34, 0, 4), 12, Blocks.DEEPSLATE_BRICKS);
        buildArena(level, origin.offset(34, 0, 4), 12, Blocks.SANDSTONE);
    }

    private static void buildGround(ServerLevel level, BlockPos o, int radius) {
        for (int x=-radius; x<=radius; x++) for (int z=-radius; z<=radius; z++) {
            if (x*x + z*z <= radius*radius) {
                BlockPos p=o.offset(x,-1,z);
                level.setBlock(p, (Math.abs(x)%7==0 || Math.abs(z)%7==0) ? Blocks.POLISHED_ANDESITE.defaultBlockState() : Blocks.COARSE_DIRT.defaultBlockState(), 3);
            }
        }
    }

    private static void buildEntrance(ServerLevel level, BlockPos o) {
        for (int y=0;y<10;y++) for (int x=-7;x<=7;x++) {
            boolean pillar = Math.abs(x)>=5 && y<=7;
            boolean arch = y>=6 && Math.abs(x)<=5 && (y + Math.abs(x) >= 10);
            if (pillar || arch) level.setBlock(o.offset(x,y,0), Blocks.QUARTZ_BRICKS.defaultBlockState(), 3);
        }
        for (int x=-4;x<=4;x++) level.setBlock(o.offset(x,0,1), Blocks.SMOOTH_QUARTZ.defaultBlockState(),3);
        level.setBlock(o.offset(0,4,0), Blocks.GLOWSTONE.defaultBlockState(),3);
    }

    private static void buildGarage(ServerLevel level, BlockPos p, int index, RandomSource random) {
        int w=9, d=9, h=5;
        BlockState wall = random.nextInt(4)==0 ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState()
            : random.nextBoolean() ? Blocks.BRICKS.defaultBlockState() : Blocks.COBBLESTONE.defaultBlockState();
        BlockState roof = random.nextBoolean() ? Blocks.DEEPSLATE_TILES.defaultBlockState() : Blocks.OAK_PLANKS.defaultBlockState();
        for (int x=0;x<w;x++) for (int z=0;z<d;z++) {
            level.setBlock(p.offset(x,0,z), Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            level.setBlock(p.offset(x,h,z), roof,3);
            for(int y=1;y<h;y++) {
                boolean edge=x==0||x==w-1||z==0||z==d-1;
                if(edge) level.setBlock(p.offset(x,y,z), wall,3);
            }
        }
        // Front opening and roll-up door.
        for(int y=1;y<=3;y++) for(int x=2;x<=6;x++) {
            level.setBlock(p.offset(x,y,0), Blocks.IRON_BARS.defaultBlockState(),3);
        }
        level.setBlock(p.offset(4,4,0), Blocks.LANTERN.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,2), Blocks.COBWEB.defaultBlockState(),3);
        if(random.nextBoolean()) level.setBlock(p.offset(7,1,7), Blocks.MOSS_CARPET.defaultBlockState(),3);
        if(random.nextBoolean()) level.setBlock(p.offset(2,1,6), Blocks.BARREL.defaultBlockState(),3);
        List<ItemStack> garageLoot = LootScanner.generateGarageLoot(new Random(random.nextLong()), 18 + random.nextInt(15));
        placeChest(level, p.offset(2,1,3), random, garageLoot, 0);
        placeChest(level, p.offset(6,1,3), random, garageLoot, 1);
        level.setBlock(p.offset(4,1,8), Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,7), Blocks.FLOWER_POT.defaultBlockState(),3);
        level.setBlock(p.offset(7,1,2), Blocks.BROWN_MUSHROOM.defaultBlockState(),3);
        level.setBlock(p.offset(4,1,4), Blocks.OAK_SIGN.defaultBlockState(),3);
    }

    private static void placeChest(ServerLevel level, BlockPos pos, RandomSource random, List<ItemStack> loot, int half) {
        level.setBlock(pos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH), 3);
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ChestBlockEntity chest) {
            int from = half * ((loot.size()+1)/2);
            int to = Math.min(loot.size(), from + (loot.size()+1)/2);
            int slot = 0;
            for (int i=from; i<to && slot<27; i++) chest.setItem(slot++, loot.get(i).copy());
            chest.setChanged();
        }
    }

    private static void buildArena(ServerLevel level, BlockPos c, int radius, Block floor) {
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            double dist=Math.sqrt(x*x+z*z);
            if(dist<=radius) {
                level.setBlock(c.offset(x,-1,z), floor.defaultBlockState(),3);
                if(dist>radius-1.4) {
                    for(int y=0;y<3;y++) level.setBlock(c.offset(x,y,z), Blocks.IRON_BARS.defaultBlockState(),3);
                }
            }
        }
        for(int i=0;i<4;i++) {
            double a=Math.PI/2*i;
            int x=(int)(Math.cos(a)*(radius-3)), z=(int)(Math.sin(a)*(radius-3));
            level.setBlock(c.offset(x,0,z), Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        level.setBlock(c, Blocks.GOLD_BLOCK.defaultBlockState(),3);
    }

    public static int clear(ServerLevel level, BlockPos center, int radius) {
        int removed=0;
        BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        int minY=Math.max(level.getMinBuildHeight(), center.getY()-8);
        int maxY=Math.min(level.getMaxBuildHeight()-1, center.getY()+18);
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            for(int y=minY;y<=maxY;y++) {
                p.set(center.getX()+x,y,center.getZ()+z);
                BlockState state=level.getBlockState(p);
                if(!state.isAir()) {
                    // Deliberately only remove the custom palette used by this generator.
                    if(isGeneratedBlock(state.getBlock())) {
                        level.removeBlock(p, false);
                        removed++;
                    }
                }
            }
        }
        return removed;
    }

    private static boolean isGeneratedBlock(Block b) {
        return b==Blocks.POLISHED_ANDESITE || b==Blocks.COARSE_DIRT || b==Blocks.QUARTZ_BRICKS ||
            b==Blocks.SMOOTH_QUARTZ || b==Blocks.GLOWSTONE || b==Blocks.GRAY_CONCRETE ||
            b==Blocks.MOSSY_STONE_BRICKS || b==Blocks.BRICKS || b==Blocks.COBBLESTONE ||
            b==Blocks.DEEPSLATE_TILES || b==Blocks.OAK_PLANKS || b==Blocks.IRON_BARS ||
            b==Blocks.LANTERN || b==Blocks.COBWEB || b==Blocks.MOSS_CARPET ||
            b==Blocks.BARREL || b==Blocks.CHEST || b==Blocks.CRAFTING_TABLE ||
            b==Blocks.FLOWER_POT || b==Blocks.BROWN_MUSHROOM || b==Blocks.OAK_SIGN ||
            b==Blocks.STONE_BRICKS || b==Blocks.DEEPSLATE_BRICKS || b==Blocks.SANDSTONE ||
            b==Blocks.SEA_LANTERN || b==Blocks.GOLD_BLOCK;
    }
}
