# Garage Auction — Forge 1.20.1

Command: `/garagesspawn` (requires permission level 2).

This revision replaces the arena-themed layout with a procedural abandoned scrapyard: uneven dirt/gravel terrain, perimeter garbage heaps, debris-strewn narrow alleys, 12 varied garages, opaque shutter doors, centered black garage labels, and 3–5 scattered chests/barrels per garage.

Loot is selected uniformly from eligible items in the live item registry across all loaded mods. A garage can roll at most one multi-piece armor set; set completion is heuristic based on item registry names and is not guaranteed for unusual modular armor systems. Complex mods such as TaCZ may require dedicated adapters.

Build with Java 17 and Gradle 8.8 using GitHub Actions.

Note: this source revision has not yet been tested in a live Minecraft client. GitHub Actions compilation is the next verification step.
