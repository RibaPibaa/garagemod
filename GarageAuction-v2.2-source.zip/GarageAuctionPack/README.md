# Garage Auction 0.3.0 — Forge 1.20.1

**Runtime:** Minecraft 1.20.1, Forge 47.4.10, Java 17. Build with Gradle 8.8.

## Commands (operator permission level 2)

- `/squarespawn` — large landscaped circular park, central monument, paths, flower beds, trees and 24 small garages. Each garage receives 4–6 loot containers placed inside the room.
- `/scrapyardspawn` — abandoned scrapyard made of irregular trash heaps instead of garages. Gravel is not used. Search containers are placed outside/alongside heaps and are stocked; scrapyard loot gets a higher share of weapon/equipment/valuable item IDs.
- `/garagesspawn` — enclosed blue-grey garage yard with 12 machine garages, large solid iron-block doors and 4–6 loot containers per garage. Vehicle-related items receive extra weight here.
- `/arenaspawn` — large circular stadium with stepped stands and modest lighting. It does not generate loot containers.
- `/garagebatch square 10` — create 10 park cottages in a row.
- `/garagebatch workshop 10` — create 10 machine garages in a row.
- `/garagebatch scrapyard 10` — create 10 separate trash heaps, each with loot containers, in a row.
- `/reverselootsquare` — reroll chest/barrel contents around the player within the park-sized radius.
- `/reverselootgarages` — reroll chest/barrel contents around the player in the garage-yard radius.
- `/reverselootscrapyard` — reroll chest/barrel contents around the player in the scrapyard radius.

Run the three `reverseloot...` commands while standing near the centre of the corresponding generated location. They refresh every chest/barrel found in that radius, so avoid standing where unrelated storage is nearby.

## Terrain handling

Generation checks the terrain across its intended footprint before changing blocks. It refuses to generate when the height variation is too steep, rather than clearing a huge surrounding area or leaving the build floating. On accepted terrain, the footprint is levelled locally with a dirt foundation. It still replaces blocks **inside the generated footprint**, so test in a copy of the world first and keep other builds outside that footprint.

## Loot behaviour

The scanner reads the live Forge item registry, so items registered by installed mods can be considered without listing every mod manually. Containers are filled with shuffled slots and have a vanilla fallback if the registry scan returns no eligible items. Clothing-like item IDs receive a modest extra chance. Complete four-piece `ArmorItem` sets remain rare (7.5% roll when permitted) and are kept together; the generator stops allowing another set in the same garage once one is detected. Workshop garages give additional weight to item IDs suggesting wheels, tires, engines, vehicle parts and aircraft components. Scrapyard containers favour IDs suggesting weapons, ammunition, equipment and other valuables.

Some mods store weapon variants, ammunition, attachments or abilities in custom NBT/capabilities, or use item names that do not identify their function. Those require mod-specific adapters; registry scanning alone cannot reliably synthesize those variants.

## Build

```bash
gradle build --no-daemon
```

The compiled mod is written to `build/libs/garageauction-0.3.0.jar`.
