package com.geko.garageauction.command;

import com.geko.garageauction.structure.MarketplaceBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class GarageCommands {
    private GarageCommands() {}

    public static void register(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("squarespawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generatePark(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Площадь создана: 24 гаража, дорожки, цветники и центральный монумент."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("scrapyardspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateScrapyard(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Свалка создана: кучи мусора и заполненные контейнеры."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("garagesspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateGarages(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Гаражный район создан: 12 мастерских в сине-серой гамме."),true);
                return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("arenaspawn").requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            try {
                MarketplaceBuilder.generateArena(p.serverLevel(),p.blockPosition(),p.getYRot());
                ctx.getSource().sendSuccess(() -> Component.literal("Круглая арена создана. Лута нет."),true); return 1;
            } catch (IllegalArgumentException ex) {
                ctx.getSource().sendFailure(Component.literal(ex.getMessage())); return 0;
            }
        }));
        dispatcher.register(Commands.literal("garagebatch").requires(s -> s.hasPermission(2))
            .then(Commands.argument("type",StringArgumentType.word())
            .then(Commands.argument("count",IntegerArgumentType.integer(1,50)).executes(ctx -> {
                if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
                String type=StringArgumentType.getString(ctx,"type");
                int count=IntegerArgumentType.getInteger(ctx,"count");
                try {
                    int made=MarketplaceBuilder.spawnBatch(p.serverLevel(),p.blockPosition(),p.getYRot(),type,count);
                    ctx.getSource().sendSuccess(() -> Component.literal("Создано объектов в ряд: "+made+". Тип: "+type),true); return 1;
                } catch (IllegalArgumentException ex) {
                    ctx.getSource().sendFailure(Component.literal(ex.getMessage()+". Пример: /garagebatch square 10")); return 0;
                }
            }))));
        registerRefresh(dispatcher,"reverselootsquare",102,"square","Лут площади обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootgarages",56,"vehicle","Лут гаражного района обновлён в контейнерах: ");
        registerRefresh(dispatcher,"reverselootscrapyard",52,"scrapyard","Лут свалки обновлён в контейнерах: ");
    }

    private static void registerRefresh(com.mojang.brigadier.CommandDispatcher<net.minecraft.commands.CommandSourceStack> dispatcher,String name,int radius,String lootMode,String message) {
        dispatcher.register(Commands.literal(name).requires(s -> s.hasPermission(2)).executes(ctx -> {
            if (!(ctx.getSource().getEntity() instanceof ServerPlayer p)) return 0;
            int count=MarketplaceBuilder.refreshLoot(p.serverLevel(),p.blockPosition(),radius,lootMode);
            final int result=count;
            ctx.getSource().sendSuccess(() -> Component.literal(message+result),true); return 1;
        }));
    }
}
