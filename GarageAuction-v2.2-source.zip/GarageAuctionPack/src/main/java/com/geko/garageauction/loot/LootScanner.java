package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.util.*;

/** Runtime registry scanner. Samples mod items uniformly and gives wearable clothing a modest bonus. */
public final class LootScanner {
    private LootScanner() {}
    public record ScanSummary(int total, Map<String,Integer> byMod) {}
    private static final List<Item> COMMON = new ArrayList<>();
    private static final List<Item> CLOTHING = new ArrayList<>();
    private static final List<Item> VEHICLE = new ArrayList<>();
    private static final List<Item> VALUABLE = new ArrayList<>();
    private static final List<List<Item>> ARMOR_SETS = new ArrayList<>();
    private static boolean scanned;

    public static synchronized ScanSummary scan() {
        COMMON.clear(); CLOTHING.clear(); VEHICLE.clear(); VALUABLE.clear(); ARMOR_SETS.clear();
        Map<String,Integer> counts = new TreeMap<>();
        Map<String, EnumMap<EquipmentSlot, Item>> sets = new HashMap<>();
        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id == null || item == Items.AIR || excluded(id)) continue;
            counts.merge(id.getNamespace(), 1, Integer::sum);
            if (item instanceof ArmorItem armor) {
                String key = id.getNamespace() + ":" + armorSetName(id.getPath());
                sets.computeIfAbsent(key, k -> new EnumMap<>(EquipmentSlot.class)).put(armor.getEquipmentSlot(), item);
            } else {
                COMMON.add(item);
                if (isWearableClothing(id.getPath())) CLOTHING.add(item);
                if (isVehicleItem(id.getPath())) VEHICLE.add(item);
                if (isValuableItem(id.getPath())) VALUABLE.add(item);
            }
        }
        for (EnumMap<EquipmentSlot, Item> set : sets.values()) {
            if (set.containsKey(EquipmentSlot.HEAD) && set.containsKey(EquipmentSlot.CHEST)
                    && set.containsKey(EquipmentSlot.LEGS) && set.containsKey(EquipmentSlot.FEET))
                ARMOR_SETS.add(new ArrayList<>(set.values()));
        }
        scanned = true;
        return new ScanSummary(COMMON.size() + sets.values().stream().mapToInt(Map::size).sum(), Collections.unmodifiableMap(counts));
    }

    private static boolean isWearableClothing(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        return p.contains("clothing") || p.contains("outfit") || p.contains("costume") || p.contains("jacket")
                || p.contains("shirt") || p.contains("hoodie") || p.contains("pants") || p.contains("trousers")
                || p.contains("suit") || p.contains("uniform") || p.contains("coat") || p.contains("hat")
                || p.contains("glove") || p.contains("scarf") || p.contains("dress") || p.contains("boots");
    }


    private static boolean isVehicleItem(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        return p.contains("wheel") || p.contains("tire") || p.contains("tyre") || p.contains("engine")
                || p.contains("vehicle") || p.contains("car_") || p.startsWith("car") || p.contains("motor")
                || p.contains("brake") || p.contains("steering") || p.contains("suspension") || p.contains("fuel_tank")
                || p.contains("rotor") || p.contains("wing") || p.contains("propeller") || p.contains("jet");
    }

    private static boolean isValuableItem(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        return p.contains("weapon") || p.contains("gun") || p.contains("rifle") || p.contains("pistol")
                || p.contains("sword") || p.contains("blade") || p.contains("armor") || p.contains("armour")
                || p.contains("artifact") || p.contains("relic") || p.contains("crystal") || p.contains("energy")
                || p.contains("ammo") || p.contains("bullet") || p.contains("missile") || p.contains("grenade")
                || p.contains("railgun") || p.contains("laser") || p.contains("staff") || p.contains("wand")
                || p.contains("blaster") || p.contains("lightsaber") || p.contains("saber") || p.contains("shotgun")
                || p.contains("katana") || p.contains("spear") || p.contains("crossbow") || p.contains("cyberware")
                || p.contains("serum") || p.contains("syringe") || p.contains("hero") || p.contains("hammer");
    }

    private static boolean excluded(ResourceLocation id) {
        String p = id.getPath().toLowerCase(Locale.ROOT);
        return Set.of("air", "barrier", "command_block", "chain_command_block", "repeating_command_block",
                "structure_block", "jigsaw", "light", "structure_void", "knowledge_book").contains(p)
                || p.contains("spawn_egg") || p.contains("debug") || p.contains("test_item") || p.contains("_spawn");
    }

    private static String armorSetName(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        for (String suffix : List.of("_helmet", "_head", "_mask", "_chestplate", "_chest", "_leggings", "_legs", "_boots", "_feet"))
            if (p.endsWith(suffix)) return p.substring(0, p.length() - suffix.length());
        return p;
    }

    /** Creates a stocked container. Armor remains rare and a full suit is kept together. */
    public static synchronized List<ItemStack> generateContainerLoot(Random random, int targetStacks, boolean allowArmorSet) {
        if (!scanned) scan();
        List<ItemStack> out = new ArrayList<>();
        if (allowArmorSet && !ARMOR_SETS.isEmpty() && random.nextFloat() < 0.075f) {
            List<Item> set = ARMOR_SETS.get(random.nextInt(ARMOR_SETS.size()));
            for (Item piece : set) out.add(new ItemStack(piece));
        }
        if (COMMON.isEmpty()) {
            out.add(new ItemStack(Items.IRON_INGOT, 3));
            out.add(new ItemStack(Items.COOKED_BEEF, 2));
            return out;
        }
        int count = Math.max(8, targetStacks - out.size());
        for (int i = 0; i < count; i++) {
            // 12% of draws use the clothing pool; all other registered items keep uniform odds.
            Item item = !CLOTHING.isEmpty() && random.nextFloat() < 0.12f
                    ? CLOTHING.get(random.nextInt(CLOTHING.size()))
                    : COMMON.get(random.nextInt(COMMON.size()));
            ItemStack stack = new ItemStack(item);
            if (stack.getMaxStackSize() > 1 && random.nextFloat() < 0.35f)
                stack.setCount(1 + random.nextInt(Math.min(stack.getMaxStackSize(), 8)));
            out.add(stack);
        }
        return out;
    }

    public static synchronized List<ItemStack> generateVehicleContainerLoot(Random random,int targetStacks,boolean allowArmorSet) {
        if (!scanned) scan();
        List<ItemStack> out=generateContainerLoot(random,targetStacks,allowArmorSet);
        if (VEHICLE.isEmpty()) return out;
        int firstNonArmor=0;
        while(firstNonArmor<out.size() && out.get(firstNonArmor).getItem() instanceof ArmorItem) firstNonArmor++;
        for(int i=0;i<Math.max(1,targetStacks/4) && firstNonArmor+i<out.size();i++) {
            if(random.nextFloat()<0.55f) {
                Item item=VEHICLE.get(random.nextInt(VEHICLE.size()));
                out.set(firstNonArmor+i,new ItemStack(item));
            }
        }
        return out;
    }

    public static synchronized List<ItemStack> generateScrapyardContainerLoot(Random random,int targetStacks,boolean allowArmorSet) {
        if (!scanned) scan();
        List<ItemStack> out=generateContainerLoot(random,targetStacks,allowArmorSet);
        if (VALUABLE.isEmpty()) return out;
        int replacements=Math.max(2,targetStacks/5);
        for(int i=0;i<replacements && i<out.size();i++) {
            if(random.nextFloat()<0.8f) out.set(i,new ItemStack(VALUABLE.get(random.nextInt(VALUABLE.size()))));
        }
        return out;
    }

    public static synchronized List<ItemStack> generateGarageLoot(Random random, int targetStacks) {
        return generateContainerLoot(random, targetStacks, true);
    }

    public static ItemStack randomStack(Random random) {
        List<ItemStack> stacks = generateContainerLoot(random, 1, false);
        return stacks.isEmpty() ? ItemStack.EMPTY : stacks.get(0);
    }
}
