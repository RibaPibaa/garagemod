package com.geko.garageauction.structure;

import com.geko.garageauction.loot.LootScanner;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.Container;

import java.util.*;

/** Procedural locations and loot handling for Garage Auction. */
public final class MarketplaceBuilder {
    private MarketplaceBuilder() {}

    private static BlockPos oriented(BlockPos origin, Direction right, Direction forward, int x, int z) {
        return origin.relative(right, x).relative(forward, z);
    }

    private static int surfaceY(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    /** Find a safe, mostly level footprint. Only the footprint itself is modified. */
    private static int prepareFootprint(ServerLevel level, BlockPos center, int radius, Block floor, boolean circular) {
        List<Integer> heights = new ArrayList<>();
        int min=Integer.MAX_VALUE, max=Integer.MIN_VALUE;
        for (int x=-radius; x<=radius; x++) for (int z=-radius; z<=radius; z++) {
            if (circular && x*x+z*z > radius*radius) continue;
            int h=surfaceY(level,center.getX()+x,center.getZ()+z);
            heights.add(h); min=Math.min(min,h); max=Math.max(max,h);
        }
        if (heights.isEmpty()) return center.getY();
        Collections.sort(heights);
        int base = heights.get(heights.size()/2);
        if (max-min > 10 || heights.stream().anyMatch(h -> Math.abs(h-base)>5))
            throw new IllegalArgumentException("Рельеф слишком крутой (перепад " + (max-min) + " блоков). Выбери более ровное место.");
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x=-radius; x<=radius; x++) for (int z=-radius; z<=radius; z++) {
            if (circular && x*x+z*z > radius*radius) continue;
            int wx=center.getX()+x, wz=center.getZ()+z;
            int top=surfaceY(level,wx,wz);
            // Cut only the high column inside the footprint; low ground receives a compact dirt foundation.
            if (top > base) {
                for (int y=Math.min(level.getMaxBuildHeight()-1,top+1); y>=base-1; y--) {
                    pos.set(wx,y,wz);
                    if (!level.getBlockState(pos).isAir()) level.removeBlock(pos,false);
                }
            } else if (top < base) {
                for (int y=top-1; y<base-1; y++) {
                    pos.set(wx,y,wz); level.setBlock(pos, Blocks.DIRT.defaultBlockState(),3);
                }
            }
            // Strip foliage inside the build footprint so tree canopies are not left floating.
            for (int y=base; y<Math.min(level.getMaxBuildHeight(),base+24); y++) {
                pos.set(wx,y,wz);
                if (level.getBlockState(pos).getBlock() instanceof LeavesBlock) level.removeBlock(pos,false);
            }
            pos.set(wx,base-1,wz); level.setBlock(pos, floor.defaultBlockState(),3);
        }
        return base;
    }

    public static void generatePark(ServerLevel level, BlockPos playerPos, float yaw) {
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        Direction f=Direction.fromYRot(yaw).getOpposite(), right=f.getClockWise();
        BlockPos o=playerPos.relative(f,14);
        int base=prepareFootprint(level,o,102,Blocks.GRASS_BLOCK,true);
        // Large circular green, stone perimeter and planted outer ring.
        for(int x=-102;x<=102;x++) for(int z=-102;z<=102;z++) {
            double d=Math.sqrt(x*x+z*z); if(d>102) continue;
            BlockPos p=o.offset(x,base-1-o.getY(),z);
            if(d>94) level.setBlock(p,Blocks.STONE_BRICKS.defaultBlockState(),3);
            else if(d>91 && r.nextFloat()<.25f) level.setBlock(p,Blocks.MOSSY_STONE_BRICKS.defaultBlockState(),3);
            else level.setBlock(p,Blocks.GRASS_BLOCK.defaultBlockState(),3);
        }
        // Thick hedge wall and trees around the edge.
        for(int a=0;a<360;a++) {
            double ang=a*Math.PI/180.0;
            BlockPos p=o.offset((int)(96*Math.cos(ang)),base-o.getY(),(int)(96*Math.sin(ang)));
            for(int y=0;y<3;y++) for(int dx=-1;dx<=1;dx++) for(int dz=-1;dz<=1;dz++)
                level.setBlock(p.offset(dx,y,dz),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
            if(a%18==0) parkTree(level,p,r);
        }
        // Central monument.
        BlockPos c=o;
        for(int y=0;y<3;y++) for(int x=-7+y;x<=7-y;x++) for(int z=-7+y;z<=7-y;z++)
            level.setBlock(c.offset(x,base-o.getY()+y-1,z),Blocks.POLISHED_ANDESITE.defaultBlockState(),3);
        for(int y=2;y<16;y++) {
            int rad=y<9?3:2;
            for(int x=-rad;x<=rad;x++) for(int z=-rad;z<=rad;z++) if(Math.abs(x)+Math.abs(z)<=rad+1)
                level.setBlock(c.offset(x,base-o.getY()+y,z),(y%3==0?Blocks.GRAY_CONCRETE:Blocks.STONE_BRICKS).defaultBlockState(),3);
        }
        // Four broad paths and secondary cross paths.
        for(int n=-2;n<=2;n++) for(int t=-90;t<=90;t++) {
            for(int w=-1;w<=1;w++) {
                BlockPos p=oriented(o,right,f,n*2+w, t);
                if(p.getX()<o.getX()-100 || p.getX()>o.getX()+100) continue;
                level.setBlock(p.offset(0,base-o.getY()-1,0),Blocks.SMOOTH_STONE.defaultBlockState(),3);
            }
            BlockPos q=oriented(o,right,f,t,n*2);
            level.setBlock(q.offset(0,base-o.getY()-1,0),Blocks.SMOOTH_STONE.defaultBlockState(),3);
        }
        // Flower beds alongside paths.
        Block[] flowers={Blocks.POPPY,Blocks.DANDELION,Blocks.BLUE_ORCHID,Blocks.CORNFLOWER,Blocks.ALLIUM,Blocks.OXEYE_DAISY,Blocks.RED_TULIP,Blocks.AZURE_BLUET};
        for(int i=0;i<280;i++) {
            int x=r.nextInt(176)-88,z=r.nextInt(176)-88;
            if(x*x+z*z>88*88) continue;
            BlockPos p=o.offset(x,base-o.getY(),z);
            if(level.getBlockState(p).isAir() && r.nextFloat()<.72f) level.setBlock(p,flowers[r.nextInt(flowers.length)].defaultBlockState(),3);
        }
        // Benches and lamps near the central paths.
        for(int a=0;a<16;a++) {
            double ang=a*Math.PI/8; int x=(int)(17*Math.cos(ang)),z=(int)(17*Math.sin(ang));
            BlockPos p=o.offset(x,base-o.getY(),z);
            level.setBlock(p,Blocks.SPRUCE_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.NORTH),3);
            if(a%2==0) { level.setBlock(p.above(3),Blocks.LANTERN.defaultBlockState(),3); }
        }
        // 24 cottages in three rings, with enough room for paths between them.
        Block[] roofs={Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL,Blocks.ORANGE_WOOL,Blocks.PURPLE_WOOL,Blocks.CYAN_WOOL,Blocks.MAGENTA_WOOL};
        int idx=1;
        for(int ring=0;ring<3;ring++) for(int i=0;i<8;i++) {
            double ang=i*Math.PI/4+(ring%2==0?0:Math.PI/8);
            int rad=ring==0?43:ring==1?65:84;
            BlockPos h=o.offset((int)(rad*Math.cos(ang)),base-o.getY(),(int)(rad*Math.sin(ang)));
            buildParkCottage(level,h,idx++,roofs[r.nextInt(roofs.length)],r);
        }
    }

    private static void parkTree(ServerLevel level,BlockPos p,RandomSource r) {
        int h=4+r.nextInt(3);
        for(int y=0;y<h;y++) level.setBlock(p.above(y),Blocks.OAK_LOG.defaultBlockState(),3);
        for(int x=-2;x<=2;x++) for(int y=h-2;y<=h+1;y++) for(int z=-2;z<=2;z++)
            if(x*x+z*z+(y-h)*(y-h)<=7 && r.nextFloat()<.88f)
                level.setBlock(p.offset(x,y,z),Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT,true),3);
    }

    private static void buildParkCottage(ServerLevel level,BlockPos p,int index,Block roof,RandomSource r) {
        int w=9,d=10; Block[] woods={Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,Blocks.BIRCH_PLANKS,Blocks.DARK_OAK_PLANKS};
        Block wall=woods[r.nextInt(woods.length)];
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=p.offset(x,0,z); level.setBlock(q,Blocks.OAK_PLANKS.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) for(int y=1;y<=4;y++)
                if(!(z==0&&x>=3&&x<=5&&y<=3)) level.setBlock(q.above(y),wall.defaultBlockState(),3);
        }
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) level.setBlock(p.offset(x,5,z),roof.defaultBlockState(),3);
        level.setBlock(p.offset(4,1,0),Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH),3);
        level.setBlock(p.offset(4,2,0),Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.FACING,Direction.SOUTH).setValue(DoorBlock.HALF,DoubleBlockHalf.UPPER),3);
        level.setBlock(p.offset(2,1,2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(6,1,2),Blocks.CARTOGRAPHY_TABLE.defaultBlockState(),3);
        if(r.nextBoolean()) {
            ArmorStand stand=EntityType.ARMOR_STAND.create(level);
            if(stand!=null) { stand.moveTo(p.getX()+4.5,p.getY()+1,p.getZ()+6.5,r.nextFloat()*360,0); level.addFreshEntity(stand); }
        }
        fillGarageContainers(level,p,w,d,4+r.nextInt(3),r,true,false);
    }

    public static void generateScrapyard(ServerLevel level,BlockPos playerPos,float yaw) {
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        BlockPos o=playerPos.relative(f,10);
        int base=prepareFootprint(level,o,48,Blocks.COARSE_DIRT,false);
        Block[] ground={Blocks.COARSE_DIRT,Blocks.MUD,Blocks.ROOTED_DIRT,Blocks.PODZOL,Blocks.MOSS_BLOCK};
        for(int x=-48;x<=48;x++) for(int z=-42;z<=48;z++) {
            BlockPos p=o.offset(x,base-o.getY()-1,z);
            if(r.nextFloat()<.12f) level.setBlock(p,ground[r.nextInt(ground.length)].defaultBlockState(),3);
        }
        // Perimeter walls of wreckage; no gravel in the palette.
        for(int side=-1;side<=1;side+=2) for(int z=-38;z<=42;z+=3+r.nextInt(3))
            rubbleMound(level,o.offset(side*(40+r.nextInt(5)),base-o.getY(),z),3+r.nextInt(4),2+r.nextInt(4),r);
        for(int x=-40;x<=40;x+=4+r.nextInt(3)) rubbleMound(level,o.offset(x,base-o.getY(),-35-r.nextInt(5)),3+r.nextInt(4),2+r.nextInt(4),r);
        // Main muddy access tracks.
        for(int lane=-1;lane<=1;lane++) for(int z=-5;z<=46;z++) for(int x=-2;x<=2;x++) {
            BlockPos p=oriented(o,right,f,lane*22+x,z).offset(0,base-o.getY()-1,0);
            if(r.nextFloat()<.22f) level.setBlock(p,Blocks.PODZOL.defaultBlockState(),3);
            else if(r.nextFloat()<.12f) level.setBlock(p,Blocks.COARSE_DIRT.defaultBlockState(),3);
        }
        // 20 irregular trash heaps. Containers are placed beside/on clear ground, never buried.
        for(int i=0;i<20;i++) {
            int x=r.nextInt(74)-37,z=r.nextInt(68)-20;
            BlockPos mound=o.offset(x,base-o.getY(),z);
            int moundRadius=3+r.nextInt(4);
            rubbleMound(level,mound,moundRadius,2+r.nextInt(5),r);
            int containers=2+r.nextInt(3);
            for(int c=0;c<containers;c++) {
                int dx=(c%2==0?-1:1)*(moundRadius+2), dz=(c/2)*(moundRadius+2);
                BlockPos cp=mound.offset(dx,0,dz);
                placeLootContainer(level,cp,r,16+r.nextInt(8),false,false,true);
            }
        }
        // A few isolated searchable barrels among the debris.
        for(int i=0;i<14;i++) {
            BlockPos p=o.offset(r.nextInt(82)-41,base-o.getY(),r.nextInt(72)-24);
            placeLootContainer(level,p,r,15+r.nextInt(8),false,false,true);
        }
    }

    private static void rubbleMound(ServerLevel level,BlockPos center,int radius,int height,RandomSource r) {
        BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        for(int y=0;y<height;y++) for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) {
            double limit=radius-y*.48; if(x*x+z*z>limit*limit || r.nextFloat()<.13f) continue;
            p.set(center.getX()+x,center.getY()+y,center.getZ()+z);
            level.setBlock(p,randomTrashBlock(r).defaultBlockState(),3);
        }
    }

    private static Block randomTrashBlock(RandomSource r) {
        Block[] palette={Blocks.COBBLESTONE,Blocks.MOSSY_COBBLESTONE,Blocks.ANDESITE,Blocks.DIORITE,Blocks.COBBLED_DEEPSLATE,
            Blocks.BRICKS,Blocks.MOSSY_STONE_BRICKS,Blocks.OAK_PLANKS,Blocks.SPRUCE_PLANKS,Blocks.IRON_BLOCK,
            Blocks.CUT_COPPER,Blocks.DIRT,Blocks.ROOTED_DIRT,Blocks.CHAIN,Blocks.GRAY_CONCRETE,
            Blocks.BLACK_CONCRETE,Blocks.DEEPSLATE_BRICKS,Blocks.CRACKED_STONE_BRICKS};
        return palette[r.nextInt(palette.length)];
    }

    public static void generateGarages(ServerLevel level,BlockPos playerPos,float yaw) {
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        BlockPos o=playerPos.relative(f,12);
        int base=prepareFootprint(level,o,52,Blocks.GRAY_CONCRETE,false);
        // Blue-grey enclosed yard.
        for(int x=-50;x<=50;x++) for(int z=-50;z<=50;z++) if(Math.abs(x)==50||Math.abs(z)==50) {
            for(int y=0;y<5;y++) level.setBlock(o.offset(x,base-o.getY()+y,z),Blocks.BLUE_TERRACOTTA.defaultBlockState(),3);
            if((x+z)%8==0) level.setBlock(o.offset(x,base-o.getY()+5,z),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        int idx=1;
        for(int row=0;row<3;row++) for(int col=0;col<4;col++) {
            BlockPos p=oriented(o,right,f,-31+col*21,-28+row*27).above(base-o.getY());
            buildWorkshopGarage(level,p,idx++,r);
        }
        // Concrete lanes between the rows.
        for(int z=-46;z<=46;z++) for(int x=-2;x<=2;x++)
            level.setBlock(o.offset(x,base-o.getY()-1,z),Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
        for(int i=0;i<12;i++) {
            BlockPos lamp=o.offset((i%2==0?-1:1)*46,base-o.getY(),-42+i*7);
            level.setBlock(lamp,Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(),3);
            level.setBlock(lamp.above(4),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
    }

    private static void buildWorkshopGarage(ServerLevel level,BlockPos p,int index,RandomSource r) {
        int w=13,d=15,h=5;
        for(int x=0;x<w;x++) for(int z=0;z<d;z++) {
            BlockPos q=p.offset(x,0,z);
            level.setBlock(q,Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            if(x==0||x==w-1||z==0||z==d-1) for(int y=1;y<=h;y++) {
                if(z==0 && x>=3 && x<=w-4 && y<=4) continue;
                level.setBlock(q.above(y), (r.nextInt(4)==0?Blocks.LIGHT_GRAY_CONCRETE:Blocks.BLUE_TERRACOTTA).defaultBlockState(),3);
            }
            if(yRoofEdge(x,z,w,d)) level.setBlock(q.above(h+1),Blocks.GRAY_CONCRETE.defaultBlockState(),3);
        }
        // Oversized solid iron-block garage shutter.
        for(int x=3;x<=w-4;x++) for(int y=1;y<=4;y++) level.setBlock(p.offset(x,y,0),Blocks.IRON_BLOCK.defaultBlockState(),3);
        BlockPos sign=p.offset(w/2,h+1,1);
        level.setBlock(sign,Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,2),Blocks.CRAFTING_TABLE.defaultBlockState(),3);
        level.setBlock(p.offset(w-2,1,2),Blocks.ANVIL.defaultBlockState(),3);
        level.setBlock(p.offset(1,1,d-2),Blocks.SMITHING_TABLE.defaultBlockState(),3);
        fillGarageContainers(level,p,w,d,4+r.nextInt(3),r,true,true);
        level.setBlock(p.offset(w/2, h+2, d-2),Blocks.SEA_LANTERN.defaultBlockState(),3);
    }

    private static boolean yRoofEdge(int x,int z,int w,int d) { return x==0||x==w-1||z==0||z==d-1; }

    public static void generateArena(ServerLevel level,BlockPos playerPos,float yaw) {
        BlockPos o=playerPos.relative(Direction.fromYRot(yaw).getOpposite(),12);
        int base=prepareFootprint(level,o,62,Blocks.STONE_BRICKS,true);
        for(int x=-60;x<=60;x++) for(int z=-60;z<=60;z++) {
            double d=Math.sqrt(x*x+z*z); if(d>60) continue;
            BlockPos p=o.offset(x,base-o.getY()-1,z);
            level.setBlock(p,d<38?Blocks.SMOOTH_STONE.defaultBlockState():Blocks.GRAY_CONCRETE.defaultBlockState(),3);
            if(d>48) for(int y=0;y<5;y++) level.setBlock(p.above(y+1),Blocks.STONE_BRICKS.defaultBlockState(),3);
        }
        // Tiered circular spectator stands.
        for(int ring=39;ring<=57;ring++) {
            int rise=(ring-39)/3;
            for(int a=0;a<720;a++) {
                double ang=a*Math.PI/360; int x=(int)(ring*Math.cos(ang)),z=(int)(ring*Math.sin(ang));
                BlockPos p=o.offset(x,base-o.getY()+rise,z);
                level.setBlock(p,ring%2==0?Blocks.POLISHED_ANDESITE.defaultBlockState():Blocks.GRAY_CONCRETE.defaultBlockState(),3);
                if(ring%3==0) level.setBlock(p.above(),Blocks.STONE_BRICK_STAIRS.defaultBlockState(),3);
            }
        }
        // Four lighting towers outside the fighting floor; no containers or loot.
        for(int a=0;a<16;a++) {
            double ang=a*Math.PI/8; int x=(int)(55*Math.cos(ang)),z=(int)(55*Math.sin(ang));
            BlockPos p=o.offset(x,base-o.getY(),z);
            for(int y=0;y<11;y++) level.setBlock(p.above(y),Blocks.IRON_BARS.defaultBlockState(),3);
            level.setBlock(p.above(11),Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
        for(int a=0;a<8;a++) {
            double ang=a*Math.PI/4; BlockPos p=o.offset((int)(33*Math.cos(ang)),base-o.getY(),(int)(33*Math.sin(ang)));
            level.setBlock(p,Blocks.SEA_LANTERN.defaultBlockState(),3);
        }
    }

    /** Spawn a requested number of independent objects in a straight row in front of the player. */
    public static int spawnBatch(ServerLevel level,BlockPos playerPos,float yaw,String type,int count) {
        Direction f=Direction.fromYRot(yaw).getOpposite(),right=f.getClockWise();
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        int made=0;
        for(int i=0;i<count;i++) {
            BlockPos p=playerPos.relative(f,8).relative(right,(i-(count-1)/2)*16);
            int y=surfaceY(level,p.getX(),p.getZ()); p=new BlockPos(p.getX(),y,p.getZ());
            switch(type.toLowerCase(Locale.ROOT)) {
                case "square" -> buildParkCottage(level,p, i+1, new Block[]{Blocks.RED_WOOL,Blocks.BLUE_WOOL,Blocks.GREEN_WOOL,Blocks.YELLOW_WOOL}[r.nextInt(4)],r);
                case "workshop", "garage" -> buildWorkshopGarage(level,p,i+1,r);
                case "scrapyard", "trash" -> {
                    int moundRadius=4+r.nextInt(3);
                    rubbleMound(level,p,moundRadius,3+r.nextInt(4),r);
                    for(int c=0;c<3;c++) placeLootContainer(level,p.offset((c-1)*(moundRadius+2),0,moundRadius+2),r,16+r.nextInt(8),false,false,true);
                }
                default -> throw new IllegalArgumentException("Тип: square, workshop или scrapyard");
            }
            made++;
        }
        return made;
    }

    private static void fillGarageContainers(ServerLevel level,BlockPos p,int w,int d,int count,RandomSource r,boolean allowArmor,boolean workshop) {
        Set<Long> used=new HashSet<>(); boolean armorSetUsed=false;
        for(int i=0;i<count;i++) {
            BlockPos cp=null;
            for(int tries=0;tries<60;tries++) {
                int x=1+r.nextInt(w-2),z=1+r.nextInt(d-2);
                // Keep the central floor clear and containers visibly inside the room.
                if(z<3 && x>w/2-2 && x<w/2+2) continue;
                BlockPos candidate=p.offset(x,1,z);
                if(used.add(candidate.asLong())) {cp=candidate;break;}
            }
            if(cp==null) continue;
            placeLootContainer(level,cp,r,16+r.nextInt(9),allowArmor&&!armorSetUsed,workshop);
            BlockEntity be=level.getBlockEntity(cp);
            if(be instanceof Container c) for(int slot=0;slot<c.getContainerSize();slot++) {
                ItemStack st=c.getItem(slot);
                if(!st.isEmpty() && st.getItem() instanceof net.minecraft.world.item.ArmorItem) armorSetUsed=true;
            }
        }
    }

    private static void placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowArmor) {
        placeLootContainer(level,pos,r,target,allowArmor,false,false);
    }

    private static void placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowArmor,boolean vehicleBonus) {
        placeLootContainer(level,pos,r,target,allowArmor,vehicleBonus,false);
    }

    private static void placeLootContainer(ServerLevel level,BlockPos pos,RandomSource r,int target,boolean allowArmor,boolean vehicleBonus,boolean scrapyardBonus) {
        // Container is placed on top of the floor, not embedded into it.
        BlockPos cp=pos;
        if(!level.getBlockState(cp).isAir()) cp=cp.above();
        if(!level.getBlockState(cp).isAir()) cp=cp.above();
        boolean barrel=r.nextFloat()<.38f;
        level.setBlock(cp,barrel?Blocks.BARREL.defaultBlockState():Blocks.CHEST.defaultBlockState(),3);
        BlockEntity be=level.getBlockEntity(cp);
        if(be instanceof Container container) {
            List<ItemStack> loot=vehicleBonus
                    ? LootScanner.generateVehicleContainerLoot(new Random(r.nextLong()),target,allowArmor)
                    : scrapyardBonus
                        ? LootScanner.generateScrapyardContainerLoot(new Random(r.nextLong()),target,allowArmor)
                        : LootScanner.generateContainerLoot(new Random(r.nextLong()),target,allowArmor);
            fillRandomSlots(container,loot,r);
        }
    }

    private static void fillRandomSlots(Container container,List<ItemStack> loot,RandomSource r) {
        container.clearContent();
        int size=container.getContainerSize();
        List<ItemStack> items=new ArrayList<>();
        for(ItemStack stack:loot) if(stack!=null&&!stack.isEmpty()) items.add(stack.copy());
        // Always at least one item, even if a registry scan unexpectedly returned nothing.
        if(items.isEmpty()) items.add(new ItemStack(Items.IRON_INGOT,2+r.nextInt(5)));
        Collections.shuffle(items,new Random(r.nextLong()));
        List<Integer> slots=new ArrayList<>(); for(int i=0;i<size;i++) slots.add(i);
        Collections.shuffle(slots,new Random(r.nextLong()));
        int n=Math.min(size,items.size());
        for(int i=0;i<n;i++) container.setItem(slots.get(i),items.get(i));
        container.setChanged();
    }

    /** Refreshes only chest/barrel loot in the selected radius. Returns updated container count. */
    public static int refreshLoot(ServerLevel level,BlockPos center,int radius,String lootMode) {
        int changed=0; BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        int minY=Math.max(level.getMinBuildHeight(),center.getY()-24),maxY=Math.min(level.getMaxBuildHeight()-1,center.getY()+32);
        RandomSource r=RandomSource.create(level.getRandom().nextLong());
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) for(int y=minY;y<=maxY;y++) {
            p.set(center.getX()+x,y,center.getZ()+z);
            BlockEntity be=level.getBlockEntity(p);
            if(be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) {
                if(be instanceof Container container) {
                    boolean allowArmor=changed%5==0;
                    int target=18+r.nextInt(8);
                    List<ItemStack> loot="vehicle".equals(lootMode)
                            ? LootScanner.generateVehicleContainerLoot(new Random(r.nextLong()),target,allowArmor)
                            : "scrapyard".equals(lootMode)
                                ? LootScanner.generateScrapyardContainerLoot(new Random(r.nextLong()),target,allowArmor)
                                : LootScanner.generateContainerLoot(new Random(r.nextLong()),target,allowArmor);
                    fillRandomSlots(container,loot,r); changed++;
                }
            }
        }
        return changed;
    }

    /** Legacy compatibility: clears only a bounded cube, retained for internal tooling. */
    public static int clear(ServerLevel level,BlockPos center,int radius) {
        int removed=0; BlockPos.MutableBlockPos p=new BlockPos.MutableBlockPos();
        int minY=Math.max(level.getMinBuildHeight(),center.getY()-8),maxY=Math.min(level.getMaxBuildHeight()-1,center.getY()+24);
        for(int x=-radius;x<=radius;x++) for(int z=-radius;z<=radius;z++) for(int y=minY;y<=maxY;y++) {
            p.set(center.getX()+x,y,z);
            if(!level.getBlockState(p).isAir()) {level.removeBlock(p,false);removed++;}
        }
        return removed;
    }
}
