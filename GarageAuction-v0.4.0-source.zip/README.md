# Garage Auction 0.4.0 — Forge 1.20.1

**Runtime:** Minecraft 1.20.1, Forge 47.4.28, Java 17. Build with Gradle 8.8.

## Commands (operator permission level 2)

- `/squarespawn` — landscaped circular park, central monument, paths, flower beds, trees and 24 cottages. Each cottage receives 4–6 loot containers.
- `/scrapyardspawn` — abandoned scrapyard made of irregular trash heaps, with searchable chests and barrels. Loot favours weapons, ammunition, equipment and other valuables.
- `/garagesspawn` — enclosed blue-grey yard with 12 machine garages, large iron doors and 4–6 loot containers per garage. Vehicle-related items receive extra weight.
- `/luxuryspawn` — premium residential district with four two-storey white villas, blue-glass windows, furnished interiors, landscaped hedges and exactly 10 mixed chests/barrels across the whole district (2–3 per villa).
- `/arenaspawn` — large circular stadium with stepped stands and lighting. It does not generate loot containers.
- `/garagebatch square 10` — create 10 park cottages in a row.
- `/garagebatch workshop 10` — create 10 machine garages in a row.
- `/garagebatch luxury 4` — create 4 premium villas in a row; each gets 3 loot containers.
- `/garagebatch scrapyard 10` — create 10 separate trash heaps, each with loot containers, in a row.
- `/reverselootsquare` — reroll chest/barrel contents around the player within the park-sized radius.
- `/reverselootgarages` — reroll chest/barrel contents around the player in the garage-yard radius.
- `/reverselootscrapyard` — reroll chest/barrel contents around the player in the scrapyard radius.
- `/reverselootluxury` — reroll loot around the player in the luxury-district radius, using its premium loot weighting.

Run a `reverseloot...` command while standing near the centre of the corresponding generated location. The command refreshes every chest/barrel found in that radius, so avoid standing where unrelated storage is nearby.

## Loot behaviour

The scanner reads the live Forge item registry, so items from installed mods can be considered without listing every mod manually. Normal containers draw uniformly from the registered non-armor item pool, so individual mod items keep the same base chance. Matching armor sets with two or more registered pieces and multi-piece clothing outfits are treated as a single wearable-set drop; the chance was raised from 7.5% to 10% per eligible container. A garage still stops rolling for another wearable set once one has been placed, so it can contain at most one full set.

TaCZ support is optional and uses reflection, so Garage Auction still loads without TaCZ. When TaCZ is present, the mod reads the loaded gun-pack index and creates a valid `tacz:modern_kinetic_gun` stack with its `GunId`, plus a `tacz:ammo` stack with the matching `AmmoId`. Ordinary containers have a 6% per-container gun roll; luxury-villa containers have a 20% roll. The matching ammunition is always placed in the same chest/barrel as the gun.

Luxury-villa containers strongly favour items whose registry IDs indicate weapons, equipment, powers, artifacts, valuables and clothing; ordinary low-value items have a much smaller share. The villa loot uses 62% valuable items, 24% clothing and 14% general items for its normal stack rolls, plus separate wearable-set and TaCZ rolls. Each villa can receive at most one complete wearable set during generation.

Workshop garages give additional weight to vehicle-related item IDs. Scrapyard containers favour IDs suggesting weapons, ammunition, equipment and other valuables. Items are placed in shuffled container slots, not in ordered rows.

Some mods store variants, ammunition, attachments or abilities in custom NBT/capabilities, or use item IDs that do not identify their function. Those require mod-specific adapters; registry scanning alone cannot reliably synthesize them. TaCZ is handled through its own loaded gun/ammo data index.

## Terrain handling

Generation checks the terrain across its intended footprint before changing blocks. It refuses to generate when the height variation is too steep, rather than clearing a huge surrounding area or leaving the build floating. On accepted terrain, the footprint is levelled locally with a compact foundation. It still replaces blocks **inside the generated footprint**, so test in a copy of the world first and keep other builds outside that footprint.

## Build

```bash
gradle build --no-daemon
```

The compiled mod is written to `build/libs/garageauction-0.4.0.jar`.
