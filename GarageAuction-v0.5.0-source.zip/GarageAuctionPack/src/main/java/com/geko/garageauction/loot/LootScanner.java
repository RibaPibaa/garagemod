package com.geko.garageauction.loot;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;

import java.lang.reflect.Method;
import java.util.*;

/** Runtime registry scanner for modded loot, wearable sets and optional TaCZ integration. */
public final class LootScanner {
    private LootScanner() {}

    public record ScanSummary(int total, Map<String, Integer> byMod) {}
    public record LootResult(List<ItemStack> items, boolean includesWearableSet) {}

    private enum ClothingSlot { HEAD, CHEST, LEGS, FEET, HANDS }
    private record TaczGun(ResourceLocation gunId, ResourceLocation ammoId) {}

    private static final List<Item> COMMON = new ArrayList<>();
    private static final List<Item> CLOTHING = new ArrayList<>();
    private static final List<Item> VEHICLE = new ArrayList<>();
    private static final List<Item> VALUABLE = new ArrayList<>();
    private static final List<Item> WEAPONS = new ArrayList<>();
    private static final List<List<Item>> WEARABLE_SETS = new ArrayList<>();
    private static final List<TaczGun> TACZ_GUNS = new ArrayList<>();

    private static final float WEARABLE_SET_CHANCE = 0.10f;
    private static final float TACZ_GUN_CHANCE = 0.06f;
    private static final float LUXURY_SET_CHANCE = 0.18f;
    private static final float LUXURY_TACZ_CHANCE = 0.20f;
    private static boolean scanned;

    public static synchronized ScanSummary scan() {
        COMMON.clear();
        CLOTHING.clear();
        VEHICLE.clear();
        VALUABLE.clear();
        WEAPONS.clear();
        WEARABLE_SETS.clear();
        TACZ_GUNS.clear();

        Map<String, Integer> counts = new TreeMap<>();
        Map<String, EnumMap<EquipmentSlot, Item>> armorSets = new HashMap<>();
        Map<String, EnumMap<ClothingSlot, Item>> clothingSets = new HashMap<>();
        List<Item> onePieceOutfits = new ArrayList<>();

        for (Item item : BuiltInRegistries.ITEM) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            if (id == null || item == Items.AIR || excluded(id)) continue;
            counts.merge(id.getNamespace(), 1, Integer::sum);

            if (item instanceof ArmorItem armor) {
                String armorPath = id.getPath().toLowerCase(Locale.ROOT);
                if (isOnePieceOutfit(armorPath)) {
                    onePieceOutfits.add(item);
                } else {
                    String key = id.getNamespace() + ":" + armorSetName(armorPath);
                    armorSets.computeIfAbsent(key, k -> new EnumMap<>(EquipmentSlot.class))
                            .put(armor.getEquipmentSlot(), item);
                }
                continue;
            }

            COMMON.add(item);
            String path = id.getPath().toLowerCase(Locale.ROOT);
            if (isWearableClothing(path)) {
                CLOTHING.add(item);
                ClothingSlot slot = clothingSlot(path);
                if (slot != null) {
                    String setName = clothingSetName(path, slot);
                    String key = id.getNamespace() + ":" + (setName.isBlank() ? path : setName);
                    clothingSets.computeIfAbsent(key, k -> new EnumMap<>(ClothingSlot.class)).put(slot, item);
                } else if (isOnePieceOutfit(path)) {
                    onePieceOutfits.add(item);
                }
            }
            if (isVehicleItem(path)) VEHICLE.add(item);
            if (isValuableItem(path)) VALUABLE.add(item);
            if (isWeaponItem(path)) WEAPONS.add(item);
        }

        for (EnumMap<EquipmentSlot, Item> set : armorSets.values()) {
            // Some armor packs have two- or three-piece sets rather than the vanilla four-piece layout.
            if (set.size() >= 2) WEARABLE_SETS.add(new ArrayList<>(set.values()));
        }

        for (EnumMap<ClothingSlot, Item> set : clothingSets.values()) {
            // Clothing packs commonly use two-piece outfits; keep all discovered matching pieces together.
            if (set.size() >= 2) WEARABLE_SETS.add(new ArrayList<>(set.values()));
        }
        for (Item outfit : onePieceOutfits) WEARABLE_SETS.add(List.of(outfit));

        scanTaczGuns();
        scanned = true;

        int setPieceCount = WEARABLE_SETS.stream().mapToInt(List::size).sum();
        return new ScanSummary(COMMON.size() + setPieceCount, Collections.unmodifiableMap(counts));
    }

    private static void scanTaczGuns() {
        try {
            // Reflection keeps GarageAuction optional: it still runs when TaCZ is not installed.
            Class<?> api = Class.forName("com.tacz.guns.api.TimelessAPI");
            Method allGunsMethod = api.getDeclaredMethod("getAllCommonGunIndex");
            Object result = allGunsMethod.invoke(null);
            if (!(result instanceof Set<?> entries)) return;

            for (Object object : entries) {
                try {
                    if (!(object instanceof Map.Entry<?, ?> entry)) continue;
                    if (!(entry.getKey() instanceof ResourceLocation gunId)) continue;
                    Object index = entry.getValue();
                    if (index == null) continue;

                    Object gunData = index.getClass().getMethod("getGunData").invoke(index);
                    if (gunData == null) continue;
                    Object ammoValue = gunData.getClass().getMethod("getAmmoId").invoke(gunData);
                    if (!(ammoValue instanceof ResourceLocation ammoId)) continue;
                    if (ammoId.toString().isBlank() || "tacz:empty".equals(ammoId.toString())) continue;

                    TACZ_GUNS.add(new TaczGun(gunId, ammoId));
                } catch (Exception ignoredEntry) {
                    // Skip only a malformed gun-pack entry; keep all other valid guns.
                }
            }
            TACZ_GUNS.sort(Comparator.comparing(g -> g.gunId().toString()));
        } catch (Exception | LinkageError ignored) {
            // TaCZ is optional. A missing or changed API simply disables its special loot roll.
            TACZ_GUNS.clear();
        }
    }

    private static List<ItemStack> createTaczWeaponBundle(Random random) {
        if (TACZ_GUNS.isEmpty()) return List.of();
        Item gunItem = BuiltInRegistries.ITEM.get(new ResourceLocation("tacz", "modern_kinetic_gun"));
        Item ammoItem = BuiltInRegistries.ITEM.get(new ResourceLocation("tacz", "ammo"));
        if (gunItem == Items.AIR || ammoItem == Items.AIR) return List.of();

        TaczGun definition = TACZ_GUNS.get(random.nextInt(TACZ_GUNS.size()));
        ItemStack gun = new ItemStack(gunItem);
        // TaCZ stores the selected gun-pack variant in this NBT field.
        gun.getOrCreateTag().putString("GunId", definition.gunId().toString());

        ItemStack ammo = new ItemStack(ammoItem);
        // AmmoItemDataAccessor reads AmmoId and resolves the correct caliber from the loaded gun packs.
        ammo.getOrCreateTag().putString("AmmoId", definition.ammoId().toString());
        int maxStack = Math.max(1, ammo.getMaxStackSize());
        ammo.setCount(Math.max(1, Math.min(maxStack, 24)));
        return List.of(gun, ammo);
    }

    private static boolean isWearableClothing(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("clothing") || p.contains("outfit") || p.contains("costume") || p.contains("jacket")
                || p.contains("shirt") || p.contains("hoodie") || p.contains("pants") || p.contains("trousers")
                || p.contains("suit") || p.contains("uniform") || p.contains("coat") || p.contains("hat")
                || p.contains("glove") || p.contains("scarf") || p.contains("dress") || p.contains("boots")
                || p.contains("shoes") || p.contains("sneaker") || p.contains("skirt") || p.contains("vest")
                || p.contains("helmet") || p.contains("mask") || p.contains("cape") || p.contains("robe")
                || p.contains("tunic") || p.contains("sweater") || p.contains("blouse") || p.contains("shorts");
    }

    private static ClothingSlot clothingSlot(String path) {
        if (endsWithAny(path, "_helmet", "_helm", "_head", "_mask", "_hood", "_hat", "_cap", "_beanie", "_cowl", "_crown")
                || startsWithAny(path, "helmet_", "helm_", "head_", "mask_", "hood_", "hat_", "cap_")) return ClothingSlot.HEAD;
        if (endsWithAny(path, "_chestplate", "_chest", "_torso", "_jacket", "_coat", "_shirt", "_hoodie", "_top", "_vest", "_tunic", "_robe", "_sweater", "_blouse", "_jersey")
                || startsWithAny(path, "chestplate_", "chest_", "torso_", "jacket_", "coat_", "shirt_", "hoodie_", "top_", "vest_", "tunic_", "robe_")) return ClothingSlot.CHEST;
        if (endsWithAny(path, "_leggings", "_legs", "_pants", "_trousers", "_shorts", "_skirt")
                || startsWithAny(path, "leggings_", "legs_", "pants_", "trousers_", "shorts_", "skirt_")) return ClothingSlot.LEGS;
        if (endsWithAny(path, "_boots", "_feet", "_shoes", "_sneakers", "_sandals")
                || startsWithAny(path, "boots_", "feet_", "shoes_", "sneakers_", "sandals_")) return ClothingSlot.FEET;
        if (endsWithAny(path, "_gloves", "_glove", "_hands", "_gauntlets", "_bracers")
                || startsWithAny(path, "gloves_", "glove_", "hands_", "gauntlets_", "bracers_")) return ClothingSlot.HANDS;
        return null;
    }

    private static String clothingSetName(String path, ClothingSlot slot) {
        String[] suffixes = switch (slot) {
            case HEAD -> new String[]{"_helmet", "_helm", "_head", "_mask", "_hood", "_hat", "_cap", "_beanie", "_cowl", "_crown"};
            case CHEST -> new String[]{"_chestplate", "_chest", "_torso", "_jacket", "_coat", "_shirt", "_hoodie", "_top", "_vest", "_tunic", "_robe", "_sweater", "_blouse", "_jersey"};
            case LEGS -> new String[]{"_leggings", "_legs", "_pants", "_trousers", "_shorts", "_skirt"};
            case FEET -> new String[]{"_boots", "_feet", "_shoes", "_sneakers", "_sandals"};
            case HANDS -> new String[]{"_gloves", "_glove", "_hands", "_gauntlets", "_bracers"};
        };
        for (String suffix : suffixes) if (path.endsWith(suffix)) return path.substring(0, path.length() - suffix.length());
        String[] prefixes = switch (slot) {
            case HEAD -> new String[]{"helmet_", "helm_", "head_", "mask_", "hood_", "hat_", "cap_"};
            case CHEST -> new String[]{"chestplate_", "chest_", "torso_", "jacket_", "coat_", "shirt_", "hoodie_", "top_", "vest_", "tunic_", "robe_"};
            case LEGS -> new String[]{"leggings_", "legs_", "pants_", "trousers_", "shorts_", "skirt_"};
            case FEET -> new String[]{"boots_", "feet_", "shoes_", "sneakers_", "sandals_"};
            case HANDS -> new String[]{"gloves_", "glove_", "hands_", "gauntlets_", "bracers_"};
        };
        for (String prefix : prefixes) if (path.startsWith(prefix)) return path.substring(prefix.length());
        return path;
    }

    private static boolean startsWithAny(String value, String... prefixes) {
        for (String prefix : prefixes) if (value.startsWith(prefix)) return true;
        return false;
    }

    private static boolean isOnePieceOutfit(String path) {
        return endsWithAny(path, "_suit", "_outfit", "_costume", "_uniform", "_onesie", "_dress", "_cape", "_clothing");
    }

    private static boolean endsWithAny(String value, String... suffixes) {
        for (String suffix : suffixes) if (value.endsWith(suffix)) return true;
        return false;
    }

    private static boolean isVehicleItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("wheel") || p.contains("tire") || p.contains("tyre") || p.contains("engine")
                || p.contains("vehicle") || p.contains("car_") || p.startsWith("car") || p.contains("motor")
                || p.contains("brake") || p.contains("steering") || p.contains("suspension") || p.contains("fuel_tank")
                || p.contains("rotor") || p.contains("wing") || p.contains("propeller") || p.contains("jet");
    }

    private static boolean isWeaponItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("weapon") || p.contains("gun") || p.contains("rifle") || p.contains("pistol")
                || p.contains("shotgun") || p.contains("sword") || p.contains("blade") || p.contains("katana")
                || p.contains("saber") || p.contains("sabre") || p.contains("spear") || p.contains("lance")
                || p.contains("axe") || p.contains("mace") || p.contains("hammer") || p.contains("crossbow")
                || p.contains("bow") || p.contains("blaster") || p.contains("lightsaber") || p.contains("railgun")
                || p.contains("laser") || p.contains("launcher") || p.contains("staff") || p.contains("wand")
                || p.contains("grenade") || p.contains("missile") || p.contains("melee");
    }

    private static boolean isValuableItem(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        return p.contains("weapon") || p.contains("gun") || p.contains("rifle") || p.contains("pistol")
                || p.contains("sword") || p.contains("blade") || p.contains("armor") || p.contains("armour")
                || p.contains("artifact") || p.contains("relic") || p.contains("crystal") || p.contains("energy")
                || p.contains("ammo") || p.contains("bullet") || p.contains("missile") || p.contains("grenade")
                || p.contains("railgun") || p.contains("laser") || p.contains("staff") || p.contains("wand")
                || p.contains("blaster") || p.contains("lightsaber") || p.contains("saber") || p.contains("shotgun")
                || p.contains("katana") || p.contains("spear") || p.contains("crossbow") || p.contains("cyberware")
                || p.contains("serum") || p.contains("syringe") || p.contains("hero") || p.contains("hammer")
                || p.contains("shield") || p.contains("gauntlet") || p.contains("power") || p.contains("superpower")
                || p.contains("launcher") || p.contains("melee") || p.contains("grenade") || p.contains("ring")
                || p.contains("amulet") || p.contains("gadget") || p.contains("device");
    }

    private static boolean excluded(ResourceLocation id) {
        String p = id.getPath().toLowerCase(Locale.ROOT);
        if ("tacz".equals(id.getNamespace()) && Set.of("modern_kinetic_gun", "ammo", "ammo_box", "attachment").contains(p))
            return true;
        return Set.of("air", "barrier", "command_block", "chain_command_block", "repeating_command_block",
                "structure_block", "jigsaw", "light", "structure_void", "knowledge_book").contains(p)
                || p.contains("spawn_egg") || p.contains("debug") || p.contains("test_item") || p.contains("_spawn");
    }

    private static String armorSetName(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        for (String suffix : List.of("_armor_helmet", "_armor_chestplate", "_armor_leggings", "_armor_boots",
                "_armor_head", "_armor_chest", "_armor_legs", "_armor_feet", "_helmet", "_helm", "_head",
                "_mask", "_cowl", "_chestplate", "_chest", "_torso", "_body", "_leggings", "_legs",
                "_pants", "_boots", "_feet", "_shoes")) {
            if (p.endsWith(suffix)) return p.substring(0, p.length() - suffix.length());
        }
        for (String prefix : List.of("helmet_", "helm_", "head_", "mask_", "chestplate_", "chest_", "torso_",
                "leggings_", "legs_", "pants_", "boots_", "feet_", "shoes_")) {
            if (p.startsWith(prefix)) return p.substring(prefix.length());
        }
        return p;
    }

    private static void ensureScanned() {
        if (!scanned) scan();
    }

    public static synchronized LootResult generateContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        return generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                WEARABLE_SET_CHANCE, TACZ_GUN_CHANCE, false);
    }

    public static synchronized List<ItemStack> generateContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateContainerLootResult(random, targetStacks, allowWearableSet).items();
    }

    public static synchronized LootResult generateVehicleContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        LootResult result = generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                WEARABLE_SET_CHANCE, TACZ_GUN_CHANCE, false);
        List<ItemStack> out = new ArrayList<>(result.items());
        if (!VEHICLE.isEmpty()) {
            int replacements = Math.max(1, targetStacks / 4);
            int replaced = 0;
            for (int i = 0; i < out.size() && replaced < replacements; i++) {
                if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.55f) {
                    out.set(i, new ItemStack(VEHICLE.get(random.nextInt(VEHICLE.size()))));
                    replaced++;
                }
            }
        }
        return new LootResult(out, result.includesWearableSet());
    }

    public static synchronized List<ItemStack> generateVehicleContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateVehicleContainerLootResult(random, targetStacks, allowWearableSet).items();
    }

    public static synchronized LootResult generateScrapyardContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        LootResult result = generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                WEARABLE_SET_CHANCE, TACZ_GUN_CHANCE, false);
        List<ItemStack> out = new ArrayList<>(result.items());
        if (!VALUABLE.isEmpty()) {
            int replacements = Math.max(2, targetStacks / 5);
            int replaced = 0;
            for (int i = 0; i < out.size() && replaced < replacements; i++) {
                if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.8f) {
                    out.set(i, new ItemStack(VALUABLE.get(random.nextInt(VALUABLE.size()))));
                    replaced++;
                }
            }
        }
        return new LootResult(out, result.includesWearableSet());
    }

    public static synchronized List<ItemStack> generateScrapyardContainerLoot(Random random, int targetStacks, boolean allowWearableSet) {
        return generateScrapyardContainerLootResult(random, targetStacks, allowWearableSet).items();
    }


    private static boolean isProtectedLoot(ItemStack stack) {
        if (stack.isEmpty()) return true;
        Item item = stack.getItem();
        if (item instanceof ArmorItem || CLOTHING.contains(item)) return true;
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
        return id != null && "tacz".equals(id.getNamespace())
                && ("modern_kinetic_gun".equals(id.getPath()) || "ammo".equals(id.getPath()));
    }

    /** Glitch-zone loot is deliberately stronger than ordinary containers. */
    public static synchronized LootResult generateMatrixContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        LootResult base = generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                0.14f, 0.12f, true);
        List<ItemStack> out = new ArrayList<>(base.items());
        if (!VALUABLE.isEmpty()) {
            int replacements = Math.max(2, targetStacks / 3);
            int replaced = 0;
            for (int i = 0; i < out.size() && replaced < replacements; i++) {
                if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.9f) {
                    out.set(i, new ItemStack(VALUABLE.get(random.nextInt(VALUABLE.size()))));
                    replaced++;
                }
            }
        }
        return new LootResult(out, base.includesWearableSet());
    }

    /** Medieval armories favour melee/ranged weapons and have a higher full-set chance. */
    public static synchronized LootResult generateCastleContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        LootResult base = generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                0.24f, 0.10f, false);
        List<ItemStack> out = new ArrayList<>(base.items());
        if (!WEAPONS.isEmpty()) {
            int replacements = Math.max(3, targetStacks / 2);
            int replaced = 0;
            for (int i = 0; i < out.size() && replaced < replacements; i++) {
                if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.92f) {
                    out.set(i, new ItemStack(WEAPONS.get(random.nextInt(WEAPONS.size()))));
                    replaced++;
                }
            }
        } else if (!VALUABLE.isEmpty()) {
            int replacements = Math.max(2, targetStacks / 3);
            for (int i = 0; i < out.size() && replacements > 0; i++) {
                if (!isProtectedLoot(out.get(i)) && random.nextFloat() < 0.85f) {
                    out.set(i, new ItemStack(VALUABLE.get(random.nextInt(VALUABLE.size()))));
                    replacements--;
                }
            }
        }
        return new LootResult(out, base.includesWearableSet());
    }

    public static synchronized LootResult generateLuxuryContainerLootResult(Random random, int targetStacks, boolean allowWearableSet) {
        ensureScanned();
        return generateWeightedContainerLoot(random, targetStacks, allowWearableSet,
                LUXURY_SET_CHANCE, LUXURY_TACZ_CHANCE, true);
    }

    private static LootResult generateWeightedContainerLoot(Random random, int targetStacks, boolean allowWearableSet,
                                                              float setChance, float taczChance, boolean luxury) {
        List<ItemStack> out = new ArrayList<>();
        boolean wearableSetDropped = false;

        if (allowWearableSet && !WEARABLE_SETS.isEmpty() && random.nextFloat() < setChance) {
            List<Item> set = WEARABLE_SETS.get(random.nextInt(WEARABLE_SETS.size()));
            for (Item piece : set) out.add(new ItemStack(piece));
            wearableSetDropped = true;
        }

        if (COMMON.isEmpty() && VALUABLE.isEmpty() && CLOTHING.isEmpty()) {
            out.add(new ItemStack(Items.IRON_INGOT, 3));
            out.add(new ItemStack(Items.COOKED_BEEF, 2));
            return new LootResult(out, wearableSetDropped);
        }

        int count = Math.max(8, targetStacks - out.size());
        for (int i = 0; i < count; i++) {
            Item item;
            if (luxury) {
                float roll = random.nextFloat();
                if (roll < 0.62f && !VALUABLE.isEmpty()) {
                    item = VALUABLE.get(random.nextInt(VALUABLE.size()));
                } else if (roll < 0.86f && !CLOTHING.isEmpty()) {
                    item = CLOTHING.get(random.nextInt(CLOTHING.size()));
                } else if (!COMMON.isEmpty()) {
                    item = COMMON.get(random.nextInt(COMMON.size()));
                } else if (!VALUABLE.isEmpty()) {
                    item = VALUABLE.get(random.nextInt(VALUABLE.size()));
                } else {
                    item = CLOTHING.get(random.nextInt(CLOTHING.size()));
                }
            } else {
                // Every ordinary registered non-armor item keeps the same base chance.
                item = COMMON.isEmpty()
                        ? VALUABLE.get(random.nextInt(VALUABLE.size()))
                        : COMMON.get(random.nextInt(COMMON.size()));
            }

            ItemStack stack = new ItemStack(item);
            if (stack.getMaxStackSize() > 1 && random.nextFloat() < 0.35f)
                stack.setCount(1 + random.nextInt(Math.min(stack.getMaxStackSize(), 8)));
            out.add(stack);
        }

        if (!TACZ_GUNS.isEmpty() && random.nextFloat() < taczChance) {
            List<ItemStack> bundle = createTaczWeaponBundle(random);
            out.addAll(bundle);
        }
        return new LootResult(out, wearableSetDropped);
    }

    public static synchronized List<ItemStack> generateGarageLoot(Random random, int targetStacks) {
        return generateContainerLoot(random, targetStacks, true);
    }

    public static ItemStack randomStack(Random random) {
        List<ItemStack> stacks = generateContainerLoot(random, 1, false);
        return stacks.isEmpty() ? ItemStack.EMPTY : stacks.get(0);
    }
}
