package com.geko.garageauction;

import com.geko.garageauction.command.GarageCommands;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(GarageAuctionMod.MODID)
public class GarageAuctionMod {
    public static final String MODID = "garageauction";

    public GarageAuctionMod() {
        MinecraftForge.EVENT_BUS.addListener(this::registerCommands);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void registerCommands(RegisterCommandsEvent event) {
        GarageCommands.register(event.getDispatcher());
    }
}
