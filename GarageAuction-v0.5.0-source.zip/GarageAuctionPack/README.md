# Garage Auction 0.5.0 — Forge 1.20.1

**Runtime:** Minecraft 1.20.1, Forge 47.4.28, Java 17. Build with Gradle 8.8.

## Spawn commands (operator permission level 2)

- `/squarespawn` — ухоженная круглая площадь с дорожками, цветами, монументом и 24 небольшими гаражами.
- `/scrapyardspawn` — свалка из неровных куч мусора, без гравия и без обычных гаражей. В контейнерах есть лут.
- `/garagesspawn` — сине-серый район мастерских с железными воротами и автомобильным лутом.
- `/luxuryspawn` — огромный круглый богатый район (радиус около 290 блоков) с высокой мраморной стеной, широкими главными проспектами, узкими жилыми улицами, небольшим памятником и плотной застройкой двухэтажными виллами. В каждом доме 7–10 контейнеров, в том числе угловые и поставленные друг на друга.
- `/arenaspawn` — круглый стадион с трибунами и освещением. Лута нет.
- `/matrixspawn` — круглая зона «Сбой в матрице», примерно втрое больше площади по линейным размерам и крупнее богатого района: разноцветная терракота, холмы, низины, трещины, заражённые постройки из других районов, закрытые собственные гаражи и сильный лут.
- `/castlesspawn` — круглый средневековый район с каменной стеной и замками. Внутри замков только бочки; лут смещён в сторону холодного и огнестрельного оружия. В одном замке может выпасть не более двух комплектов брони/одежды.

## Other commands

- `/garagebatch square 10` — создать 10 отдельных гаражей площади в ряд.
- `/garagebatch workshop 10` — создать 10 мастерских в ряд.
- `/garagebatch luxury 4` — создать 4 богатые виллы в ряд, по 7–10 контейнеров в каждой.
- `/garagebatch scrapyard 10` — создать 10 отдельных куч мусора с контейнерами в ряд.
- `/restorestructures` — очистить зарегистрированные модом постройки и восстановить их на тех же местах с тем же seed, расположением и первоначальным лутом. Команда работает с локациями, созданными после установки версии 0.5.0; старые локации не имеют сохранённых координат/seed и автоматически не восстанавливаются. Выполнять в текущем измерении, где были созданы локации.

## Loot refresh commands

- `/reverselootsquare` — обновить содержимое сундуков и бочек площади.
- `/reverselootgarages` — обновить лут мастерских.
- `/reverselootscrapyard` — обновить лут свалки.
- `/reverselootluxury` — обновить лут богатого района.
- `/reverselootmatrix` — обновить лут зоны сбоя в матрице.
- `/reverselootcastles` — обновить лут бочек в замках.

Запускай команду обновления, находясь примерно в центре нужной локации. Обновляются только контейнеры в соответствующем радиусе.

## Loot behaviour

The scanner reads the live Forge item registry, so installed mod items are considered without hard-coding every mod. Normal loot retains the registry-based pool. Vehicle garages give extra weight to vehicle-related item IDs. Scrapyard containers favour valuable equipment. Luxury homes favour valuable items and clothing. Matrix garages use stronger loot. Castle armories favour weapons, including melee and firearms, and have a higher wearable-set chance with a maximum of two complete sets per castle during generation.

TaCZ support remains optional and uses reflection to inspect loaded gun-pack data and create a matching gun/ammunition bundle. Mods that encode variants, abilities, attachments or capabilities in custom NBT may still need dedicated adapters.

Every generated chest/barrel is filled with at least one item. If the registry scan unexpectedly yields no items, a small iron-ingot fallback is used.

## Structure restoration

Version 0.5.0 records each generated location's dimension-local coordinates, orientation, type, radius and random seed in Minecraft SavedData. `/restorestructures` clears the generated volume above the preserved foundation plane, removes generated armor stands, and re-runs the same generator with the saved seed. This avoids stacking duplicate structures and reproduces the same generated layout and loot. Player-built blocks placed inside a registered generated footprint will also be cleared by restoration.

## Terrain handling

Generation checks terrain across its footprint and locally cuts/fills moderate height changes. Very steep terrain is rejected rather than flattening an unlimited area. Large districts affect a large footprint; test them in a copy of the world and keep unrelated builds outside the footprint.

## Build

```bash
gradle build --no-daemon
```

The compiled mod is written to `build/libs/garageauction-0.5.0.jar`.
